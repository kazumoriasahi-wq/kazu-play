import { Table, viewForAI, rankOf, suitOf } from './engine.js';
import { createEffects } from './effects.js';
import { choose, styles } from './ai.js';
const $ = (id) => document.getElementById(id);
const get = (key, defaults) => { try {
    return { ...defaults, ...JSON.parse(localStorage.getItem(key) || '{}') };
}
catch {
    return defaults;
} };
const settingsKey = 'pip_poker_club_settings_v1', statsKey = 'pip_poker_club_stats_v1';
let cfg = get(settingsKey, { lang: 'ja', seats: 4, level: 'medium', sb: 10, bb: 20, buy: 2000, mode: 'free', volume: 45, muted: false, music: 16, musicMuted: false, intensity: 'standard', dealSpeed: 'standard' });
const stats = get(statsKey, { hands: 0, wins: 0, showdowns: 0, showdownWins: 0, vpip: 0, pfr: 0, three: 0, opportunities: 0, largest: 0, trophies: 0, history: [], reads: [] });
function save() { try {
    localStorage.setItem(settingsKey, JSON.stringify(cfg));
    localStorage.setItem(statsKey, JSON.stringify(stats));
}
catch { /* Local storage may be disabled. */ } }
const portalLang = new URLSearchParams(location.search).get('lang');
if (portalLang === 'ja' || portalLang === 'en') cfg.lang = portalLang;
const tr = (ja, en) => cfg.lang === 'ja' ? ja : en;
const elem = (tag, cls = '', txt = '') => { const e = document.createElement(tag); e.className = cls; e.textContent = txt; return e; };
const fmt = (n) => n.toLocaleString(cfg.lang);
const dialog = $('dialog');
let table = null, dealer = -1, stacks = [], handNo = 0, finished = false, timer = 0, wager = 0, champion = -1, pendingResult = false;
const fx = createEffects(() => cfg, releasePresentation);
const unlock = fx.unlock;
const names = ['', 'MILO', 'LUNA', 'NOVA', 'SAGE', 'OTTO'];
const icons = ['●', '◆', '✦', '▲', '◇', '◈'];
const name = (seat) => seat === 0 ? tr('あなた', 'You') : names[seat];
const modeName = () => ({ free: tr('フリープレイ', 'Free play'), tournament: tr('トーナメント', 'Tournament'), practice: tr('練習', 'Practice') })[cfg.mode];
const levelName = () => ({ easy: tr('初級', 'Beginner'), medium: tr('中級', 'Intermediate'), hard: tr('上級', 'Advanced') })[cfg.level];
const ranksJa = ['ハイカード', 'ワンペア', 'ツーペア', 'スリーカード', 'ストレート', 'フラッシュ', 'フルハウス', 'フォーカード', 'ストレートフラッシュ', 'ロイヤルフラッシュ'];
const ranksEn = ['High card', 'One pair', 'Two pair', 'Three of a kind', 'Straight', 'Flush', 'Full house', 'Four of a kind', 'Straight flush', 'Royal flush'];
function rankName(r) { return (cfg.lang === 'ja' ? ranksJa : ranksEn)[r.score[0] === 8 && r.score[1] === 14 ? 9 : r.score[0]]; }
function cardText(c) { return ('23456789TJQKA'[rankOf(c) - 2] === 'T' ? '10' : '23456789TJQKA'[rankOf(c) - 2]) + '♠♥♣♦'[suitOf(c)]; }
const suitPaths = [
    'M12 2C9 7 2 10 2 15a5 5 0 0 0 9 3c-.3 3-1.3 4-3 5h8c-1.7-1-2.7-2-3-5a5 5 0 0 0 9-3C22 10 15 7 12 2Z',
    'M12 22 3.7 13.5C-2 7.4 5.4 1 12 7c6.6-6 14 .4 8.3 6.5Z',
    'M12 2a5 5 0 0 1 4.5 7.2 5.5 5.5 0 1 1-3.2 9.5c.4 2 1.3 3.3 3 4.3H7.7c1.7-1 2.6-2.3 3-4.3a5.5 5.5 0 1 1-3.2-9.5A5 5 0 0 1 12 2Z',
    'M12 1 22 12 12 23 2 12Z',
];
function suitMark(suit) {
    const ns = 'http://www.w3.org/2000/svg', svg = document.createElementNS(ns, 'svg'), path = document.createElementNS(ns, 'path');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    svg.classList.add('suit-mark');
    path.setAttribute('d', suitPaths[suit]);
    path.setAttribute('fill', 'currentColor');
    svg.append(path);
    return svg;
}
function card(c, back = false, best = false) {
    const e = elem('span', 'card' + (best ? ' best' : '') + (back ? ' back' : c === null ? ' empty' : ''));
    if (back) {
        e.append(elem('span', 'back-monogram', 'P'));
        e.setAttribute('aria-label', tr('裏向き', 'Face down'));
        e.setAttribute('role', 'img');
    }
    else if (c !== null) {
        const t = cardText(c), r = t.slice(0, -1), s = suitOf(c);
        e.dataset.card = String(c);
        e.classList.toggle('red', s % 2 === 1);
        e.setAttribute('aria-label', t);
        e.setAttribute('role', 'img');
        const top = elem('span', 'rank-corner', r), bottom = elem('span', 'rank-corner reverse', r);
        const court = rankOf(c);
        if (court >= 11 && court <= 13) {
            e.classList.add('court');
            e.append(elem('span', 'court-engraving', court === 13 ? '♔' : court === 12 ? '♕' : '♞'));
        }
        e.append(top, suitMark(s), bottom);
    }
    else
        e.setAttribute('aria-hidden', 'true');
    return e;
}
function btn(txt, fn, cls = '', disabled = false) { const b = elem('button', cls, txt); b.type = 'button'; b.disabled = disabled; b.onclick = fn; return b; }
const positions = { 2: [[50, 85], [50, 14]], 3: [[50, 85], [25, 15], [75, 15]], 4: [[50, 85], [14, 50], [50, 14], [86, 50]], 5: [[50, 85], [14, 55], [29, 14], [71, 14], [86, 55]], 6: [[50, 85], [14, 55], [22, 15], [50, 12], [78, 15], [86, 55]] };
function record(t) {
    const hero = t.moves.filter(x => x.seat === 0 && x.street === 'preflop');
    const won = t.awards.reduce((sum, a) => sum + (a.shares[0] || 0), 0);
    stats.hands++;
    if (won)
        stats.wins++;
    if (t.result === 'showdown' && t.ranks[0]) {
        stats.showdowns++;
        if (won)
            stats.showdownWins++;
    }
    if (hero.some(m => m.paid > 0))
        stats.vpip++;
    if (hero.some(m => m.to > m.previous))
        stats.pfr++;
    let raises = 0, opportunity = false, three = false;
    for (const m of t.moves.filter(m => m.street === 'preflop')) {
        if (m.seat === 0 && raises === 1 && m.previous > m.to - m.paid) {
            opportunity = true;
            if (m.to > m.previous)
                three = true;
        }
        if (m.to > m.previous)
            raises++;
    }
    stats.opportunities += Number(opportunity);
    stats.three += Number(three);
    stats.largest = Math.max(stats.largest, won);
    stats.history.unshift({ id: stats.hands, board: [...t.board], hole: [...t.players[0].hole], awards: t.awards.flatMap(a => a.winners.map(seat => ({ seat, chips: a.shares[seat] }))), won, role: t.ranks[0]?.score.join(',') ?? '' });
    stats.history = stats.history.slice(0, 40);
    stats.reads = [...stats.reads, ...t.moves.filter(m => m.seat === 0).map(m => ({ seat: m.seat, aggressive: m.to > m.previous }))].slice(-100);
    save();
}
function start() {
    clearTimeout(timer);
    unlock();
    let previousBB = -1;
    if (table && finished) {
        stacks = table.players.map(p => p.stack);
        dealer = table.dealer;
        if (cfg.mode === 'tournament' && stacks.filter(x => x > 0).length === 2 && table.players.filter(x => x.hole.length).length > 2)
            previousBB = table.bbSeat;
    }
    if (!table)
        stacks = Array(cfg.seats).fill(cfg.buy);
    if (cfg.mode !== 'tournament')
        stacks = stacks.map(x => x || cfg.buy);
    if (stacks.filter(x => x > 0).length < 2)
        return;
    if (previousBB >= 0) {
        const seats = stacks.map((_, i) => (previousBB + 1 + i) % stacks.length).filter(i => stacks[i] > 0);
        dealer = (seats[1] - 1 + stacks.length) % stacks.length;
    }
    const scale = cfg.mode === 'tournament' ? 2 ** Math.min(20, Math.floor(handNo / 5)) : 1;
    table = new Table(stacks, dealer, cfg.sb * scale, cfg.bb * scale);
    handNo++;
    finished = false;
    wager = 0;
    champion = -1;
    pendingResult = table.street === 'done' && table.board.length > 0;
    refresh();
    const elapsed = fx.deal(table.order(table.dealer).filter(i => table.players[i].hole.length), [...table.players[0].hole]);
    if (table.board.length)
        playBoard([], elapsed);
    else if (finished)
        celebrate();
    scheduleAI();
}
function reset() { clearTimeout(timer); table = null; dealer = -1; stacks = []; handNo = 0; finished = false; champion = -1; start(); }
function move(action, to) {
    if (!table || table.actor < 0)
        return;
    if (table.actor === 0 && fx.remaining() > 0) {
        fx.clear();
        $('status').textContent = tr('カードを公開しました。アクションを選んでください。', 'Cards revealed. Choose your action.');
        return;
    }
    const i = table.actor, l = table.legal(i);
    if (!l)
        return;
    unlock();
    if (action === 'raise' && (!Number.isSafeInteger(to) || to < l.min || to > l.max)) {
        $('status').textContent = tr('ベット額の範囲', 'Valid amount') + ' ' + fmt(l.min) + '–' + fmt(l.max);
        return;
    }
    const oldBoard = [...table.board];
    table.act(i, action, to);
    pendingResult = table.street === 'done' && table.board.length > oldBoard.length;
    refresh();
    fx.action(table.moves.at(-1));
    if (table.board.length > oldBoard.length)
        playBoard(oldBoard);
    else if (finished)
        celebrate();
    scheduleAI();
}
function playBoard(oldBoard, offset = 0) {
    if (!table)
        return;
    const t = table;
    let previous = oldBoard;
    for (const count of [3, 4, 5])
        if (count > oldBoard.length && count <= t.board.length) {
            const visible = t.board.slice(0, count);
            offset += fx.board(t.players[0].folded ? [] : [...t.players[0].hole], visible, previous, offset);
            previous = visible;
        }
    if (finished) {
        const finish = () => {
            if (table !== t)
                return;
            pendingResult = false;
            render();
            celebrate();
        };
        if (offset)
            fx.after(finish, offset + 45);
        else
            finish();
    }
}
function celebrate() {
    if (!table)
        return;
    const t = table;
    const winners = t.players.flatMap((_, seat) => {
        const amount = t.awards.reduce((n, p) => n + (p.shares[seat] || 0), 0);
        return amount ? [{ seat, amount }] : [];
    });
    fx.award(winners, t.bb, champion);
}
function refresh() {
    clearTimeout(timer);
    if (table?.street === 'done' && !finished) {
        finished = true;
        if (table.players[0].hole.length)
            record(table);
        if (cfg.mode === 'tournament') {
            const alive = table.players.flatMap((p, i) => p.stack > 0 ? [i] : []);
            if (alive.length === 1) {
                champion = alive[0];
                if (champion === 0) {
                    stats.trophies++;
                    save();
                }
            }
        }
    }
    render();
    scheduleAI();
}
function releasePresentation() {
    if (pendingResult) {
        pendingResult = false;
        render();
    }
    scheduleAI();
}
function scheduleAI() {
    clearTimeout(timer);
    if (!dialog.open && table && table.actor > 0) {
        timer = window.setTimeout(() => {
            if (!table || table.actor <= 0 || dialog.open)
                return;
            const decision = choose(viewForAI(table, table.actor), cfg.level, stats.reads);
            move(decision.action, decision.to);
        }, Math.ceil(fx.remaining()) + 580);
    }
}
const actionName = (a) => ({ fold: tr('フォールド', 'Fold'), check: tr('チェック', 'Check'), call: tr('コール', 'Call'), raise: tr('レイズ', 'Raise'), allin: tr('オールイン', 'All-in') })[a];
function displayStack(seat) {
    if (!table)
        return cfg.buy;
    const stack = table.players[seat].stack;
    if (!pendingResult)
        return stack;
    return stack - (table.refunds[seat] ?? 0) - table.awards.reduce((n, a) => n + (a.shares[seat] ?? 0), 0);
}
function render() {
    document.documentElement.lang = cfg.lang;
    document.documentElement.dataset.effects = cfg.intensity;
    $('records').textContent = tr('戦績', 'Records');
    $('help').textContent = tr('遊び方', 'Guide');
    $('lang').textContent = tr('EN', '日本語');
    $('setup').textContent = tr('テーブル設定', 'Table settings');
    $('disclaimer').textContent = tr('無料プレイ · 仮想チップのみ', 'Free play · Virtual chips only');
    $('volume-label').textContent = tr('効果音', 'SFX');
    $('mute').textContent = cfg.muted ? tr('効果音消音中', 'SFX muted') : tr('効果音消音', 'Mute SFX');
    $('volume').value = String(cfg.volume);
    $('effects-label').textContent = tr('演出', 'Effects');
    $('skip-fx').textContent = tr('演出をスキップ', 'Skip effects');
    const mode = $('effects-mode');
    [tr('フル演出', 'Full'), tr('標準演出', 'Standard'), tr('軽量演出', 'Light'), tr('演出OFF', 'Off')].forEach((title, i) => mode.options[i].textContent = title);
    mode.value = cfg.intensity;
    $('music-label').textContent = 'BGM';
    $('music-mute').textContent = cfg.musicMuted ? tr('BGM消音中', 'Music muted') : tr('BGM消音', 'Mute music');
    $('music-volume').value = String(cfg.music);
    const seats = $('seats'), board = $('board'), actions = $('actions'), t = table, l = t?.actor === 0 ? t.legal() : null;
    const displayFinished = finished && !pendingResult;
    const reveal = displayFinished && t?.result === 'showdown';
    const winner = reveal ? t?.ranks[0] : undefined, best = new Set(winner?.cards ?? []);
    const pos = positions[cfg.seats];
    seats.replaceChildren();
    board.replaceChildren();
    actions.replaceChildren();
    $('level').textContent = modeName() + ' · ' + levelName() + ' · ' + fmt(t?.sb ?? cfg.sb) + ' / ' + fmt(t?.bb ?? cfg.bb);
    $('pot').replaceChildren(elem('span', 'chip', '♠'), document.createTextNode(tr('ポット ', 'Pot ') + fmt(t?.pot ?? 0)));
    const street = { preflop: 'PREFLOP', flop: 'FLOP', turn: 'TURN', river: 'RIVER', done: 'RESULT' };
    $('street').textContent = t ? 'HAND ' + handNo + ' · ' + street[t.street] : 'VIRTUAL CHIPS';
    for (let j = 0; j < 5; j++)
        board.append(card(t?.board[j] ?? null, false, best.has(t?.board[j] ?? -1)));
    pos.forEach(([x, y], i) => {
        const p = t?.players[i], s = elem('div', 'seat');
        s.dataset.seat = String(i);
        s.style.left = x + '%';
        s.style.top = y + '%';
        if (i === 0)
            s.classList.add('hero-seat');
        s.classList.toggle('active', t?.actor === i);
        s.classList.toggle('folded', !!p?.folded);
        s.classList.toggle('winner', displayFinished && !!t?.awards.some(a => a.winners.includes(i)));
        const title = elem('strong');
        title.append(elem('span', 'avatar', icons[i]), document.createTextNode(name(i)));
        if (i > 0) {
            title.title = styles[(i - 1) % styles.length].name[cfg.lang === 'ja' ? 0 : 1];
        }
        if (i === t?.dealer)
            title.append(elem('span', 'badge', 'D'));
        if (i === t?.sbSeat)
            title.append(elem('span', 'badge', 'SB'));
        if (i === t?.bbSeat)
            title.append(elem('span', 'badge', 'BB'));
        const hand = elem('div', i === 0 ? 'hand hero-cards' : 'hand');
        for (let j = 0; j < 2; j++) {
            const c = p?.hole[j] ?? null, show = i === 0 || reveal && !p?.folded;
            hand.append(card(show ? c : null, !show && c !== null, show && i === 0 && best.has(c ?? -1)));
        }
        const m = t?.moves.slice().reverse().find(x => x.seat === i && x.street === t.street);
        const detail = p?.hole.length === 0 ? tr('脱落', 'Out') : p?.folded ? tr('フォールド', 'Folded') : reveal && t?.ranks[i] ? rankName(t.ranks[i]) : p?.stack === 0 ? tr('オールイン', 'All-in') : m ? actionName(m.action) : i === 0 ? tr('プレイヤー', 'Player') : 'CPU';
        const stack = elem('small', 'seat-stack');
        stack.append(elem('span', 'mini-chip'), document.createTextNode(fmt(displayStack(i)) + ' · ' + detail));
        s.append(title, hand, stack);
        seats.append(s);
    });
    $('stack').textContent = tr('残り ', 'Stack ') + fmt(displayStack(0));
    $('call').textContent = tr('コール ', 'To call ') + (l ? fmt(l.call) : '—');
    $('turn-label').textContent = l ? tr('あなたの手番', 'YOUR TURN') : displayFinished ? tr('ハンド結果', 'HAND RESULT') : tr('テーブル', 'THE TABLE');
    $('wager').hidden = !l?.raise || l.max < l.min;
    const status = $('status');
    status.replaceChildren();
    if (!t) {
        status.textContent = tr('PIPがご案内します。テーブルへどうぞ。', 'Pip is your dealer. Take a seat.');
        actions.append(btn(tr('対戦を開始', 'Start playing'), start, 'primary'));
        return;
    }
    if (pendingResult) {
        status.textContent = tr('コミュニティカードを公開中…', 'Revealing the community cards…');
        return;
    }
    if (displayFinished) {
        const result = t.awards.map((a, i) => (i ? tr('サイド ', 'Side ') + i : tr('メイン', 'Main')) + ' · ' + a.winners.map(j => name(j) + ' +' + fmt(a.shares[j])).join(' / '));
        const refunds = Object.entries(t.refunds).map(([i, n]) => name(Number(i)) + ' +' + fmt(n));
        status.append(elem('div', '', champion >= 0 ? name(champion) + tr('が優勝！', ' wins the tournament!') : t.result === 'fold' ? tr('フォールドで決着', 'Won by fold') : tr('ショーダウン', 'Showdown')), elem('div', 'result-list', result.join('　')));
        if (refunds.length)
            status.append(elem('div', 'result-list', tr('未コール分を返却 ', 'Uncalled bet returned ') + refunds.join(' / ')));
        if (winner && cfg.mode === 'practice')
            status.append(elem('div', 'result-list', rankName(winner) + ' · ' + winner.cards.map(cardText).join(' ') + ' · ' + tr('この5枚が最強の組み合わせ', 'These are your strongest five cards')));
        const ended = cfg.mode === 'tournament' && champion >= 0;
        actions.append(btn(ended ? tr('新しい大会', 'New tournament') : tr('次のハンド', 'Next hand'), ended ? setup : start, 'primary'));
        return;
    }
    if (!l) {
        status.textContent = name(t.actor) + tr('が考え中…', ' is thinking…');
        return;
    }
    status.textContent = cfg.mode === 'practice' ? (l.due ? tr('コールは同額を出す。降りるならフォールド。', 'Call to match the bet, or fold to leave the hand.') : tr('チェックならチップを出さずに手番を渡せます。', 'Check to pass without committing chips.')) : l.due ? tr('ベットに応じるか、降りるかを選択', 'Respond to the current bet') : tr('チェックまたはベット', 'Check or bet');
    const current = l.due ? 'call' : 'check';
    actions.append(btn(tr('フォールド', 'Fold') + ' [F]', () => move('fold')), btn(actionName(current) + (l.due ? ' ' + fmt(l.call) : '') + ' [C]', () => move(current), 'primary'));
    if (l.raise && l.max >= l.min) {
        wager = l.min;
        const range = $('slider'), amount = $('amount');
        for (const e of [range, amount]) {
            e.min = String(l.min);
            e.max = String(l.max);
            e.value = String(wager);
            e.step = '1';
        }
        $('amount-label').textContent = tr('合計額', 'Total to');
        range.oninput = () => { wager = Number(range.value); amount.value = range.value; };
        amount.oninput = () => { wager = amount.valueAsNumber; if (Number.isFinite(wager))
            range.value = amount.value; };
        actions.append(btn((t.high ? tr('レイズ', 'Raise') : tr('ベット', 'Bet')) + ' [R]', () => move('raise', wager)));
    }
    if (l.allin)
        actions.append(btn(tr('オールイン', 'All-in'), () => move('allin'), 'danger'));
}
function open(title) { clearTimeout(timer); $('dialog-title').textContent = title; $('dialog-body').replaceChildren(); if (!dialog.open)
    dialog.showModal(); return $('dialog-body'); }
function setup() {
    const body = open(tr('テーブル設定', 'Table settings')), form = elem('form');
    function select(label, opts, value) { const s = elem('select'); for (const [key, title] of opts) {
        const o = elem('option', '', title);
        o.value = key;
        s.add(o);
    } s.value = value; const l = elem('label', '', label); l.append(s); form.append(l); return s; }
    function number(label, value, min, max) { const x = elem('input'); x.type = 'number'; x.inputMode = 'numeric'; x.value = String(value); x.min = String(min); x.max = String(max); x.required = true; const l = elem('label', '', label); l.append(x); form.append(l); return x; }
    const mode = select(tr('モード', 'Mode'), [['free', tr('フリープレイ', 'Free play')], ['tournament', tr('トーナメント', 'Tournament')], ['practice', tr('練習', 'Practice')]], cfg.mode);
    const count = select(tr('席数（自分を含む）', 'Seats including you'), ['2', '3', '4', '5', '6'].map(x => [x, x]), String(cfg.seats));
    const level = select(tr('AI難易度', 'AI difficulty'), [['easy', tr('初級', 'Beginner')], ['medium', tr('中級', 'Intermediate')], ['hard', tr('上級', 'Advanced')]], cfg.level);
    const speed = select(tr('カード配布速度', 'Deal speed'), [['slow', tr('ゆっくり', 'Slow')], ['standard', tr('標準', 'Standard')], ['fast', tr('高速', 'Fast')]], cfg.dealSpeed);
    const sb = number(tr('スモールブラインド', 'Small blind'), cfg.sb, 1, 50000), bb = number(tr('ビッグブラインド', 'Big blind'), cfg.bb, 2, 100000), buy = number(tr('初期スタック', 'Starting stack'), cfg.buy, 2, 1000000);
    form.append(elem('p', 'shortcuts', tr('大会では5ハンドごとにブラインドが2倍になります。この設定で開始すると現在の卓を離れます。', 'Tournament blinds double every five hands. Starting here leaves the current table.')));
    const submit = elem('button', 'primary', tr('この設定で開始', 'Start with these settings'));
    submit.type = 'submit';
    form.append(submit);
    form.oninput = () => { bb.setCustomValidity(''); buy.setCustomValidity(''); };
    form.onsubmit = e => {
        e.preventDefault();
        if (bb.valueAsNumber <= sb.valueAsNumber) {
            bb.setCustomValidity(tr('SBより大きくしてください。', 'Enter a value greater than the small blind.'));
            bb.reportValidity();
            return;
        }
        if (buy.valueAsNumber < bb.valueAsNumber) {
            buy.setCustomValidity(tr('BB以上にしてください。', 'Enter at least one big blind.'));
            buy.reportValidity();
            return;
        }
        cfg = { ...cfg, seats: Number(count.value), mode: mode.value, level: level.value, dealSpeed: speed.value, sb: sb.valueAsNumber, bb: bb.valueAsNumber, buy: buy.valueAsNumber };
        save();
        dialog.close();
        reset();
    };
    body.append(form);
}
function guide() {
    const body = open(tr('PIPのポーカーガイド', 'Pip’s poker guide'));
    body.append(elem('p', '', tr('手札2枚と場の最大5枚から、最も強い5枚を選びます。相手が全員降りても勝利です。', 'Use the strongest five cards from your two hole cards and up to five shared cards. You also win when all opponents fold.')));
    body.append(elem('p', '', tr('チェックはベットなしで手番を渡す、コールは現在額に合わせる、フォールドは降りる、ベット／レイズは賭け額を増やす操作です。オールインでは残りをすべて出します。', 'Check passes without betting. Call matches the bet, fold gives up the hand, and bet or raise increases the wager. All-in commits your remaining chips.')));
    body.append(elem('p', '', tr('PC操作：Fでフォールド、Cでチェック／コール、Rで入力額をベット／レイズ。', 'Keyboard: F folds, C checks or calls, and R bets or raises to the entered total.')));
    const ol = elem('ol');
    for (const r of [...(cfg.lang === 'ja' ? ranksJa : ranksEn)].reverse())
        ol.append(elem('li', '', r));
    body.append(ol);
}
function records() {
    const body = open(tr('戦績とハンド履歴', 'Records & hand history'));
    const pct = (n, d) => d ? (100 * n / d).toFixed(1) + '% (' + n + '/' + d + ')' : '—';
    const entries = [[tr('総プレイハンド数', 'Hands played'), fmt(stats.hands)], [tr('勝利ハンド数', 'Hands won'), fmt(stats.wins)], [tr('ショーダウン勝率', 'Showdown win rate'), pct(stats.showdownWins, stats.showdowns)], ['VPIP', pct(stats.vpip, stats.hands)], ['PFR', pct(stats.pfr, stats.hands)], [tr('3ベット率', '3-bet rate'), pct(stats.three, stats.opportunities)], [tr('1ハンドの最大受取額', 'Largest hand payout'), fmt(stats.largest)], [tr('トーナメント優勝', 'Tournament wins'), fmt(stats.trophies)]];
    for (const [label, value] of entries) {
        const row = elem('div', 'stat-row');
        row.append(elem('span', '', label), elem('strong', '', value));
        body.append(row);
    }
    body.append(elem('p', 'shortcuts', tr('完了したハンドを集計。ポットを一部でも獲得すれば勝利。ショーダウン勝率の分母は自分がショーダウンした回数。VPIPはプリフロップでブラインド以外を払ったハンド、PFRはプリフロップで増額したハンド。3ベット率は最初のレイズに直面した機会のうち再レイズした割合。', 'Completed hands only. Winning any pot share counts as a win. Showdown win rate uses hands you reached showdown. VPIP counts voluntary preflop payments; PFR counts preflop increases. 3-bet rate uses hands where you faced the first preflop raise.')));
    body.append(elem('h3', '', tr('最近40ハンド', 'Last 40 hands')));
    for (const h of stats.history) {
        const d = elem('details');
        const role = h.role ? rankName({ score: h.role.split(',').map(Number), cards: [] }) : '—';
        d.append(elem('summary', '', '#' + h.id + ' · ' + h.hole.map(cardText).join(' ') + ' · ' + role + ' · +' + fmt(h.won)), elem('p', '', 'BOARD: ' + (h.board.map(cardText).join(' ') || '—')), elem('p', '', h.awards.map(x => name(x.seat) + ' +' + fmt(x.chips)).join(' / ')));
        body.append(d);
    }
}
$('setup').onclick = setup;
$('help').onclick = guide;
$('records').onclick = records;
$('close').onclick = () => dialog.close();
dialog.onclose = () => { if (!fx.remaining())
    render(); scheduleAI(); };
$('lang').onclick = () => { cfg.lang = cfg.lang === 'ja' ? 'en' : 'ja'; save(); if (fx.remaining()) {
    fx.clear();
    pendingResult = false;
} render(); scheduleAI(); };
$('mute').onclick = () => { cfg.muted = !cfg.muted; unlock(); save(); if (fx.remaining()) {
    fx.clear();
    pendingResult = false;
} render(); scheduleAI(); };
$('volume').oninput = e => { cfg.volume = Number(e.target.value); save(); };
$('effects-mode').onchange = e => { cfg.intensity = e.target.value; fx.clear(); document.documentElement.dataset.effects = cfg.intensity; save(); releasePresentation(); };
$('music-mute').onclick = () => { cfg.musicMuted = !cfg.musicMuted; unlock(); fx.music(); save(); if (fx.remaining()) {
    fx.clear();
    pendingResult = false;
} render(); scheduleAI(); };
$('music-volume').oninput = e => { cfg.music = Number(e.target.value); unlock(); fx.music(); save(); };
document.addEventListener('keydown', e => {
    if (e.repeat || e.altKey || e.ctrlKey || e.metaKey || dialog.open || e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement || table?.actor !== 0)
        return;
    const l = table.legal();
    if (!l)
        return;
    const key = e.key.toLowerCase();
    if (key === 'f')
        move('fold');
    if (key === 'c')
        move(l.due ? 'call' : 'check');
    if (key === 'r' && l.raise && l.max >= l.min)
        move('raise', wager);
});
render();
