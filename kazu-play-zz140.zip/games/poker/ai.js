import { compare, evaluate, rankOf, secureInt, suitOf } from './engine.js';
export const styles = [
    { name: ['堅実・攻撃型', 'Tight aggressive'], tight: .055, aggression: .73 },
    { name: ['大胆・攻撃型', 'Loose aggressive'], tight: -.055, aggression: .87 },
    { name: ['堅実・慎重型', 'Tight passive'], tight: .075, aggression: .28 },
    { name: ['大胆・慎重型', 'Loose passive'], tight: -.04, aggression: .40 },
];
function opening(a, b) {
    const hi = Math.max(rankOf(a), rankOf(b)), lo = Math.min(rankOf(a), rankOf(b));
    if (hi === lo)
        return .48 + hi / 38;
    return .22 + (hi - 2) * .025 + (lo - 2) * .012 + (suitOf(a) === suitOf(b) ? .058 : 0) + (hi - lo <= 2 ? .05 : 0);
}
function equity(view, iterations, readRanges) {
    const unavailable = new Set([...view.hole, ...view.board]);
    const pool = Array.from({ length: 52 }, (_, c) => c).filter(c => !unavailable.has(c));
    const opponents = view.players.flatMap((p, i) => i !== view.seat && !p.folded ? [i] : []);
    let equity = 0;
    for (let trial = 0; trial < iterations; trial++) {
        const remaining = [...pool];
        const draw = () => remaining.splice(secureInt(remaining.length), 1)[0];
        const hands = opponents.map(seat => {
            const raises = view.moves.filter(m => m.seat === seat && m.to > m.previous).length;
            const entries = view.moves.filter(m => m.seat === seat && m.street === 'preflop' && m.paid > 0).length;
            let a = draw(), b = draw();
            if (readRanges && (raises || entries) && opening(a, b) < (raises ? .54 : .44) && secureInt(100) < 65) {
                remaining.push(a, b);
                a = draw();
                b = draw();
            }
            return [a, b];
        });
        const board = [...view.board];
        while (board.length < 5)
            board.push(draw());
        const ours = evaluate([...view.hole, ...board]).score;
        let tied = 1, beat = false;
        for (const hand of hands) {
            const d = compare(evaluate([...hand, ...board]).score, ours);
            if (d > 0) {
                beat = true;
                break;
            }
            if (d === 0)
                tied++;
        }
        if (!beat)
            equity += 1 / tied;
    }
    return equity / iterations;
}
export function choose(view, level, history = []) {
    const { legal: l } = view, p = view.players[view.seat];
    const opponents = view.players.filter((p, i) => !p.folded && i !== view.seat).length;
    const style = styles[(view.seat - 1) % styles.length] ?? styles[0];
    const late = (((view.seat - view.dealer + view.players.length - 1) % view.players.length) / (view.players.length - 1));
    const chance = secureInt(1000) / 1000;
    const basic = view.board.length ? (evaluate([...view.hole, ...view.board]).score[0] + 1) / 9 : opening(view.hole[0], view.hole[1]);
    const strength = level === 'easy' ? basic : equity(view, level === 'hard' ? 72 : 28, level === 'hard');
    const odds = l.call / (view.pot + l.call || 1);
    const samples = history.filter(x => x.seat === 0).slice(-60);
    const aggression = samples.length >= 8 ? samples.filter(x => x.aggressive).length / samples.length : .28;
    const pressure = level === 'hard' ? (aggression - .28) * .13 : 0;
    const pos = level === 'easy' ? 0 : (late - .5) * .07;
    const cardSuits = [...view.hole, ...view.board].map(suitOf);
    const drawing = view.board.length >= 3 && view.board.length <= 4 && [0, 1, 2, 3].some(s => cardSuits.filter(x => x === s).length === 4);
    const value = strength > Math.max(level === 'easy' ? .48 : .37, 1 / (opponents + 1) + .10) + style.tight - pos;
    const bluffRate = level === 'easy' ? .01 : level === 'medium' ? .055 : drawing ? .27 : .11;
    if (l.raise && (value && chance < style.aggression || !l.due && chance < bluffRate * style.aggression)) {
        const size = Math.max(l.min, p.bet + l.due + Math.round(view.pot * (level === 'hard' ? (value ? .72 : .47) : .48)));
        if (size <= l.max)
            return { action: 'raise', to: size };
        if (l.allin && value)
            return { action: 'allin' };
    }
    if (!l.due)
        return { action: 'check' };
    if (strength + pos + pressure >= odds + style.tight + (level === 'easy' ? .1 : .025))
        return { action: 'call' };
    return { action: 'fold' };
}
