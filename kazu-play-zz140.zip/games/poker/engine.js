export const rankOf = (card) => card % 13 + 2;
export const suitOf = (card) => Math.floor(card / 13);
export function compare(a, b) {
    for (let i = 0; i < Math.max(a.length, b.length); i++) {
        const d = (a[i] ?? 0) - (b[i] ?? 0);
        if (d)
            return Math.sign(d);
    }
    return 0;
}
function five(cards) {
    const ranks = cards.map(rankOf).sort((a, b) => b - a);
    const groups = [...new Set(ranks)].map(r => [ranks.filter(x => x === r).length, r]).sort((a, b) => b[0] - a[0] || b[1] - a[1]);
    const flush = cards.every(c => suitOf(c) === suitOf(cards[0]));
    const straight = groups.length === 5 ? ranks[0] - ranks[4] === 4 ? ranks[0] : ranks.join(',') === '14,5,4,3,2' ? 5 : 0 : 0;
    if (flush && straight)
        return [8, straight];
    if (groups[0][0] === 4)
        return [7, groups[0][1], groups[1][1]];
    if (groups[0][0] === 3 && groups[1][0] === 2)
        return [6, groups[0][1], groups[1][1]];
    if (flush)
        return [5, ...ranks];
    if (straight)
        return [4, straight];
    if (groups[0][0] === 3)
        return [3, ...groups.map(g => g[1])];
    if (groups[0][0] === 2)
        return [groups[1][0] === 2 ? 2 : 1, ...groups.map(g => g[1])];
    return [0, ...ranks];
}
export function evaluate(cards) {
    if (cards.length < 5 || cards.length > 7 || new Set(cards).size !== cards.length || cards.some(c => !Number.isInteger(c) || c < 0 || c > 51))
        throw new Error('Invalid cards');
    let best = { score: [-1], cards: [] };
    const visit = (from, picked) => {
        if (picked.length === 5) {
            const score = five(picked);
            if (compare(score, best.score) > 0)
                best = { score, cards: picked };
            return;
        }
        for (let i = from; i <= cards.length - (5 - picked.length); i++)
            visit(i + 1, [...picked, cards[i]]);
    };
    visit(0, []);
    return best;
}
export function secureInt(bound) {
    if (!Number.isInteger(bound) || bound < 1 || bound > 0x100000000)
        throw new Error('Invalid bound');
    const range = 0x100000000, limit = range - range % bound, buffer = new Uint32Array(1);
    do {
        crypto.getRandomValues(buffer);
    } while (buffer[0] >= limit);
    return buffer[0] % bound;
}
export function shuffledDeck() {
    const cards = Array.from({ length: 52 }, (_, i) => i);
    for (let i = 51; i > 0; i--) {
        const j = secureInt(i + 1);
        [cards[i], cards[j]] = [cards[j], cards[i]];
    }
    return cards;
}
export function makePots(players) {
    const levels = [...new Set(players.map(p => p.total).filter(x => x > 0))].sort((a, b) => a - b);
    let lower = 0;
    return levels.map(level => {
        const contributors = players.flatMap((p, i) => p.total >= level ? [i] : []);
        const amount = (level - lower) * contributors.length;
        lower = level;
        return { amount, eligible: contributors.filter(i => !players[i].folded) };
    });
}
export class Table {
    sb;
    bb;
    players;
    board = [];
    street = 'preflop';
    dealer;
    sbSeat;
    bbSeat;
    actor = -1;
    high;
    step;
    moves = [];
    awards = [];
    ranks = {};
    refunds = {};
    result = null;
    #deck;
    constructor(stacks, previousDealer, sb, bb, deck = shuffledDeck()) {
        this.sb = sb;
        this.bb = bb;
        if (stacks.length < 2 || stacks.length > 6 || stacks.some(x => !Number.isSafeInteger(x) || x < 0) || stacks.filter(x => x > 0).length < 2 || !Number.isSafeInteger(sb) || !Number.isSafeInteger(bb) || sb < 1 || bb < sb)
            throw new Error('Invalid table');
        if (deck.length !== 52 || new Set(deck).size !== 52 || deck.some(c => !Number.isInteger(c) || c < 0 || c > 51))
            throw new Error('Invalid deck');
        this.#deck = [...deck];
        this.players = stacks.map(stack => ({ stack, total: 0, bet: 0, folded: stack === 0, hole: [], actedAt: null }));
        this.dealer = this.next(previousDealer, i => !this.players[i].folded);
        const heads = stacks.filter(x => x > 0).length === 2;
        this.sbSeat = heads ? this.dealer : this.next(this.dealer, i => !this.players[i].folded);
        this.bbSeat = this.next(this.sbSeat, i => !this.players[i].folded);
        this.high = bb;
        this.step = bb;
        for (let round = 0; round < 2; round++)
            for (const i of this.order(this.dealer))
                if (!this.players[i].folded)
                    this.players[i].hole.push(this.draw());
        this.pay(this.sbSeat, Math.min(sb, stacks[this.sbSeat]));
        this.pay(this.bbSeat, Math.min(bb, stacks[this.bbSeat]));
        this.advance(this.bbSeat);
    }
    order(from) { return Array.from({ length: this.players.length }, (_, j) => (from + j + 1 + this.players.length) % this.players.length); }
    next(from, match) { return this.order(from).find(match) ?? -1; }
    get pot() { return this.players.reduce((n, p) => n + p.total, 0); }
    live() { return this.players.flatMap((p, i) => p.folded ? [] : [i]); }
    draw() { const c = this.#deck.pop(); if (c === undefined)
        throw new Error('Empty deck'); return c; }
    pay(i, n) { const p = this.players[i]; p.stack -= n; p.bet += n; p.total += n; }
    liveHigh() { return Math.max(0, ...this.players.map(p => p.bet)); }
    legal(i = this.actor) {
        if (i !== this.actor || i < 0 || this.street === 'done')
            return null;
        const p = this.players[i], due = Math.max(0, this.target() - p.bet), max = p.bet + p.stack;
        const raise = this.live().some(j => j !== i && this.players[j].stack > 0) && max > this.high && (p.actedAt === null || this.high - p.actedAt >= this.step);
        return { due, call: Math.min(due, p.stack), min: this.high + this.step, max, raise, allin: p.stack <= due || raise };
    }
    target() { return this.live().filter(i => this.players[i].stack > 0).length < 2 ? this.liveHigh() : this.high; }
    act(i, action, to) {
        const l = this.legal(i);
        if (!l)
            throw new Error('Not your turn');
        const p = this.players[i], previous = this.high;
        let paid = 0;
        if (action === 'fold') {
            p.folded = true;
        }
        else if (action === 'check' && l.due === 0) { /* No chips move. */ }
        else if (action === 'call' && l.due > 0) {
            paid = l.call;
        }
        else if (action === 'allin' && l.allin) {
            paid = p.stack;
        }
        else if (action === 'raise' && l.raise && typeof to === 'number' && Number.isSafeInteger(to) && to >= l.min && to <= l.max) {
            paid = to - p.bet;
        }
        else
            throw new Error('Illegal action');
        this.pay(i, paid);
        if (p.bet > this.high) {
            const increment = p.bet - this.high;
            if (increment >= this.step)
                this.step = increment;
            this.high = p.bet;
        }
        p.actedAt = this.high;
        this.moves.push({ seat: i, street: this.street, action, paid, to: p.bet, previous });
        this.advance(i);
    }
    advance(from) {
        const live = this.live();
        if (live.length === 1) {
            this.finish(live);
            return;
        }
        const active = live.filter(i => this.players[i].stack > 0);
        const target = this.target();
        this.actor = this.next(from, i => active.includes(i) && (this.players[i].bet < target || (active.length > 1 && this.players[i].actedAt === null)));
        if (this.actor !== -1)
            return;
        if (this.street === 'river') {
            this.finish(live);
            return;
        }
        this.draw();
        if (this.street === 'preflop') {
            this.street = 'flop';
            this.board.push(this.draw(), this.draw(), this.draw());
        }
        else {
            this.street = this.street === 'flop' ? 'turn' : 'river';
            this.board.push(this.draw());
        }
        this.players.forEach(p => { p.bet = 0; p.actedAt = null; });
        this.high = 0;
        this.step = this.bb;
        this.advance(this.dealer);
    }
    finish(live) {
        const largest = this.players.map(p => p.total).sort((a, b) => b - a);
        if (largest[0] > largest[1]) {
            const i = this.players.findIndex(p => p.total === largest[0]), refund = largest[0] - largest[1];
            this.players[i].total -= refund;
            this.players[i].stack += refund;
            this.refunds[i] = refund;
        }
        this.result = live.length === 1 ? 'fold' : 'showdown';
        if (this.result === 'showdown')
            for (const i of live)
                this.ranks[i] = evaluate([...this.players[i].hole, ...this.board]);
        const pots = live.length === 1 ? [{ amount: this.pot, eligible: live }] : makePots(this.players);
        for (const pot of pots) {
            const eligible = live.length === 1 ? live : pot.eligible;
            if (!eligible.length)
                throw new Error('Pot without eligible players');
            const best = eligible.reduce((a, b) => this.result === 'showdown' && compare(this.ranks[b].score, this.ranks[a].score) > 0 ? b : a);
            const winners = this.order(this.dealer).filter(i => eligible.includes(i) && (i === best || compare(this.ranks[i].score, this.ranks[best].score) === 0));
            const each = Math.floor(pot.amount / winners.length), extra = pot.amount % winners.length, shares = {};
            winners.forEach((i, j) => { shares[i] = each + Number(j < extra); this.players[i].stack += shares[i]; });
            this.awards.push({ ...pot, winners, shares });
        }
        this.actor = -1;
        this.street = 'done';
    }
}
export function viewForAI(table, i) {
    const legal = table.legal(i);
    if (!legal)
        throw new Error('No AI decision due');
    return { seat: i, hole: [...table.players[i].hole], board: [...table.board], legal: { ...legal },
        players: table.players.map(({ stack, bet, total, folded }) => ({ stack, bet, total, folded })),
        dealer: table.dealer, bb: table.bb, street: table.street, pot: table.pot, moves: table.moves.map(m => ({ ...m })) };
}
