/* Gesture-gated synthesis; capped voices and cancellation after asynchronous resume. */
(function(root){'use strict';
function create({allowed,createContext,onBlocked=()=>{}}){let context=null,ticket=0;const voices=new Set();
async function play(kind='test',detail={}){if(!allowed())return false;const request=++ticket;try{if(!context||context.state==='closed')context=createContext();const c=context;if(c.state!=='running')await c.resume();if(request!==ticket||!allowed()||c!==context||c.state!=='running')return false;
const festive=kind==='clear'||kind==='test',tier=Math.min(4,Math.max(1,Number(detail.combo)||1,Number(detail.lines)||1)),shift=festive?Math.pow(2,(tier-1)/12):1;
const tone=(hz,delay,duration,volume,type='sine',end=hz)=>{if(voices.size>=32)return;const o=c.createOscillator(),g=c.createGain(),at=c.currentTime+.01+delay;o.type=type;o.frequency.setValueAtTime(hz,at);o.frequency.exponentialRampToValueAtTime(Math.max(1,end),at+duration);g.gain.setValueAtTime(.0001,at);g.gain.linearRampToValueAtTime(volume,at+.008);g.gain.exponentialRampToValueAtTime(.0001,at+duration);o.connect(g);g.connect(c.destination);voices.add(o);o.onended=()=>{voices.delete(o);o.disconnect();g.disconnect();};o.start(at);o.stop(at+duration+.02);};
if(festive){[523,659,784,1047,1319,1568,2093].forEach((hz,i)=>{tone(hz*shift,i*.043,.23,.033);tone(hz*2*shift,i*.043,.11,.008);});[1047,1319,1568].forEach(hz=>tone(hz*shift,.27,.46,.019,'triangle'));tone(150,0,.13,.055,'sine',55);if(tier>1)[2093,2637,3136].slice(0,tier-1).forEach((hz,i)=>tone(hz*shift,.37+i*.055,.28,.018));}
else if(kind==='bad')tone(170,0,.13,.025,'triangle',120);else if(kind==='select')tone(740,0,.065,.019);else{tone(660,0,.09,.027);tone(990,.035,.11,.022);}return true;
}catch{if(request===ticket)onBlocked();return false;}}
function stop(){ticket++;for(const o of voices){try{o.stop();}catch{}}voices.clear();const c=context;context=null;if(c&&c.state!=='closed')void c.close().catch(()=>{});}return{play,stop};}
root.BlockRushSound={create};if(typeof module!=='undefined')module.exports={create};})(globalThis);
