(function(root){'use strict';
const ingredients=[
 {id:'lettuce',name:['Garden lettuce','レタス'],color:'#74975a'},
 {id:'tomato',name:['Ripe tomato','トマト'],color:'#c5745c'},
 {id:'cheese',name:['Mellow cheddar','チーズ'],color:'#d5b76b'},
 {id:'ham',name:['Smoked ham','ハム'],color:'#c78d83'},
 {id:'egg',name:['Sunny egg','たまご'],color:'#d4b97b'},
 {id:'cucumber',name:['Crisp cucumber','きゅうり'],color:'#73957b'}
];
const recipes=[
 {id:'garden',name:['Garden morning','朝のガーデン'],layers:['lettuce','tomato'],guest:'rabbit',person:['Luna','ルナ'],line:['Something fresh for my morning walk.','朝のお散歩に、さっぱりしたものを。']},
 {id:'cheddar',name:['Cheddar comfort','ほっとチーズ'],layers:['ham','cheese'],guest:'bear',person:['Theo','テオ'],line:['A warm little lunch, please.','あたたかいランチを、ひとつ。']},
 {id:'sunrise',name:['Sunrise toast','おひさまトースト'],layers:['lettuce','egg'],guest:'cat',person:['Mimi','ミミ'],line:['An egg sandwich makes any day brighter.','たまごのサンドで、いい一日に。']},
 {id:'crunch',name:['Green & crunchy','しゃきしゃきグリーン'],layers:['lettuce','cucumber','cheese'],guest:'rabbit',person:['Olive','オリーブ'],line:['I love a little crunch.','しゃきっとした食感が好きなの。']},
 {id:'classic',name:['The little classic','小さなお店の定番'],layers:['lettuce','ham','tomato'],guest:'dog',person:['Benny','ベニー'],line:['The usual, for my journey home.','帰り道のおともに、いつものを。']},
 {id:'picnic',name:['Picnic pocket','ピクニックサンド'],layers:['cheese','ham','cucumber'],guest:'bear',person:['Hazel','ヘイゼル'],line:['Off to the park. Make it a lovely one!','公園に行くの。楽しみだなあ！']},
 {id:'brunch',name:['Sunday brunch','日曜日のブランチ'],layers:['ham','cheese','egg'],guest:'cat',person:['Jules','ジュール'],line:['A slow morning and a hearty sandwich.','のんびりした朝には、しっかりサンド。']},
 {id:'rainbow',name:['Garden rainbow','畑のにじいろ'],layers:['lettuce','tomato','cucumber','cheese'],guest:'dog',person:['Maple','メープル'],line:['All those garden colours, please.','畑の色を、たっぷりお願い。']},
 {id:'sunclub',name:['Sunny little club','おひさまクラブ'],layers:['lettuce','ham','cheese','egg'],guest:'bear',person:['Otto','オットー'],line:['I have been looking forward to this.','このお店に来るの、楽しみだったんだ。']},
 {id:'house',name:['Pip’s house special','PIPの特製サンド'],layers:['lettuce','ham','tomato','cheese'],guest:'rabbit',person:['Rosie','ロージー'],line:['Your house special, for a special day.','特別な日だから、お店のおすすめを。']}
];
const byId=id=>ingredients.find(i=>i.id===id),recipe=id=>recipes.find(r=>r.id===id);
function toastQuality(heat){if(!Number.isFinite(heat))return 0;if(heat>=.43&&heat<=.65)return 20;if(heat>=.28&&heat<=.82)return 12;return 4;}
function grade(target,layers,heat){const a=target.layers,b=layers;const dp=Array.from({length:a.length+1},()=>Array(b.length+1).fill(0));for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)dp[i][j]=a[i-1]===b[j-1]?dp[i-1][j-1]+1:Math.max(dp[i-1][j],dp[i][j-1]);const exact=a.length===b.length&&a.every((id,i)=>id===b[i]);const food=Math.max(0,Math.round(80*dp[a.length][b.length]/a.length)-Math.max(0,b.length-a.length)*12),toast=toastQuality(heat);return {score:Math.min(100,food+toast),exact,toast,stars:food+toast>=95?3:food+toast>=70?2:1};}
function fresh(order=recipes.map(r=>r.id)){return {version:1,orders:[...order],index:0,results:[],current:{toast:null,layers:[],closed:false},best:0,days:0,lang:'ja',sound:true,music:true,assist:false};}
function clean(raw){const state=fresh();if(!raw||raw.version!==1)return state;state.best=Number.isInteger(raw.best)?Math.max(0,Math.min(1000,raw.best)):0;state.days=Number.isInteger(raw.days)?Math.max(0,Math.min(9999,raw.days)):0;state.lang=raw.lang==='en'?'en':'ja';for(const k of ['sound','music'])state[k]=raw[k]!==false;state.assist=raw.assist===true;if(!Array.isArray(raw.orders)||raw.orders.length!==10||new Set(raw.orders).size!==10||!raw.orders.every(recipe))return state;state.orders=[...raw.orders];if(!Array.isArray(raw.results)||raw.results.length>10)return state;for(let n=0;n<raw.results.length;n++){const r=raw.results[n];if(!r||r.id!==state.orders[n]||!Array.isArray(r.layers)||r.layers.length>6||!r.layers.every(byId)||!Number.isFinite(r.heat)||r.heat<0||r.heat>1)break;state.results.push({id:r.id,layers:[...r.layers],heat:r.heat,...grade(recipe(r.id),r.layers,r.heat)});}state.index=state.results.length;const c=raw.current;if(state.index<10&&c&&Number.isFinite(c.toast)&&c.toast>=0&&c.toast<=1&&Array.isArray(c.layers)&&c.layers.length<=6&&c.layers.every(byId))state.current={toast:c.toast,layers:[...c.layers],closed:c.closed===true};return state;}
function shuffle(random=Math.random){const ids=recipes.map(r=>r.id);for(let i=ids.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[ids[i],ids[j]]=[ids[j],ids[i]];}return ids;}
const api={ingredients,recipes,byId,recipe,grade,toastQuality,fresh,clean,shuffle};root.DinerEngine=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
