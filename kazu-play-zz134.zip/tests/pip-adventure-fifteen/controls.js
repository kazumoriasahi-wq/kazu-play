(function(root){'use strict';
// Each finger/key owns its own input. The newest direction wins during a handover.
function create(doc,{playing,unlock,input,autoDash=()=>false}){
 const pointers=new Map(),keys=new Map(),buttons=[...doc.querySelectorAll('[data-key]')],directions=doc.querySelector('.directions');let order=0;
 const keyMap={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'interact',Space:'jump',ShiftLeft:'dash',ShiftRight:'dash'};
 function update(){const held=[...keys.values(),...pointers.values()];for(const k of ['left','right','jump','dash','interact'])input[k]=false;let direction=null;for(const h of held){if(h.key==='left'||h.key==='right'){if(!direction||h.order>direction.order)direction=h;}else if(h.key)input[h.key]=true;}if(direction)input[direction.key]=true;if(autoDash()&&[...pointers.values()].some(p=>p.directional&&p.key))input.dash=true;buttons.forEach(b=>b.classList.toggle('held',!!input[b.dataset.key]));}
 function releaseCapture(id,p){try{if(p.owner.hasPointerCapture?.(id))p.owner.releasePointerCapture(id);}catch{/* A cancelled or detached pointer may already be released. */}}
 function release(id,cancelled=false){const p=pointers.get(id);if(!p)return false;pointers.delete(id);if(cancelled&&p.key==='jump')input.jumpPressed=false;releaseCapture(id,p);return true;}
 function reset(){const old=[...pointers];keys.clear();pointers.clear();Object.keys(input).forEach(k=>input[k]=false);for(const [id,p] of old)releaseCapture(id,p);update();}
 doc.addEventListener('keydown',e=>{const k=keyMap[e.code];if(!k||!playing()||e.target.matches('select,input,textarea')||doc.querySelector('dialog[open]'))return;e.preventDefault();if(keys.has(e.code))return;if(k==='jump'&&!input.jump)input.jumpPressed=true;keys.set(e.code,{key:k,order:++order});update();});
 doc.addEventListener('keyup',e=>{if(!keyMap[e.code])return;if(playing())e.preventDefault();keys.delete(e.code);update();});
 buttons.forEach(b=>{b.addEventListener('pointerdown',e=>{e.preventDefault();if(!playing())return;unlock();const k=b.dataset.key;if(k==='jump'&&!input.jump)input.jumpPressed=true;pointers.set(e.pointerId,{key:k,order:++order,owner:b,pointerType:e.pointerType||'mouse',directional:k==='left'||k==='right'});update();try{b.setPointerCapture(e.pointerId);}catch{/* Document listeners still release this finger. */}});
 b.addEventListener('lostpointercapture',e=>{if(pointers.get(e.pointerId)?.owner===b){pointers.delete(e.pointerId);update();}});
 b.addEventListener('contextmenu',e=>e.preventDefault());});
 doc.addEventListener('pointermove',e=>{const p=pointers.get(e.pointerId);if(!p)return;if(e.buttons===0){release(e.pointerId);update();return;}if(!p.directional)return;const r=directions.getBoundingClientRect();const middle=(r.left+r.right)/2,inside=e.clientX>=r.left-18&&e.clientX<=r.right+18&&e.clientY>=r.top-32&&e.clientY<=r.bottom+32;const k=inside?(p.key&&Math.abs(e.clientX-middle)<7?p.key:e.clientX<middle?'left':'right'):null;if(k!==p.key){p.key=k;p.order=++order;update();}});
 const end=e=>{if(release(e.pointerId,e.type==='pointercancel'))update();};
 for(const name of ['pointerup','pointercancel']){doc.addEventListener(name,end,true);doc.defaultView?.addEventListener(name,end,true);}
 // Native touch-end fallback: do not depend on receiving every pointerup.
 // Touch.target stays at the original button during a slide; pointer IDs and touch IDs need not match.
 function reconcileTouches(e){if(!e.touches)return;const touches=Array.from(e.touches);let changed=false;
 for(const [id,p] of pointers){if(p.pointerType!=='touch')continue;const active=touches.some(t=>t.target===p.owner||p.owner.contains?.(t.target));if(!active)changed=release(id,e.type==='touchcancel')||changed;}
 if(changed)update();}
 for(const name of ['touchstart','touchmove','touchend','touchcancel'])doc.addEventListener(name,reconcileTouches,{capture:true,passive:true});
 const win=doc.defaultView;if(win){for(const name of ['blur','pagehide','pageshow'])win.addEventListener(name,reset);win.addEventListener('keyup',e=>{if(keyMap[e.code]){keys.delete(e.code);update();}},true);}
 doc.addEventListener('visibilitychange',()=>{if(doc.hidden)reset();});
 return{reset,refresh:update};
}
root.PipControls={create};if(typeof module!=='undefined')module.exports={create};
})(globalThis);
