(function(root){'use strict';
const CATALOG=[
 {id:'books',name:['Travel journals','旅の手帳'],w:2,h:3,color:'#5e8175'},
 {id:'camera',name:['Little camera','小さなカメラ'],w:3,h:2,color:'#b98a57'},
 {id:'jar',name:['Botanical vial','植物標本の小瓶'],w:1,h:3,color:'#7b9b87'},
 {id:'glasses',name:['Field binoculars','双眼鏡'],w:3,h:1,color:'#65848b'},
 {id:'cup',name:['Tea for the journey','旅のお茶カップ'],w:2,h:2,color:'#c6a47b'},
 {id:'tin',name:['Keepsake tin','思い出の缶'],w:2,h:2,color:'#88917f'},
 {id:'lens',name:['Pip’s magnifier','PIPの虫めがね'],w:2,h:2,color:'#b39761'},
 {id:'letters',name:['A letter from home','家からの手紙'],w:2,h:1,color:'#c5a28a'},
 {id:'scarf',name:['A folded scarf','たたんだスカーフ'],w:2,h:1,color:'#bd7e63'},
 {id:'brush',name:['Sketching brushes','スケッチの筆'],w:2,h:1,color:'#9d8c6f'} ,
{id:'teapot',name:['Little teapot','小さなティーポット'],w:3,h:2},
{id:'cookies',name:['Biscuit tray','ビスケットのトレー'],w:3,h:2},
{id:'spoon',name:['Tea spoons','ティースプーン'],w:1,h:3},
{id:'napkin',name:['Linen napkins','リネンのナプキン'],w:2,h:2},
{id:'tea',name:['Tea caddy','紅茶の缶'],w:2,h:2},
{id:'pot',name:['Young seedling','小さな苗'],w:2,h:3},
{id:'gloves',name:['Garden gloves','ガーデニング手袋'],w:2,h:2},
{id:'spade',name:['Hand trowel','小さなスコップ'],w:1,h:3},
{id:'seeds',name:['Seed packets','種の袋'],w:2,h:1},
{id:'watering',name:['Watering can','じょうろ'],w:3,h:2},
{id:'stamp',name:['Postage stamps','切手のブック'],w:1,h:2},
{id:'ink',name:['Ink and pen','インクとペン'],w:1,h:2},
{id:'telescope',name:['Pocket telescope','小さな望遠鏡'],w:1,h:4},
{id:'starbox',name:['Constellation tin','星座の缶'],w:2,h:2},
{id:'map',name:['Star atlas','星の地図'],w:3,h:3},
{id:'basket',name:['Picnic basket','ピクニックかご'],w:3,h:3},
{id:'bottle',name:['Lemon cordial','レモンの水筒'],w:1,h:3}
];
const STAGES=[
{id:'travel',name:['Pip’s travel drawer','PIPの旅じたく'],tag:'THE TRAVELLER’S DRAWER',story:['A new journey begins with a little order.','小さな旅は、旅じたくから。'],level:['Gentle','やさしい'],color:'#3f6555',items:['books','camera','jar','glasses','cup','tin','lens','letters','scarf','brush']},
{id:'tea-time',name:['Tea by the window','窓辺のお茶じかん'],tag:'AFTERNOON TEA',story:['Warm tea, biscuits, and a rainy afternoon.','雨の午後に、紅茶とビスケットを。'],level:['Gentle','やさしい'],color:'#886445',items:['teapot','cookies','cup','tin','letters','spoon','napkin','jar','tea']},
{id:'garden',name:['A little garden','小さな庭しごと'],tag:'THE GARDEN SHED',story:['Pack the tools. New shoots are waiting.','道具をそろえて、新しい芽を迎えよう。'],level:['Thoughtful','じっくり'],color:'#526e44',items:['pot','gloves','jar','spade','seeds','watering','books','scarf','brush','letters']},
{id:'post',name:['Letters from home','旅先への手紙'],tag:'THE WRITING DESK',story:['Letters, stamps, and memories worth keeping.','手紙も切手も、大切にしまって。'],level:['Thoughtful','じっくり'],color:'#725d68',items:['books','camera','tin','lens','glasses','jar','letters','scarf','brush','stamp','ink']},
{id:'stars',name:['An evening of stars','星を見に行こう'],tag:'THE OBSERVATORY',story:['The atlas is big. The night is full of wonders.','大きな星の地図を、どうしまおう？'],level:['A little tricky','ちょっと難しい'],color:'#4c657d',items:['map','telescope','starbox','lens','books','jar','letters','brush','scarf']},
{id:'picnic',name:['Sunday picnic','日曜日のピクニック'],tag:'THE PICNIC CUPBOARD',story:['A big basket, a small drawer, a lovely day ahead.','大きなかごと、小さな引き出し。'],level:['A little tricky','ちょっと難しい'],color:'#8b6751',items:['basket','bottle','teapot','cup','tin','napkin','letters','scarf','brush']}
];
let current=STAGES[0],ITEMS=current.items.map(id=>CATALOG.find(i=>i.id===id));
function setStage(id){current=STAGES.find(s=>s.id===id)||STAGES[0];ITEMS=current.items.map(id=>CATALOG.find(i=>i.id===id));return current;}
const SIZE=6,byId=id=>ITEMS.find(i=>i.id===id),dims=(id,r=0)=>{const i=byId(id);return r%2?[i.h,i.w]:[i.w,i.h]};
function valid(placed,id,x,y,r=0){if(!byId(id)||![x,y,r].every(Number.isInteger)||!([0,1].includes(r)))return false;const[w,h]=dims(id,r);if(x<0||y<0||x+w>SIZE||y+h>SIZE)return false;for(const[k,p]of Object.entries(placed)){if(k===id)continue;const[a,b]=dims(k,p.r);if(x<p.x+a&&x+w>p.x&&y<p.y+b&&y+h>p.y)return false;}return true;}
function clean(doc){const placed={};if(doc&&doc.version===1&&doc.placed&&typeof doc.placed==='object')for(const i of ITEMS){const p=doc.placed[i.id];if(p&&valid(placed,i.id,p.x,p.y,p.r))placed[i.id]={x:p.x,y:p.y,r:p.r};}return{version:1,placed,moves:Number.isInteger(doc?.moves)?Math.max(0,doc.moves):0,hints:Number.isInteger(doc?.hints)?Math.max(0,Math.min(1000,doc.hints)):0,lang:doc?.lang==='en'?'en':'ja',sound:doc?.sound!==false,music:doc?.music!==false};}
function solve(placed,budget=150000){const checked={};for(const[id,p]of Object.entries(placed)){if(!p||!valid(checked,id,p.x,p.y,p.r))return null;checked[id]=p;}const board=Array(36).fill(false);for(const[id,p]of Object.entries(placed)){if(!byId(id))return null;const[w,h]=dims(id,p.r);for(let y=p.y;y<p.y+h;y++)for(let x=p.x;x<p.x+w;x++)board[y*6+x]=true;}let visits=0;const left=ITEMS.filter(i=>!placed[i.id]),out={...placed};function dfs(items){if(++visits>budget)return false;const start=board.indexOf(false);if(start<0)return items.length===0;const x=start%6,y=Math.floor(start/6),seen=new Set();for(let j=0;j<items.length;j++){const it=items[j],sig=[it.w,it.h].sort().join(':');if(seen.has(sig))continue;seen.add(sig);for(let r=0;r<(it.w===it.h?1:2);r++){const[w,h]=dims(it.id,r);if(x+w>6||y+h>6)continue;const cells=[];let ok=true;for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++){const c=yy*6+xx;cells.push(c);if(board[c])ok=false;}if(!ok)continue;cells.forEach(c=>board[c]=true);out[it.id]={x,y,r};if(dfs(items.filter((_,n)=>n!==j)))return true;delete out[it.id];cells.forEach(c=>board[c]=false);}}return false;}return dfs(left)?out:null;}
const api={ITEMS,SIZE,byId,dims,valid,clean,solve};Object.defineProperty(api,'ITEMS',{get:()=>ITEMS});Object.assign(api,{CATALOG,STAGES,setStage,getStage:()=>current});root.CozyEngine=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
