(function(root){'use strict';
function fresh(){return {version:2,mode:'classic',menu:'morning',progress:{},lang:'ja',sound:true,music:true,assist:false};}
function normalize(doc,hosted=false){
 if(!doc||![1,2].includes(doc.version))throw Error('Unsupported diner save');
 const X=root.DinerAtelier,legacy=doc.version===1&&Array.isArray(doc.orders);if(!legacy&&(!doc.progress||typeof doc.progress!=='object'||Array.isArray(doc.progress)))throw Error('Invalid diner book');
 const src=legacy?{...doc,mode:'classic',menu:'morning',progress:{classic:doc}}:doc,out=fresh();out.mode=src.mode==='chef'?'chef':'classic';out.menu=X.menus.some(m=>m.id===src.menu)?src.menu:'morning';out.lang=src.lang==='en'?'en':'ja';out.sound=src.sound!==false;out.music=src.music!==false;out.assist=src.assist===true;
 for(const key of ['classic',...X.menus.map(m=>'chef@'+m.id)]){const raw=src.progress[key];if(!raw)continue;const E=X.engine(key==='classic'?'classic':'chef',key.split('@')[1]);const state=E.clean(raw);if(hosted)delete state.lang;out.progress[key]=state;}
 if(hosted)delete out.lang;return out;
}
root.DinerRecords={fresh,normalize};if(typeof module!=='undefined')module.exports=root.DinerRecords;
})(globalThis);
