(function(root){'use strict';
const solids=[];const rect=(x,y,w,h,kind='ground',id='')=>solids.push({x,y,w,h,kind,id});
[[0,544],[576,1040],[1088,1632],[1680,2320],[2368,3520]].forEach(([a,b])=>rect(a,176,b-a,80));
[[192,144,48],[352,128,64],[448,144,64],[640,144,64],[752,112,64],[864,144,64],[1152,144,64],[1280,112,64],[1440,144,64],[1600,144,48],[1728,128,64],[1840,112,64],[2000,144,80],[2176,128,64],[2432,144,64],[2576,112,64],[2720,144,64],[2896,128,64],[3072,144,64]].forEach(([x,y,w])=>rect(x,y,w,16,'ledge'));
[[272,'star'],[944,'heart'],[2496,'star']].forEach(([x,item],i)=>{rect(x,112,16,16,'box','box'+i);solids.at(-1).item=item;});
const coins=[];function row(x,y,n){for(let i=0;i<n;i++)coins.push({id:'m'+coins.length,x:x+i*20,y});}
row(124,150,4);row(360,102,3);row(652,118,3);row(760,86,3);row(1164,118,3);row(1292,86,3);row(1448,118,3);row(1740,102,3);row(2020,118,3);row(2184,102,3);row(2584,86,3);row(2728,118,3);row(2904,102,3);row(3200,150,5);
const enemies=[{id:'e0',x:450,y:160,a:416,b:520,type:'mushroom'},{id:'e1',x:800,y:160,a:736,b:1008,type:'slime'},{id:'e2',x:1232,y:160,a:1120,b:1408,type:'mushroom'},{id:'e3',x:1520,y:160,a:1440,b:1600,type:'slime'},{id:'e4',x:1940,y:160,a:1872,b:2080,type:'mushroom'},{id:'e5',x:2220,y:160,a:2112,b:2288,type:'slime'},{id:'e6',x:2700,y:160,a:2560,b:2800,type:'mushroom'},{id:'e7',x:3020,y:160,a:2896,b:3160,type:'slime'}];
const main={width:3520,solids,coins,enemies,spawn:{x:64,y:152},goal:{x:3392,y:112,w:48,h:64},checkpoint:{x:1496,y:176},portal:{x:1824,y:152,w:26,h:28}};
const secret={width:480,solids:[{x:0,y:176,w:480,h:80,kind:'ground'},{x:176,y:144,w:64,h:16,kind:'ledge'},{x:288,y:112,w:64,h:16,kind:'ledge'}],coins:Array.from({length:8},(_,i)=>({id:'s'+i,x:128+i*32,y:i>=5?86:(i===2||i===3?118:148)})),enemies:[],spawn:{x:56,y:152},portal:{x:32,y:148,w:24,h:28},treasure:{x:364,y:152,w:20,h:24}};
root.PipWorld={main,secret,coinTotal:coins.length+secret.coins.length,stageNames:[['ひだまりの草原','SUNLIT MEADOW'],['こもれびの森','WHISPERING WOODS'],['星あかりの洞窟','STARLIGHT CAVERN'],['雲の向こうへ','SKYWARD ISLES'],['最後の砦 · ボス戦','THE FINAL BOSS']]};
if(typeof module!=='undefined')module.exports=root.PipWorld;
})(globalThis);
