// Network-only: game updates arrive without stale offline caches.
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  if(event.request.method==='GET'&&event.request.mode==='navigate'){
    event.respondWith(fetch(event.request).catch(()=>new Response('<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>接続を確認</title><body style="font:18px system-ui;padding:32px;background:#f6f3eb;color:#233c39"><h1>また、ひと息あそぼう。</h1><p>通信に接続してから、もう一度開いてください。</p><button onclick="location.reload()">再読み込み</button></body></html>',{headers:{'Content-Type':'text/html;charset=utf-8'}})));
  }
});
