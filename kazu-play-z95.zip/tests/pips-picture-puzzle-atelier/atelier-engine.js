(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.PuzzleAtelier=api;})(typeof window==='object'?window:this,function(){
 'use strict';
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 function boundary(scene,r,c,h){let n=Math.imul(scene+1,2654435761)^Math.imul(r+7,1597334677)^Math.imul(c+11,3812015801)^(h?5323:10909);n^=n>>>16;return{b:(n&1?1:-1)*[.15,.18,.21][(n>>>1)%3],s:[.29,.32,.35][(n>>>5)%3]};}
 function segments(i,C,R,scene){const r=Math.floor(i/C),c=i%C;return[[1,0,r?boundary(scene,r,c,true):null],[0,1,c<C-1?boundary(scene,r,c+1,false):null],[-1,0,r<R-1?boundary(scene,r+1,c,true):null],[0,-1,c?boundary(scene,r,c,false):null]].map(([dx,dy,p],j)=>({dx,dy,b:p?(j>=2?-p.b:p.b):0,s:p?.s||0}));}
 function shape(i,C,R,scene){let p='M0 0';for(const{dx,dy,b,s}of segments(i,C,R,scene)){if(!b){p+=`l${dx} ${dy}`;continue;}const nx=-dy*b,ny=dx*b,w=1-2*s;p+=`l${dx*s} ${dy*s} c${nx} ${ny} ${nx+dx*w} ${ny+dy*w} ${dx*w} ${dy*w} l${dx*s} ${dy*s}`;}return p+'Z';}
 function target(x,y,rect,C,R,clip=rect){if(x<clip.left||y<clip.top||x>=clip.left+clip.width||y>=clip.top+clip.height)return null;if(!rect.width||!rect.height||x<rect.left||y<rect.top||x>=rect.left+rect.width||y>=rect.top+rect.height)return null;return Math.floor((y-rect.top)/rect.height*R)*C+Math.floor((x-rect.left)/rect.width*C);}
 function pan(x,y,w,h,z){return{x:clamp(x,-w*(z-1),0)||0,y:clamp(y,-h*(z-1),0)||0};}
 function valid(r,n){return!!r&&Array.isArray(r.placed)&&new Set(r.placed).size===r.placed.length&&r.placed.every(i=>Number.isInteger(i)&&i>=0&&i<n)&&Array.isArray(r.order)&&r.order.length===n&&new Set(r.order).size===n&&r.order.every(i=>Number.isInteger(i)&&i>=0&&i<n);}
 function stats(raw,hints=3){return{elapsed:Number.isFinite(raw?.elapsed)&&raw.elapsed>=0?raw.elapsed:0,hintUses:Number.isInteger(raw?.hintUses)&&raw.hintUses>=0?raw.hintUses:3-hints,referenceUses:Number.isInteger(raw?.referenceUses)&&raw.referenceUses>=0?raw.referenceUses:0,mistakes:Number.isInteger(raw?.mistakes)&&raw.mistakes>=0?raw.mistakes:0};}
 function medals(s){return[true,s.hintUses===0,s.referenceUses===0];}
 return{shape,segments,boundary,target,pan,valid,stats,medals};
});
