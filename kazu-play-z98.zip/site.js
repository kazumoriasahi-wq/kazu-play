'use strict';
let games=[],filter='すべて',favorites=[];
try{favorites=JSON.parse(localStorage.getItem('kazu_favorites')||'[]');if(!Array.isArray(favorites))favorites=[];}catch{}
const L=window.PipPortalLanguage,say=(ja,en)=>L.pick(ja,en);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const detailsURL=id=>'guides/'+id+'.html?lang='+L.language;
function cover(raw){const g=L.game(raw);return `<div class="cover has-image" style="background:${g.color}"><img loading="lazy" decoding="async" src="covers/${g.cover||g.id}.${g.coverExtension||'jpg'}?v=detective1" alt="${esc(g.imageAlt||g.title+say('のゲーム画面',' game illustration'))}"><span class="number">${String(games.indexOf(raw)+1).padStart(2,'0')} / PIP &amp; PLAY</span></div>`;}
function render(){
 const q=(document.querySelector('#search')?.value||'').trim().toLowerCase();
 const list=games.filter(g=>{const e=L.game(g);return(filter==='すべて'||(filter==='お気に入り'?favorites.includes(g.id):g.category===filter))&&`${g.title} ${g.tag} ${g.description} ${e.title} ${e.tag} ${e.description}`.toLowerCase().includes(q);});
 document.querySelector('#grid').innerHTML=list.map(raw=>{const g=L.game(raw);return `<article class="card"><a href="${detailsURL(g.id)}" aria-label="${esc(say(g.title+'の詳細','Explore '+g.title))}">${cover(raw)}</a><div class="cardmeta"><a href="${detailsURL(g.id)}"><small>${L.category(g.category)}</small><h3>${esc(g.title)}</h3><p>${esc(g.tag)}</p></a><button class="favorite" data-id="${g.id}" aria-label="${esc(say(g.title+'をお気に入りに登録・解除','Toggle favourite: '+g.title))}" aria-pressed="${favorites.includes(g.id)}">${favorites.includes(g.id)?'♥':'♡'}</button></div></article>`;}).join('');
 document.querySelector('#empty').hidden=!!list.length;document.querySelector('#resultCount').textContent=say(list.length+'作品を表示',list.length+' games shown');
}
function renderDetail(raw){const g=L.game(raw),detail=document.querySelector('#detail');if(!detail)return;document.title=g.title+' | PIP & PLAY';detail.innerHTML=`<div class="detailtop">${cover(raw)}<div><p class="eyebrow">${L.category(g.category)} / ORIGINAL GAME</p><h1>${esc(g.title)}</h1><p>${esc(g.description)}</p><a class="button" href="play.html?game=${g.id}&lang=${L.language}">${say('あそぶ','Play now')} <span>↗</span></a><p class="note">${say('無料 · ダウンロード不要 · 音は操作後に再生されます','Free · No download · Audio starts after an interaction')}</p></div></div><section class="instructions"><p><a class=guide-link href="guides/${g.id}.html?lang=${L.language}">${say('ルールと上達のコツを読む','Read the rules and practical tips')} ↗</a></p><h2>${say('あそび方','How to play')}</h2><p>${esc(g.how)}</p><h2>${say('プレイの前に','Before you play')}</h2><p>${say('縦画面がおすすめです。各ゲームの音声ボタンで音を切り替えられます。進行や記録はこの端末のブラウザに保存され、別の端末や以前の公開版とは共有されません。ブラウザのデータ削除で記録も消えます。','Portrait orientation is recommended. Use each game’s audio controls to change the sound. Progress is saved in this browser and is not shared with other devices or earlier published editions. Clearing browser data removes saved progress.')}</p><p>${say('ゲームが開かない場合はページを再読み込みしてください。ホーム画面から開く場合も通信が必要です。','If a game does not load, try reloading the page. An internet connection is required, including when launched from the home screen.')}</p><a href="./?lang=${L.language}#collection">${say('← ほかのゲームを探す','← Explore more games')}</a></section>`;}
async function init(){
 games=await fetch('games.json?v=cozyatelierlive1').then(r=>{if(!r.ok)throw Error();return r.json()});
 if(document.querySelector('#grid')){
  render();document.querySelector('#search').addEventListener('input',render);
  document.querySelectorAll('[data-filter]').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(x=>(x.classList.toggle('selected',x===b),x.setAttribute('aria-pressed',String(x===b))));render()}));
  document.querySelector('#grid').addEventListener('click',e=>{const b=e.target.closest('.favorite');if(!b)return;const id=b.dataset.id;favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];try{localStorage.setItem('kazu_favorites',JSON.stringify(favorites))}catch{}render();document.querySelector(`[data-id="${id}"]`)?.focus();});
 }
 const detail=document.querySelector('#detail'),frame=document.querySelector('#game');let selected;
 if(detail||frame){
  selected=games.find(x=>x.id===new URLSearchParams(location.search).get('game'));
  if(!selected){if(detail)detail.innerHTML='<h1>'+say('ゲームが見つかりません','Game not found')+'</h1><a href="./">'+say('一覧に戻る','All games')+'</a>';else location.replace('./');return;}
  if(frame){if(window.KazuAnalytics)await KazuAnalytics.gameOpen(selected.id,selected.title);location.replace('games/'+selected.id+'/index.html?lang='+L.language+'&v='+(selected.id==='puzzle'?'atelierlive1':selected.id==='cozy'?'atelierlive1':selected.id==='block'?'feverlive1':selected.id==='pip'?'observelive1':selected.id==='sky'?'flowlive1':selected.id==='hop'?'flowlive1':selected.id==='orbit'?'clearlive1':selected.id==='tower'?'atelierlive1':'detective1'));return;}
  renderDetail(selected);
 }
 window.addEventListener('portal-language-change',()=>{if(document.querySelector('#grid'))render();if(selected&&detail)renderDetail(selected);});
}
init().catch(()=>{const el=document.querySelector('#grid')||document.querySelector('#detail');if(el){const p=document.createElement('p');p.className='load-note';p.textContent=say('絞り込みを読み込めませんでした。表示中の作品リンクから遊び方をご覧いただけます。','Filters could not load. You can still use the game links below.');el.before(p);}});
let installPrompt;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;const b=document.querySelector('#install');if(b)b.hidden=false;});document.querySelector('#install')?.addEventListener('click',async()=>{if(installPrompt){await installPrompt.prompt();installPrompt=null;document.querySelector('#install').hidden=true;}});
if('serviceWorker'in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
