(function(root){'use strict';
function normalize(doc,hosted=false){
 if(!doc||doc.version!==2||!doc.progress||typeof doc.progress!=='object'||Array.isArray(doc.progress))throw Error('Unsupported save');
 const E=root.CozyEngine,old=E.getStage().id,out={version:2,current:E.STAGES.some(s=>s.id===doc.current)?doc.current:'travel',mode:doc.mode==='request'?'request':'free',progress:{},stars:{},sound:doc.sound!==false,music:doc.music!==false};
 if(!hosted)out.lang=doc.lang==='ja'?'ja':'en';
 try{for(const st of E.STAGES){E.setStage(st.id);for(const key of [st.id,st.id+'@request']){if(doc.progress[key]){const data=E.clean(doc.progress[key]);if(hosted)delete data.lang;out.progress[key]=data;}const stars=doc.stars?.[key];if(Number.isInteger(stars)&&stars>=1&&stars<=3)out.stars[key]=stars;}}}finally{E.setStage(old);}
 return out;
}
function create(sdk,options={}){
 const hosted=!!sdk&&(sdk.IN_PLAYABLES_ENV===true||options.officialTest===true),store=options.storage||(()=>root.localStorage),key='pip-cozy-sort-playables-v1';let loaded=false,paused=false,audio=!hosted,dirty=false,revision=0,writing=null,value=null,first=false,ready=false,bound=false;const listeners=new Set();
 const emit=(type,v)=>listeners.forEach(fn=>fn(type,v));
 function warn(){if(hosted&&!paused)try{sdk.health.logWarning()}catch{}}
 function active(){return paused?new Promise(resolve=>{const fn=t=>{if(t==='resume'){listeners.delete(fn);resolve()}};listeners.add(fn)}):Promise.resolve()}
 function bind(){if(!hosted||bound)return;bound=true;audio=!!sdk.system.isAudioEnabled();sdk.system.onAudioEnabledChange(v=>{audio=!!v;if(!paused)emit('audio',audio)});sdk.system.onPause(()=>{if(paused)return;paused=true;emit('pause')});sdk.system.onResume(()=>{if(!paused)return;paused=false;emit('resume');void flush()});}
 async function init(){bind();let raw;if(hosted)raw=await sdk.game.loadData();else try{raw=store().getItem(key)}catch{raw=null}if(raw){const parsed=JSON.parse(raw);value=normalize(parsed,hosted)}else value={version:2,current:'travel',progress:{},stars:{},sound:true,music:true};loaded=true;await active();let lang=value.lang||'en';if(hosted){try{lang=String(await sdk.system.getLanguage()).toLowerCase().startsWith('ja')?'ja':'en'}catch{warn()}}await active();return {...value,lang};}
 function save(doc){if(!loaded||paused)return false;value=normalize(doc,hosted);dirty=true;revision++;void flush();return true}
 async function flush(){if(!loaded||paused||!dirty)return !dirty;if(writing)return writing;writing=(async()=>{while(dirty&&!paused){const rev=revision,raw=JSON.stringify(value);try{if(hosted)await sdk.game.saveData(raw);else store().setItem(key,raw)}catch{warn();if(!paused)emit('save-error');return false}if(revision===rev)dirty=false}return !dirty})().finally(()=>writing=null);return writing}
 return {hosted,init,save,flush,whenActive:active,on:fn=>listeners.add(fn),firstFrame(){if(first||paused)return;first=true;if(hosted)sdk.game.firstFrameReady()},gameReady(){if(ready||!first||!loaded||paused)return;ready=true;if(hosted)sdk.game.gameReady()},get paused(){return paused},get audioEnabled(){return audio},get loaded(){return loaded}};
}
root.CozyPlatform={create,normalize};if(typeof module!=='undefined')module.exports={create,normalize};
})(globalThis);
