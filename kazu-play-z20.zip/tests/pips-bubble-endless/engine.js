(function(root){'use strict';
const W=360,H=500,R=17,D=34,DY=Math.sqrt(3)*R,OX=27,TOP=25,MAXROW=13,DANGER=370,START={x:180,y:440};
const key=(r,c)=>r+','+c,count=(r,p=0)=>(r+p)%2?9:10;
const pos=(r,c,p=0)=>({x:OX+c*D+((r+p)%2?R:0),y:TOP+r*DY});
const inside=(r,c,p=0)=>Number.isInteger(r)&&Number.isInteger(c)&&r>=0&&r<MAXROW&&c>=0&&c<count(r,p);
function neighbors(r,c,p=0){const a=[[r,c-1],[r,c+1]];for(const dr of [-1,1])for(const dc of (r+p)%2?[0,1]:[-1,0])a.push([r+dr,c+dc]);return a.filter(([r,c])=>inside(r,c,p));}
const clone=b=>Object.fromEntries(Object.entries(b).map(([k,v])=>[k,{...v}]));
function connected(b,start,parity,match){const seen=new Set(),q=[start];while(q.length){const k=q.pop();if(seen.has(k)||!b[k]||(match&&!match(b[k])))continue;seen.add(k);const[r,c]=k.split(',').map(Number);for(const n of neighbors(r,c,parity))q.push(key(...n));}return [...seen];}
function trace(b,angle,parity=0){angle=Math.max(-1.38,Math.min(1.38,angle));let x=START.x,y=START.y,vx=Math.sin(angle),vy=-Math.cos(angle);const path=[{x,y}],nodes=Object.keys(b).map(k=>({k,...pos(...k.split(',').map(Number),parity)}));let hit=null,ceiling=false;
 for(let i=0;i<1400;i++){x+=vx*3;y+=vy*3;if(x<R+10){x=2*(R+10)-x;vx=-vx;path.push({x:R+10,y});}if(x>W-R-10){x=2*(W-R-10)-x;vx=-vx;path.push({x:W-R-10,y});}let near=Infinity;for(const p of nodes){const d=(x-p.x)**2+(y-p.y)**2;if(d<=(D-.2)**2&&d<near){near=d;hit=p.k;}}if(hit||y<=TOP){ceiling=!hit;break;}}
 path.push({x,y});let candidates=[];if(ceiling){for(let c=0;c<count(0,parity);c++)if(!b[key(0,c)])candidates.push([0,c]);}else if(hit){const[r,c]=hit.split(',').map(Number);candidates=neighbors(r,c,parity).filter(([r,c])=>!b[key(r,c)]);}
 candidates.sort((a,z)=>{const p=pos(...a,parity),q=pos(...z,parity);return(p.x-x)**2+(p.y-y)**2-((q.x-x)**2+(q.y-y)**2);});return{path,cell:candidates[0]||null,hit,angle};
}
function shoot(board,angle,color,parity=0){const b=clone(board),tr=trace(b,angle,parity);if(!tr.cell)return{...tr,board:b,popped:[],dropped:[],rescued:0,blocked:true};const[r,c]=tr.cell,k=key(r,c);b[k]={color,bird:false};let group=[];
 if(color===4){for(const co of new Set(neighbors(r,c,parity).map(x=>b[key(...x)]?.color).filter(x=>x!==undefined))){const g=connected(b,k,parity,v=>v.color===co||v.color===4);if(g.length>group.length)group=g;}}else group=connected(b,k,parity,v=>v.color===color||v.color===4);
 const popped=group.length>=3?group.map(k=>({key:k,...b[k]})):[];popped.forEach(v=>delete b[v.key]);const anchored=new Set();for(let c=0;c<count(0,parity);c++)if(b[key(0,c)])connected(b,key(0,c),parity).forEach(k=>anchored.add(k));const dropped=Object.keys(b).filter(k=>!anchored.has(k)).map(k=>({key:k,...b[k]}));dropped.forEach(v=>delete b[v.key]);return{...tr,board:b,popped,dropped,rescued:[...popped,...dropped].filter(v=>v.bird).length,blocked:false};
}
function random(s){s.seed=(Math.imul(s.seed,1664525)+1013904223)>>>0;return s.seed/4294967296;}
const level=s=>1+Math.floor(s.added/4),interval=s=>Math.max(4.5,16-(level(s)-1)*.85);
function makeRow(s,r=0){const colors=level(s)<3?3:4,offset=Math.floor(random(s)*colors);for(let c=0;c<count(r,s.parity);c++)s.board[key(r,c)]={color:(Math.floor(c/2)+offset+Math.floor(random(s)*.35))%colors,bird:level(s)>=4&&random(s)<.025};}
function pick(s){const colors=[...new Set(Object.values(s.board).map(v=>v.color).filter(c=>c<4))].sort();return colors[Math.floor(random(s)*colors.length)]??0;}
function create(seed=Date.now()){const s={version:1,seed:seed>>>0,parity:0,board:{},score:0,combo:0,added:0,elapsed:0,nextIn:16,pending:0,shots:0,cleared:0,rescued:0,rainbows:1,rainbowProgress:0,over:false,hand:0,next:0};for(let r=0;r<4;r++){for(let c=0;c<count(r);c++)s.board[key(r,c)]={color:(Math.floor(c/3)+Math.floor(r/2))%3,bird:false};}s.hand=pick(s);s.next=pick(s);return s;}
const dangerous=s=>Object.keys(s.board).some(k=>pos(...k.split(',').map(Number),s.parity).y+R>DANGER);
function addRow(s){if(s.over)return false;const b={};for(const[k,v]of Object.entries(s.board)){const[r,c]=k.split(',').map(Number);if(r+1>=MAXROW){s.over=true;return false;}b[key(r+1,c)]=v;}s.board=b;s.parity^=1;s.added++;makeRow(s);s.over=dangerous(s);return true;}
function advance(s,dt,busy=false){if(s.over||!Number.isFinite(dt)||dt<=0)return{rows:0};dt=Math.min(dt,.1);s.elapsed+=dt;s.nextIn-=dt;while(s.nextIn<=0){s.pending=Math.min(3,s.pending+1);s.nextIn+=interval(s);}let rows=0;if(!busy&&s.pending){s.pending--;if(addRow(s))rows=1;}return{rows};}
function fire(s,angle,rainbow=false){if(s.over)return null;const co=rainbow&&s.rainbows?4:s.hand,result=shoot(s.board,angle,co,s.parity);if(result.blocked)return result;s.board=result.board;s.shots++;if(co===4)s.rainbows--;s.combo=result.popped.length?s.combo+1:0;s.cleared+=result.popped.length+result.dropped.length;s.rescued+=result.rescued;s.rainbowProgress+=result.popped.length+result.dropped.length;while(s.rainbowProgress>=35){s.rainbowProgress-=35;s.rainbows=Math.min(3,s.rainbows+1);}
 const gain=result.popped.length*10+result.dropped.length*25+(result.popped.length?Math.min(5,s.combo)*20:0)+result.rescued*60;s.score=Math.min(999999999,s.score+gain);result.gain=gain;result.allClear=!Object.keys(s.board).length;
 if(result.allClear){s.score=Math.min(999999999,s.score+300);result.gain+=300;s.pending=0;s.nextIn=interval(s);makeRow(s,0);makeRow(s,1);}
 s.hand=s.next;s.next=pick(s);if(!Object.values(s.board).some(v=>v.color===s.hand))s.hand=pick(s);s.over=dangerous(s);return result;
}
function cleanSession(v){if(!v||v.version!==1||![0,1].includes(v.parity)||!v.board||Array.isArray(v.board)||typeof v.board!=='object')return null;const b={};for(const[k,val]of Object.entries(v.board)){const[r,c]=k.split(',').map(Number);if(key(r,c)!==k||!inside(r,c,v.parity)||!val||!Number.isInteger(val.color)||val.color<0||val.color>4)return null;b[k]={color:val.color,bird:!!val.bird};}if(!Object.keys(b).length||Object.keys(b).length>124)return null;
 const n=(name,max=999999999)=>Number.isFinite(v[name])?Math.max(0,Math.min(max,Math.floor(v[name]))):0;
 if(![v.hand,v.next].every(c=>Number.isInteger(c)&&c>=0&&c<4))return null;
 const s={version:1,seed:v.seed>>>0,parity:v.parity,board:b,score:n('score'),combo:n('combo',99),added:n('added',999999),elapsed:n('elapsed',9999999),nextIn:Number.isFinite(v.nextIn)?Math.max(.1,Math.min(16,v.nextIn)):16,pending:n('pending',3),shots:n('shots'),cleared:n('cleared'),rescued:n('rescued'),rainbows:n('rainbows',3),rainbowProgress:n('rainbowProgress',34),over:false,hand:v.hand,next:v.next};return dangerous(s)?null:s;
}
root.EndlessBubble={W,H,R,D,DY,TOP,MAXROW,DANGER,START,key,count,pos,inside,neighbors,trace,shoot,clone,create,level,interval,addRow,advance,fire,pick,dangerous,cleanSession};if(typeof module!=='undefined')module.exports=root.EndlessBubble;
})(globalThis);
