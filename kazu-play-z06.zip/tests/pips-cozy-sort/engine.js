(function(root){'use strict';
const ITEMS=[
 {id:'books',name:['Travel journals','旅の手帳'],w:2,h:3,color:'#5e8175'},
 {id:'camera',name:['Little camera','小さなカメラ'],w:3,h:2,color:'#b98a57'},
 {id:'jar',name:['Botanical vial','植物標本の小瓶'],w:1,h:3,color:'#7b9b87'},
 {id:'glasses',name:['Field binoculars','双眼鏡'],w:3,h:1,color:'#65848b'},
 {id:'cup',name:['Tea for the journey','旅のお茶カップ'],w:2,h:2,color:'#c6a47b'},
 {id:'tin',name:['Keepsake tin','思い出の缶'],w:2,h:2,color:'#88917f'},
 {id:'lens',name:['Pip’s magnifier','PIPの虫めがね'],w:2,h:2,color:'#b39761'},
 {id:'letters',name:['A letter from home','家からの手紙'],w:2,h:1,color:'#c5a28a'},
 {id:'scarf',name:['A folded scarf','たたんだスカーフ'],w:2,h:1,color:'#bd7e63'},
 {id:'brush',name:['Sketching brushes','スケッチの筆'],w:2,h:1,color:'#9d8c6f'}];
const SIZE=6,byId=id=>ITEMS.find(i=>i.id===id),dims=(id,r=0)=>{const i=byId(id);return r%2?[i.h,i.w]:[i.w,i.h]};
function valid(placed,id,x,y,r=0){if(!byId(id)||![x,y,r].every(Number.isInteger)||!([0,1].includes(r)))return false;const[w,h]=dims(id,r);if(x<0||y<0||x+w>SIZE||y+h>SIZE)return false;for(const[k,p]of Object.entries(placed)){if(k===id)continue;const[a,b]=dims(k,p.r);if(x<p.x+a&&x+w>p.x&&y<p.y+b&&y+h>p.y)return false;}return true;}
function clean(doc){const placed={};if(doc&&doc.version===1&&doc.placed&&typeof doc.placed==='object')for(const i of ITEMS){const p=doc.placed[i.id];if(p&&valid(placed,i.id,p.x,p.y,p.r))placed[i.id]={x:p.x,y:p.y,r:p.r};}return{version:1,placed,moves:Number.isInteger(doc?.moves)?Math.max(0,doc.moves):0,hints:Number.isInteger(doc?.hints)?Math.max(0,Math.min(10,doc.hints)):0,lang:doc?.lang==='en'?'en':'ja',sound:doc?.sound!==false,music:doc?.music!==false};}
function solve(placed,budget=150000){const board=Array(36).fill(false);for(const[id,p]of Object.entries(placed)){if(!byId(id))return null;const[w,h]=dims(id,p.r);for(let y=p.y;y<p.y+h;y++)for(let x=p.x;x<p.x+w;x++)board[y*6+x]=true;}let visits=0;const left=ITEMS.filter(i=>!placed[i.id]),out={...placed};function dfs(items){if(++visits>budget)return false;const start=board.indexOf(false);if(start<0)return items.length===0;const x=start%6,y=Math.floor(start/6),seen=new Set();for(let j=0;j<items.length;j++){const it=items[j],sig=[it.w,it.h].sort().join(':');if(seen.has(sig))continue;seen.add(sig);for(let r=0;r<(it.w===it.h?1:2);r++){const[w,h]=dims(it.id,r);if(x+w>6||y+h>6)continue;const cells=[];let ok=true;for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++){const c=yy*6+xx;cells.push(c);if(board[c])ok=false;}if(!ok)continue;cells.forEach(c=>board[c]=true);out[it.id]={x,y,r};if(dfs(items.filter((_,n)=>n!==j)))return true;delete out[it.id];cells.forEach(c=>board[c]=false);}}return false;}return dfs(left)?out:null;}
const api={ITEMS,SIZE,byId,dims,valid,clean,solve};root.CozyEngine=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
