/* Original generative pentatonic music. No external recordings or assets. */
(function(root){'use strict';function create(){let ctx=null,timer=null,step=0,enabled=true,running=false,starting=false,generation=0;const melody=[74,78,81,86,81,78,76,81,78,81,83,86,83,81,78,74],chords=[[50,57,62],[55,62,67],[47,54,59],[45,52,57]];
function note(midi,time,duration,volume,type='triangle'){if(!ctx||ctx.state!=='running')return;const o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.value=440*Math.pow(2,(midi-69)/12);g.gain.setValueAtTime(.0001,time);g.gain.exponentialRampToValueAtTime(volume,time+.06);g.gain.exponentialRampToValueAtTime(.0001,time+duration);o.connect(g).connect(ctx.destination);o.start(time);o.stop(time+duration+.05);}
function phrase(){if(!running||!enabled||!ctx||ctx.state!=='running')return;const time=ctx.currentTime+.025;note(melody[step%16],time,.6,.024);if(step%4===0)for(const n of chords[Math.floor(step/4)%4])note(n,time,1.8,.009);step++;}
async function start(){if(!enabled||running||starting)return;const token=++generation;starting=true;try{if(!ctx||ctx.state==='closed')ctx=new(window.AudioContext||window.webkitAudioContext)();const local=ctx;await local.resume();if(token!==generation||!enabled||ctx!==local||local.state!=='running')return;running=true;phrase();timer=setInterval(phrase,340);}catch{}finally{if(token===generation)starting=false;}}
function stop(){generation++;starting=false;running=false;if(timer!==null)clearInterval(timer);timer=null;if(ctx){const old=ctx;ctx=null;void old.close().catch(()=>{});}}
function effect(clear=false){if(!enabled||!ctx||ctx.state!=='running')return;const now=ctx.currentTime;for(let i=0;i<(clear?7:1);i++)note((clear?[72,76,79,84,79,84,88]:[76])[i],now+i*.075,.38,.032);}
return{start,stop,effect,set(value){enabled=!!value;if(!enabled)stop();},get enabled(){return enabled;}};}
root.TwinsMusic={create};})(globalThis);

