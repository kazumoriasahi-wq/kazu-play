import { evaluate, rankOf, suitOf } from './engine.js';
export const dealTiming = {
    slow: { flight: 500, interval: 350, flip: 550, pause: 250, flop: 1750, turn: 740, river: 840 },
    standard: { flight: 420, interval: 285, flip: 460, pause: 250, flop: 1450, turn: 640, river: 740 },
    fast: { flight: 280, interval: 125, flip: 300, pause: 120, flop: 880, turn: 410, river: 475 },
};
export function openingCue(hole) {
    if (hole.length !== 2)
        return;
    const [a, b] = hole.map(rankOf);
    if (a === b) {
        if (a === 14)
            return { text: 'POCKET ACES!', kind: 'gold', ms: 1200 };
        if (a === 13)
            return { text: 'POCKET KINGS!', kind: 'silver', ms: 1000 };
        if (a >= 11)
            return { text: 'PREMIUM PAIR', kind: 'gold', ms: 700 };
        return { text: '', kind: 'soft', ms: 420 };
    }
    if (Math.max(a, b) === 14 && Math.min(a, b) === 13)
        return { text: 'BIG SLICK', kind: suitOf(hole[0]) === suitOf(hole[1]) ? 'silver' : 'soft', ms: 680 };
}
export function madeCue(hole, board, previous) {
    if (hole.length !== 2 || board.length < 3 || board.length <= previous.length)
        return;
    const best = evaluate([...hole, ...board]);
    const [r, top] = best.score;
    const label = r === 8 && top === 14 ? 'ROYAL FLUSH!' : { 4: 'STRAIGHT', 5: 'FLUSH', 6: 'FULL HOUSE', 7: 'FOUR OF A KIND', 8: 'STRAIGHT FLUSH' }[r];
    if (!label)
        return;
    const old = previous.length >= 3 ? evaluate([...hole, ...previous]).score : [-1];
    if (r < old[0] || r === old[0] && !(r === 8 && top === 14 && old[1] !== 14))
        return;
    const ordered = [...best.cards];
    if (r === 4 || r === 8)
        ordered.sort((a, b) => (top === 5 && rankOf(a) === 14 ? 1 : rankOf(a)) - (top === 5 && rankOf(b) === 14 ? 1 : rankOf(b)));
    return { text: label, kind: r === 5 ? 'silver' : r === 7 ? 'impact' : r === 8 && top === 14 ? 'royal' : 'gold', ms: r === 8 ? 1200 : 850, cards: ordered };
}
const notes = {
    deal: [165, 113], flip: [230, 390], chip: [920, 680, 1010], check: [442], raise: [390, 580, 880], allin: [110, 165, 220, 440],
    soft: [523, 659], silver: [330, 440, 660], gold: [523, 659, 784, 1047], impact: [105, 210, 420], royal: [523, 659, 784, 1047, 1319, 1568],
    win: [392, 523, 659, 784], champion: [392, 523, 659, 784, 1047, 1319],
};
export function createEffects(settings, onSkip = () => { }) {
    let ctx, musicBus, track = 0, beat = 0;
    let timeouts = [], animations = [], until = 0;
    const layer = document.getElementById('fx-layer');
    const skip = document.getElementById('skip-fx');
    const table = document.querySelector('.felt');
    const pip = document.querySelector('.pip');
    const intensity = () => matchMedia('(prefers-reduced-motion: reduce)').matches && settings().intensity !== 'off' ? 'light' : settings().intensity;
    const motion = () => typeof table.animate === 'function' && (intensity() === 'full' || intensity() === 'standard');
    const el = (cls, text = '') => { const n = document.createElement('span'); n.className = cls; n.textContent = text; return n; };
    function tone(f, at, len, gain, target, type = 'sine') {
        if (!ctx || gain <= 0)
            return;
        const osc = ctx.createOscillator(), env = ctx.createGain();
        osc.type = type;
        osc.frequency.value = f;
        env.gain.setValueAtTime(.0001, at);
        env.gain.exponentialRampToValueAtTime(gain, at + .015);
        env.gain.exponentialRampToValueAtTime(.0001, at + len);
        osc.connect(env).connect(target);
        osc.start(at);
        osc.stop(at + len + .01);
    }
    function sound(key) {
        if (!ctx || ctx.state !== 'running' || settings().muted)
            return;
        const volume = settings().volume / 100, at = ctx.currentTime;
        notes[key].forEach((f, i) => tone(f, at + i * (key === 'deal' ? .022 : .052), key === 'deal' ? .065 : .23, volume * .075, ctx.destination, key === 'deal' || key === 'chip' ? 'triangle' : 'sine'));
    }
    function music() {
        if (!ctx || !musicBus)
            return;
        musicBus.gain.value = settings().musicMuted || document.hidden ? 0 : settings().music / 100;
        if (!musicBus.gain.value) {
            clearInterval(track);
            track = 0;
            return;
        }
        if (track)
            return;
        const chords = [[130.81, 155.56, 196, 233.08], [116.54, 146.83, 174.61, 220], [103.83, 130.81, 155.56, 196], [98, 123.47, 146.83, 174.61]];
        const pulse = () => {
            if (!ctx || !musicBus || ctx.state !== 'running')
                return;
            const chord = chords[Math.floor(beat / 4) % chords.length], at = ctx.currentTime;
            tone(chord[0] / (beat % 2 === 0 ? 2 : 1), at, .48, .058, musicBus, 'triangle');
            if (beat % 2 === 1)
                chord.slice(1).forEach((f, i) => tone(f, at + i * .025, .65, .026, musicBus));
            if (beat % 4 === 2)
                tone(chord[2] * 2, at + .17, .32, .025, musicBus);
            beat++;
        };
        pulse();
        track = window.setInterval(pulse, 540);
    }
    function unlock() {
        try {
            const Audio = window.AudioContext || window.webkitAudioContext;
            if (!Audio)
                return;
            if (!ctx) {
                ctx = new Audio();
                musicBus = ctx.createGain();
                musicBus.connect(ctx.destination);
            }
            if (ctx.state !== 'running')
                void ctx.resume().catch(() => { });
            music();
        }
        catch { /* Audio is optional. */ }
    }
    document.addEventListener('visibilitychange', music);
    const later = (fn, ms) => {
        const id = window.setTimeout(() => { timeouts = timeouts.filter(x => x !== id); fn(); }, ms);
        timeouts.push(id);
    };
    function animate(node, frames, options) {
        if (!node.animate)
            return;
        const a = node.animate(frames, options);
        animations.push(a);
        const forget = () => { animations = animations.filter(x => x !== a); };
        a.onfinish = forget;
        a.oncancel = forget;
    }
    function clear() {
        timeouts.forEach(clearTimeout);
        timeouts = [];
        animations.forEach(a => a.cancel());
        animations = [];
        layer.replaceChildren();
        skip.hidden = true;
        until = 0;
    }
    skip.onclick = () => { clear(); onSkip(); };
    const timing = () => dealTiming[settings().dealSpeed ?? 'standard'] ?? dealTiming.standard;
    const remaining = () => Math.max(0, until - performance.now());
    function reserve(ms) {
        if (!motion() || ms <= 0)
            return;
        until = Math.max(until, performance.now() + ms);
        skip.hidden = false;
        later(() => { if (remaining() < 20)
            skip.hidden = true; }, ms + 20);
    }
    function uncover(node, delay, duration) {
        animate(node, [{ opacity: 0, visibility: 'hidden', transform: 'rotateY(85deg)' }, { opacity: 0, visibility: 'hidden', transform: 'rotateY(85deg)', offset: delay / (delay + duration) }, { opacity: 1, visibility: 'visible', transform: 'none' }], { duration: delay + duration, fill: 'backwards', easing: 'linear' });
    }
    const point = (n) => { const b = n.getBoundingClientRect(); return { x: b.left + b.width / 2, y: b.top + b.height / 2, w: b.width, h: b.height }; };
    function fly(cls, from, to, delay = 0, count = 1, landing, travel = 215) {
        if (!motion() || !from.isConnected || !to.isConnected)
            return;
        const a = point(from), b = point(to);
        for (let i = 0; i < count; i++) {
            const n = el('fx-flight ' + cls, cls === 'fx-chip' ? '♠' : '');
            n.style.left = a.x + 'px';
            n.style.top = a.y + 'px';
            if (cls === 'fx-card') {
                n.style.width = Math.min(b.w || 28, 52) + 'px';
                n.style.height = Math.min(b.h || 38, 70) + 'px';
            }
            if (cls === 'fx-card')
                n.textContent = 'P';
            n.style.visibility = 'hidden';
            layer.append(n);
            later(() => {
                n.style.visibility = 'visible';
                animate(n, [{ transform: 'translate(-50%,-50%) rotate(-9deg)', opacity: 1 }, { transform: 'translate(calc(-50% + ' + (b.x - a.x) + 'px),calc(-50% + ' + (b.y - a.y) + 'px)) rotate(0deg)', opacity: .92 }], { duration: travel, easing: 'cubic-bezier(.4,.05,.24,1)', fill: 'forwards' });
                later(() => { n.remove(); if (i === 0)
                    landing?.(); }, travel);
            }, delay + i * 45);
        }
    }
    function react(kind) {
        if (!motion())
            return;
        const frames = { deal: [{ transform: 'rotate(-12deg)' }, { transform: 'rotate(9deg)' }, { transform: 'none' }],
            joy: [{ transform: 'none' }, { transform: 'translateY(-9px) rotate(-10deg)' }, { transform: 'none' }],
            surprise: [{ transform: 'none' }, { transform: 'scale(1.2) translateY(-4px)' }, { transform: 'none' }],
            champion: [{ transform: 'none' }, { transform: 'translateY(-12px) rotate(12deg)' }, { transform: 'none' }] }[kind];
        const frameSize = pip.getBoundingClientRect().width;
        const poses = { deal: [0, 4, 5, 0], joy: [24, 25, 26, 27, 0], surprise: [0, 13, 14, 0], champion: [24, 25, 26, 27, 0] }[kind];
        const duration = kind === 'champion' ? 620 : kind === 'deal' ? 480 : 380, iterations = kind === 'champion' ? 2 : 1;
        animate(pip, frames, { duration, iterations });
        animate(pip, poses.map(i => ({ backgroundPosition: -(i % 8) * frameSize + 'px ' + -Math.floor(i / 8) * frameSize + 'px' })), { duration, iterations, easing: 'steps(1,end)' });
    }
    function banner(c, targets = []) {
        if (intensity() === 'off')
            return;
        const life = intensity() === 'light' ? Math.min(c.ms, 650) : c.ms;
        const label = el('fx-banner fx-' + c.kind, c.text);
        if (c.text)
            layer.querySelectorAll('.fx-banner').forEach(n => n.remove());
        if (c.text) {
            const anchor = point(table);
            label.style.left = anchor.x + 'px';
            label.style.top = (anchor.y - 40) + 'px';
            layer.append(label);
            later(() => label.remove(), life);
        }
        if (motion()) {
            targets.forEach((node, i) => animate(node, [{ boxShadow: '0 0 0 0 #ffe5a900' }, { boxShadow: '0 0 18px 3px ' + (c.kind === 'silver' ? '#b7e8ff' : '#ffcb70') }, { boxShadow: '0 0 0 0 #ffe5a900' }], { duration: Math.max(280, life - i * 50), delay: i * 50 }));
            if (c.kind === 'royal' || intensity() === 'full' && c.kind === 'gold') {
                const p = point(table);
                for (let i = 0; i < (c.kind === 'royal' ? 20 : 9); i++) {
                    const n = el('fx-star', '✦');
                    n.style.left = p.x + 'px';
                    n.style.top = p.y + 'px';
                    layer.append(n);
                    const angle = i * 2.39996, r = 35 + (i % 6) * 13;
                    animate(n, [{ transform: 'scale(.3)', opacity: .9 }, { transform: 'translate(' + Math.cos(angle) * r + 'px,' + Math.sin(angle) * r + 'px) scale(1.15)', opacity: 0 }], { duration: life, fill: 'forwards' });
                    later(() => n.remove(), life);
                }
            }
            if (c.kind === 'impact')
                animate(table, [{ outline: '1px solid #ffc996' }, { outline: '12px solid #ffc99600' }], { duration: 560 });
        }
        if (life >= 850) {
            skip.hidden = false;
            later(() => { if (remaining() < 20 && !layer.querySelector('.fx-banner'))
                skip.hidden = true; }, life + 20);
        }
    }
    function deal(order, hero) {
        clear();
        react('deal');
        const targets = [...document.querySelectorAll('.hero-cards .card:not(.empty)')];
        const from = document.querySelector('.host');
        const t = timing(), cue = openingCue(hero);
        if (!motion()) {
            sound('deal');
            if (cue) {
                banner(cue, targets);
                sound(cue.kind);
            }
            return 0;
        }
        const arrivals = order.filter(i => document.querySelector('.seat[data-seat="' + i + '"]'));
        let lastLanding = 0;
        arrivals.forEach((i, j) => {
            const cards = i === 0 ? targets : document.querySelectorAll('.seat[data-seat="' + i + '"] .card');
            for (let round = 0; round < 2; round++) {
                const node = cards[round];
                if (!node)
                    continue;
                const delay = (round * arrivals.length + j) * t.interval;
                lastLanding = Math.max(lastLanding, delay + t.flight);
                fly('fx-card', from, node, delay, 1, () => sound('deal'), t.flight);
                if (i !== 0)
                    animate(node, [{ opacity: 0 }, { opacity: 0, offset: (delay + t.flight) / (delay + t.flight + 45) }, { opacity: 1 }], { duration: delay + t.flight + 45 });
            }
        });
        const first = lastLanding + 70, second = first + t.flip + t.pause;
        if (targets[0])
            uncover(targets[0], first, t.flip);
        if (targets[1])
            uncover(targets[1], second, t.flip);
        later(() => sound('flip'), first + Math.round(t.flip / 2));
        later(() => sound('flip'), second + Math.round(t.flip / 2));
        const end = second + t.flip;
        if (cue)
            later(() => { banner(cue, targets); sound(cue.kind); }, end);
        reserve(end);
        return end;
    }
    function board(hero, cards, previous, offset = 0) {
        const t = timing(), duration = motion() ? (cards.length === 3 ? t.flop : cards.length === 4 ? t.turn : t.river) : 0;
        const flip = Math.min(t.flip, duration), start = offset + duration - flip;
        if (duration)
            document.querySelectorAll('#board .card').forEach((n, i) => {
                if (i >= previous.length && i < cards.length)
                    uncover(n, start, flip);
            });
        const reveal = () => {
            sound('flip');
            const cue = madeCue(hero, cards, previous);
            if (!cue)
                return;
            const nodes = [...document.querySelectorAll('#board [data-card],.hero-cards [data-card]')];
            banner(cue, cue.cards.flatMap(id => nodes.filter(n => n.dataset.card === String(id))));
            sound(cue.kind);
        };
        if (duration) {
            reserve(offset + duration);
            later(reveal, offset + duration);
        }
        else
            reveal();
        return duration;
    }
    function action(move) {
        const seat = document.querySelector('.seat[data-seat="' + move.seat + '"]');
        if (!seat)
            return;
        const pot = document.getElementById('pot');
        const raise = move.to > move.previous;
        if (move.action === 'fold') {
            if (motion())
                for (const n of document.querySelectorAll(move.seat === 0 ? '.hero-cards .card' : '.seat[data-seat="' + move.seat + '"] .card'))
                    fly('fx-card', n, pot);
            sound('deal');
            return;
        }
        if (move.action === 'check') {
            sound('check');
            if (intensity() !== 'off') {
                const p = point(seat), n = el('fx-check', 'CHECK');
                n.style.left = p.x + 'px';
                n.style.top = (p.y - 29) + 'px';
                layer.append(n);
                later(() => n.remove(), 490);
            }
            return;
        }
        if (move.paid)
            fly('fx-chip', seat, pot, 0, raise ? 4 : 2);
        if (move.action === 'allin') {
            banner({ text: 'ALL IN', kind: 'allin', ms: 1050 });
            react('surprise');
            sound('allin');
            if (motion())
                animate(table, [{ filter: 'brightness(.74) saturate(.86)' }, { filter: 'brightness(.92)' }, { filter: 'none' }], { duration: 680, easing: 'ease-out' });
        }
        else
            sound(raise ? 'raise' : 'chip');
    }
    function award(seats, bb, champion) {
        const pot = document.getElementById('pot');
        seats.forEach(({ seat, amount }) => { const node = document.querySelector('.seat[data-seat="' + seat + '"]'); if (node)
            fly('fx-chip', pot, node, 45, amount >= bb * 25 ? 7 : 3); });
        if (champion >= 0) {
            banner({ text: 'TOURNAMENT CHAMPION', kind: 'royal', ms: 1350 });
            react('champion');
            sound('champion');
        }
        else if (seats.some(s => s.seat === 0)) {
            react('joy');
            sound('win');
            if (seats.some(s => s.seat === 0 && s.amount >= bb * 25))
                banner({ text: 'BIG POT!', kind: 'gold', ms: 880 });
        }
    }
    return { clear, unlock, music, deal, board, action, award, remaining, after: later };
}
