(function(root){'use strict';
const E=root.CozyEngine;
const plans={
  "travel": {
    "edge": {
      "id": "books",
      "side": "top"
    },
    "pair": [
      "camera",
      "jar"
    ]
  },
  "tea-time": {
    "edge": {
      "id": "cookies",
      "side": "right"
    },
    "pair": [
      "cookies",
      "tin"
    ]
  },
  "garden": {
    "edge": {
      "id": "scarf",
      "side": "bottom"
    },
    "pair": [
      "gloves",
      "jar"
    ]
  },
  "post": {
    "edge": {
      "id": "books",
      "side": "left"
    },
    "pair": [
      "camera",
      "tin"
    ]
  },
  "stars": {
    "edge": {
      "id": "map",
      "side": "top"
    },
    "pair": [
      "telescope",
      "starbox"
    ]
  },
  "picnic": {
    "edge": {
      "id": "teapot",
      "side": "right"
    },
    "pair": [
      "bottle",
      "teapot"
    ]
  }
};
function atEdge(id,p,side){if(!p)return false;const [w,h]=E.dims(id,p.r);return side==='top'?p.y===0:side==='bottom'?p.y+h===6:side==='left'?p.x===0:p.x+w===6;}
function adjacent(a,p,b,q){if(!p||!q)return false;const[w,h]=E.dims(a,p.r),[v,k]=E.dims(b,q.r);return ((p.x+w===q.x||q.x+v===p.x)&&Math.max(p.y,q.y)<Math.min(p.y+h,q.y+k))||((p.y+h===q.y||q.y+k===p.y)&&Math.max(p.x,q.x)<Math.min(p.x+w,q.x+v));}
function checks(placed){const g=plans[E.getStage().id];return [atEdge(g.edge.id,placed[g.edge.id],g.edge.side),adjacent(g.pair[0],placed[g.pair[0]],g.pair[1],placed[g.pair[1]])];}
function partial(placed,mode){if(mode!=='request')return true;const g=plans[E.getStage().id];if(placed[g.edge.id]&&!atEdge(g.edge.id,placed[g.edge.id],g.edge.side))return false;const [a,b]=g.pair;return !(placed[a]&&placed[b])||adjacent(a,placed[a],b,placed[b]);}
function solve(placed,mode='free',budget=300000){const base={};for(const[id,p]of Object.entries(placed)){if(!p||!E.valid(base,id,p.x,p.y,p.r))return {status:'invalid'};base[id]={...p};}if(!partial(base,mode))return {status:'blocked'};let visits=0,limited=false;const board=Array(36).fill(false);for(const[id,p]of Object.entries(base)){const[w,h]=E.dims(id,p.r);for(let y=p.y;y<p.y+h;y++)for(let x=p.x;x<p.x+w;x++)board[y*6+x]=true;}
const out={...base};function dfs(left){if(++visits>budget){limited=true;return false;}const c=board.indexOf(false);if(c<0)return !left.length&&(mode!=='request'||checks(out).every(Boolean));const x=c%6,y=Math.floor(c/6),seen=new Set(),g=plans[E.getStage().id];for(const it of left){const special=mode==='request'&&[g.edge.id,...g.pair].includes(it.id);const signature=special?it.id:[it.w,it.h].sort().join(':');if(seen.has(signature))continue;seen.add(signature);for(let r=0;r<(it.w===it.h?1:2);r++){const[w,h]=E.dims(it.id,r);if(x+w>6||y+h>6)continue;const cells=[];for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++)cells.push(yy*6+xx);if(cells.some(i=>board[i]))continue;out[it.id]={x,y,r};if(partial(out,mode)){cells.forEach(i=>board[i]=true);if(dfs(left.filter(i=>i.id!==it.id)))return true;cells.forEach(i=>board[i]=false);}delete out[it.id];if(limited)return false;}}return false;}const found=dfs(E.ITEMS.filter(i=>!base[i.id]));return found?{status:'solved',answer:out,visits}:{status:limited?'limit':'blocked',visits};}
const api={plans,checks,atEdge,adjacent,partial,solve};root.CozyAtelier=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
