importScripts('engine.js','atelier-engine.js');
onmessage=e=>{const {stage,mode,placed,id}=e.data;CozyEngine.setStage(stage);try{postMessage({id,...CozyAtelier.solve(placed,mode)})}catch{postMessage({id,status:'error'})}};
