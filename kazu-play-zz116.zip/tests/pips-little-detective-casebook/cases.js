(function(root){const cases=[
  {
    "id": 1,
    "title": [
      "消えたケーキ事件",
      "The Missing Cake"
    ],
    "place": [
      "海辺のパン屋",
      "The harbour bakery"
    ],
    "image": "bakery.webp",
    "intro": [
      "空の皿と、小さな足跡。ケーキの行方を、証拠と証言からたどろう。",
      "An empty stand and tiny prints. Follow the cake through evidence and testimony."
    ],
    "clues": [
      {
        "id": "plate",
        "pos": [
          58,
          44
        ],
        "area": [
          "ケーキ皿",
          "Cake stand"
        ],
        "name": [
          "皿に残ったクリーム",
          "Cream on the stand"
        ],
        "body": [
          "クリームが少し残っているけれど、切り分けた跡はない。ケーキは一台のまま運ばれたようだ。\n皿の近くにフォークも切り分けたかけらもない。「誰かが食べた」と決めつけるのは早い。",
          "There is a little cream, but no sign of slicing. It looks as if the cake was carried away whole.\nThere are no forks or slices nearby. It is too early to assume somebody ate it."
        ],
        "detail": [
          "皿の近くにフォークも切り分けたかけらもない。「誰かが食べた」と決めつけるのは早い。",
          "There are no forks or slices nearby. It is too early to assume somebody ate it."
        ]
      },
      {
        "id": "ribbon",
        "pos": [
          73,
          49
        ],
        "area": [
          "青い布の端",
          "Blue fabric"
        ],
        "name": [
          "ちぎれた青いリボン",
          "Torn blue ribbon"
        ],
        "body": [
          "皿の縁に引っかかった青いリボン。先が三角に裂け、細い糸が出ている。\n同じ色だけでは持ち主を断定できない。身につけていた人と、ほかの証拠を合わせて考えよう。",
          "A blue ribbon caught on the edge of the stand. Its end is torn into a triangle, with loose threads.\nColour alone does not identify its owner. Compare what people were wearing with another piece of evidence."
        ],
        "detail": [
          "同じ色だけでは持ち主を断定できない。身につけていた人と、ほかの証拠を合わせて考えよう。",
          "Colour alone does not identify its owner. Compare what people were wearing with another piece of evidence."
        ]
      },
      {
        "id": "prints",
        "pos": [
          62,
          79
        ],
        "area": [
          "床の白い跡",
          "Flour on the floor"
        ],
        "name": [
          "小さな足跡",
          "Small pawprints"
        ],
        "body": [
          "粉の上に小さく丸い足跡が続いている。カウンターから裏口の方へ。水かきの形は見当たらない。\nアヒルの足跡とは違う。パン屋のベアさんが見せてくれた足よりも、ひと回り小さい。",
          "Small round pawprints run from the counter towards the side door. There are no webbed-foot shapes.\nThese differ from a duck’s prints and are smaller than the baker Bea’s feet."
        ],
        "detail": [
          "アヒルの足跡とは違う。パン屋のベアさんが見せてくれた足よりも、ひと回り小さい。",
          "These differ from a duck’s prints and are smaller than the baker Bea’s feet."
        ]
      },
      {
        "id": "ticket",
        "pos": [
          21,
          44
        ],
        "area": [
          "留めてある紙",
          "Pinned paper"
        ],
        "name": [
          "ケーキの受け取りメモ",
          "Cake collection note"
        ],
        "body": [
          "メモには「9:15 庭の集まりへ一台。窓辺は日が当たるので、涼しい場所で待たせてね」とある。\n下の方は折れて隠れていた。ケーキを運ぶ人が、置き場所の指示を取り違えたのかもしれない。",
          "The note reads: “One cake for the garden gathering at 9:15. The window gets sunny, so please keep it somewhere cool.”\nThe bottom was folded out of sight. Perhaps someone misunderstood where the cake should wait."
        ],
        "detail": [
          "下の方は折れて隠れていた。ケーキを運ぶ人が、置き場所の指示を取り違えたのかもしれない。",
          "The bottom was folded out of sight. Perhaps someone misunderstood where the cake should wait."
        ]
      },
      {
        "id": "door",
        "pos": [
          91,
          54
        ],
        "area": [
          "開いている裏口",
          "Open side door"
        ],
        "name": [
          "開いたままの裏口",
          "Open side door"
        ],
        "body": [
          "鍵や取っ手は壊れていない。内側から普通に開けられ、外には日陰の庭がある。\n庭へ続く道にも、粉がわずかに落ちている。無理に侵入した様子はない。",
          "The latch and handle are intact. The door opens normally from inside, onto a shaded garden.\nA trace of flour continues towards the garden. There is no sign of a forced entry."
        ],
        "detail": [
          "庭へ続く道にも、粉がわずかに落ちている。無理に侵入した様子はない。",
          "A trace of flour continues towards the garden. There is no sign of a forced entry."
        ]
      },
      {
        "id": "clock",
        "pos": [
          21,
          11
        ],
        "area": [
          "壁の時計",
          "Wall clock"
        ],
        "name": [
          "止まっている時計",
          "Stopped clock"
        ],
        "body": [
          "耳を近づけても音がしない。ねじが切れて止まっている。この針を事件の時刻に使うことはできない。\n時刻は、動いている別の時計や、見聞きした人の証言から確かめる必要がある。",
          "It makes no ticking sound. The clock has run down. Its hands cannot establish the time of the incident.\nUse a working clock or a witness’s observation to establish the time instead."
        ],
        "detail": [
          "時刻は、動いている別の時計や、見聞きした人の証言から確かめる必要がある。",
          "Use a working clock or a witness’s observation to establish the time instead."
        ]
      }
    ],
    "people": [
      {
        "id": "bea",
        "name": [
          "ベア",
          "Bea"
        ],
        "role": [
          "パン屋の店主",
          "The baker"
        ],
        "desc": [
          "ケーキを仕上げた店主。受け取りの約束が気がかり。",
          "The baker who finished the cake. Worried about the collection."
        ],
        "quote": [
          "「9時にケーキを置いて、9時5分の窯のベルで奥へ行ったの。」",
          "“I set it out at nine and went to the oven when its 9:05 bell rang.”"
        ],
        "topics": [
          [
            [
              "今朝のこと",
              "This morning"
            ],
            [
              "9時に飾りつけを終えて、ケーキ皿にのせたわ。9時5分に窯のベルが鳴ったから、奥でパンを出していたの。戻ったらケーキがなかった。",
              "I finished decorating at nine. The oven bell rang at 9:05, so I went out back to take out the bread. When I returned, the cake was gone."
            ]
          ],
          [
            [
              "時計と足跡について",
              "The clock and footprints"
            ],
            [
              "壁の時計は昨日から止まっているの。窯の時計は動いているわ。床の小さな足跡？ 私の足より小さいみたい。",
              "The wall clock stopped yesterday. The oven clock works. Those little prints on the floor look smaller than my feet."
            ]
          ],
          [
            [
              "ケーキの届け先",
              "The cake’s destination"
            ],
            [
              "9時15分から庭でお茶会があるの。涼しいところで待たせて、と伝票に書いたわ。日が当たるとクリームがやわらかくなるから。",
              "It is for a garden tea party at 9:15. I wrote that it should wait somewhere cool; sunlight softens the cream."
            ]
          ]
        ],
        "detail": [
          "9時に飾りつけを終えて、ケーキ皿にのせたわ。9時5分に窯のベルが鳴ったから、奥でパンを出していたの。戻ったらケーキがなかった。\n壁の時計は昨日から止まっているの。窯の時計は動いているわ。床の小さな足跡？ 私の足より小さいみたい。\n9時15分から庭でお茶会があるの。涼しいところで待たせて、と伝票に書いたわ。日が当たるとクリームがやわらかくなるから。",
          "I finished decorating at nine. The oven bell rang at 9:05, so I went out back to take out the bread. When I returned, the cake was gone.\nThe wall clock stopped yesterday. The oven clock works. Those little prints on the floor look smaller than my feet.\nIt is for a garden tea party at 9:15. I wrote that it should wait somewhere cool; sunlight softens the cream."
        ]
      },
      {
        "id": "milo",
        "name": [
          "ミロ",
          "Milo"
        ],
        "role": [
          "配達のお手伝い",
          "Delivery assistant"
        ],
        "desc": [
          "青いリボンが目印のミロ。少し落ち着かない様子。",
          "Milo wears a blue wrist ribbon and seems a little uneasy."
        ],
        "quote": [
          "「表で袋を整理していたよ。カウンターには近づいていない。」",
          "“I was sorting bags out front. I never went near the counter.”"
        ],
        "topics": [
          [
            [
              "今朝のこと",
              "This morning"
            ],
            [
              "表で配達袋を整理していたんだ。ベアさんが奥へ行ったあとも、カウンターには一度も近づいていないよ。",
              "I was sorting delivery bags out front. Even after Bea went to the oven, I never went near the counter."
            ]
          ],
          [
            [
              "青いリボンについて",
              "The blue ribbon"
            ],
            [
              "この青いリボンは配達のお手伝いの目印なんだ。今朝つけたときは、端まできれいだったんだけど……。",
              "This blue ribbon marks me as a delivery helper. Its end was neat when I put it on this morning…"
            ]
          ],
          [
            [
              "受け取りメモについて",
              "The collection note"
            ],
            [
              "ベアさんはメモを見てね、と言っていた。でもぼく、急いでいて、下の方までよく読まなかったかも。",
              "Bea asked me to read the note. I was in a hurry; perhaps I did not read the bottom carefully."
            ]
          ]
        ],
        "detail": [
          "表で配達袋を整理していたんだ。ベアさんが奥へ行ったあとも、カウンターには一度も近づいていないよ。\nこの青いリボンは配達のお手伝いの目印なんだ。今朝つけたときは、端まできれいだったんだけど……。\nベアさんはメモを見てね、と言っていた。でもぼく、急いでいて、下の方までよく読まなかったかも。",
          "I was sorting delivery bags out front. Even after Bea went to the oven, I never went near the counter.\nThis blue ribbon marks me as a delivery helper. Its end was neat when I put it on this morning…\nBea asked me to read the note. I was in a hurry; perhaps I did not read the bottom carefully."
        ]
      },
      {
        "id": "nora",
        "name": [
          "ノラ",
          "Nora"
        ],
        "role": [
          "庭しごとのお手伝い",
          "The gardener"
        ],
        "desc": [
          "庭の水やりをしていたノラ。裏口を見かけたという。",
          "Nora was watering the garden and noticed the side door."
        ],
        "quote": [
          "「9時10分ごろ、裏口で青いひもが揺れたのを見たわ。」",
          "“Around 9:10 I saw a blue ribbon flutter at the side door.”"
        ],
        "topics": [
          [
            [
              "今朝のこと",
              "This morning"
            ],
            [
              "庭の水やりをしていたの。広場の動いている時計で9時10分を見たころ、裏口で青いひもが揺れたわ。誰かの顔までは見えなかった。",
              "I was watering the garden. Around 9:10 by the working square clock, I saw a blue ribbon flutter at the side door. I could not see anyone’s face."
            ]
          ],
          [
            [
              "庭の様子",
              "The garden"
            ],
            [
              "裏口の先には、ひさしの下の涼しいテーブルがあるの。今日は日が強いから、お茶会の準備はそこでしていたわ。",
              "There is a cool table under the awning beyond the side door. It is sunny today, so that is where we prepared the tea party."
            ]
          ],
          [
            [
              "足跡について",
              "The footprints"
            ],
            [
              "私の足には水かきがあるわ。粉の上の丸い跡は、私の足の形とは違うみたい。",
              "My feet are webbed. Those round marks in the flour are not the shape of my feet."
            ]
          ]
        ],
        "detail": [
          "庭の水やりをしていたの。広場の動いている時計で9時10分を見たころ、裏口で青いひもが揺れたわ。誰かの顔までは見えなかった。\n裏口の先には、ひさしの下の涼しいテーブルがあるの。今日は日が強いから、お茶会の準備はそこでしていたわ。\n私の足には水かきがあるわ。粉の上の丸い跡は、私の足の形とは違うみたい。",
          "I was watering the garden. Around 9:10 by the working square clock, I saw a blue ribbon flutter at the side door. I could not see anyone’s face.\nThere is a cool table under the awning beyond the side door. It is sunny today, so that is where we prepared the tea party.\nMy feet are webbed. Those round marks in the flour are not the shape of my feet."
        ]
      }
    ],
    "links": [
      {
        "pair": [
          "ribbon",
          "prints"
        ],
        "title": [
          "カウンターに近づいた人",
          "Who approached the counter?"
        ],
        "question": [
          "ミロの証言を確かめるために、結びつける証拠を2つ選ぼう。",
          "Choose two clues that can test Milo’s statement."
        ],
        "result": [
          "リボンと小さな足跡は、ミロがカウンターから裏口へ歩いた可能性を示す。「近づいていない」という証言に確かめたい点がある。",
          "The ribbon and small prints suggest Milo walked from the counter towards the side door. His claim needs checking."
        ]
      },
      {
        "pair": [
          "ticket",
          "door"
        ],
        "title": [
          "ケーキが向かった場所",
          "Where could the cake have gone?"
        ],
        "question": [
          "盗まれた以外の可能性を考えるために、結びつける証拠を2つ選ぼう。",
          "Choose two clues that suggest an explanation besides theft."
        ],
        "result": [
          "涼しい場所で待たせる指示と、庭へ普通に開く裏口。ケーキを日陰へ移した可能性がある。これはまだ仮説。本人の話を確かめよう。",
          "A request to keep it cool, and an intact door to the garden. Someone may have moved it into shade. This is a hypothesis: ask the person."
        ]
      }
    ],
    "questions": [
      {
        "text": [
          "ケーキを運んだのは？",
          "Who carried the cake?"
        ],
        "options": [
          [
            "ベア",
            "Bea"
          ],
          [
            "ミロ",
            "Milo"
          ],
          [
            "ノラ",
            "Nora"
          ]
        ],
        "answer": 1,
        "why": [
          "リボンと足跡、それを示した時の本人の説明を読み返そう。",
          "Compare the ribbon, prints and the person’s explanation."
        ]
      },
      {
        "text": [
          "通った場所は？",
          "Which route did they take?"
        ],
        "options": [
          [
            "裏口から庭へ",
            "Side door to the garden"
          ],
          [
            "窓から外へ",
            "Through the window"
          ],
          [
            "表から広場へ",
            "Front entrance to the square"
          ]
        ],
        "answer": 0,
        "why": [
          "粉の続く先と、壊れていない出入口を確かめよう。",
          "Follow the flour to the intact exit."
        ]
      },
      {
        "text": [
          "なぜケーキを動かした？",
          "Why move the cake?"
        ],
        "options": [
          [
            "ひとりで食べるため",
            "To eat it alone"
          ],
          [
            "日差しからクリームを守るため",
            "To protect the cream"
          ],
          [
            "別の店で売るため",
            "To sell it elsewhere"
          ]
        ],
        "answer": 1,
        "why": [
          "受け取りメモの置き場所の指示に注目しよう。",
          "Read the collection note’s placement instruction."
        ]
      },
      {
        "text": [
          "いつ動かした？",
          "When was it moved?"
        ],
        "options": [
          [
            "止まった壁時計の時刻",
            "At the stopped wall clock’s time"
          ],
          [
            "9時より前",
            "Before nine"
          ],
          [
            "9時5分の窯のベルのあと",
            "After the9:05 oven bell"
          ]
        ],
        "answer": 2,
        "why": [
          "止まった時計は時刻の根拠にならない。窯のベルと裏口の目撃を比べよう。",
          "The stopped clock cannot establish time. Compare the oven bell and the sighting."
        ]
      }
    ],
    "ending": [
      "ケーキは庭の日陰で、無事に待っていた。ミロはクリームを守ろうとしたのだ。ベアはほっと笑った。「次からは、ひと言教えてね」。PIPは、証拠は責めるためでなく、一緒に真実を見つけるためにあるとノートを閉じた。",
      "The cake waited safely in the shaded garden. Milo had tried to protect the cream. Bea smiled: “Next time, let me know.” Pip closed the notebook: evidence helps us find the truth together."
    ],
    "challenge": {
      "statement": [
        "「ミロはカウンターに一度も近づいていない」",
        "“Milo never went near the counter.”"
      ],
      "verdict": "review",
      "pairs": [
        [
          "ribbon",
          "prints"
        ]
      ],
      "explanation": [
        "リボンだけでは持ち主を断定できない。小さな足跡も添えて聞くと、ミロはケーキを裏口から日陰へ運んだと説明した。メモを読んでクリームを守ろうとしたが、間違えたと思い黙っていたのだ。",
        "Colour alone is insufficient. With the ribbon and prints together, Milo explains that he moved the cake through the side door into shade to protect its cream. He feared he had made a mistake."
      ]
    },
    "timeline": [
      {
        "id": 0,
        "text": [
          "ベアがケーキを仕上げる",
          "Bea finishes the cake"
        ],
        "time": [
          "9:00",
          "9:00"
        ]
      },
      {
        "id": 1,
        "text": [
          "窯のベルでベアが奥へ行く",
          "The oven bell calls Bea away"
        ],
        "time": [
          "9:05",
          "9:05"
        ]
      },
      {
        "id": 2,
        "text": [
          "ノラが裏口で青いリボンを見る",
          "Nora sees the ribbon at the side door"
        ],
        "time": [
          "9:10",
          "9:10"
        ]
      }
    ]
  },
  {
    "id": 2,
    "title": [
      "温室の消えた種",
      "The Missing Seeds"
    ],
    "place": [
      "雨あがりの温室",
      "The greenhouse after rain"
    ],
    "image": "greenhouse.webp",
    "intro": [
      "祭りに植える青い花の種が、保管箱から消えた。誰かが持ち出したのだろうか？ 土や水の跡をたどろう。",
      "The blue flower seeds for the festival are missing from their drawer. Follow the soil and water to discover why."
    ],
    "clues": [
      {
        "id": "drawer",
        "pos": [
          65,
          63
        ],
        "name": [
          "空の種の引き出し",
          "The empty seed drawer"
        ],
        "body": [
          "鍵も蝶番も壊れていない。底には乾いた土が少し残り、封筒を引き抜いた跡がある。",
          "The lock and hinges are intact. Dry soil and a clean strip show where an envelope was lifted out."
        ],
        "area": [
          "空の種の引き出し",
          "The empty seed drawer"
        ]
      },
      {
        "id": "envelope",
        "pos": [
          79,
          80
        ],
        "name": [
          "鉢の下の緑の封筒",
          "A green envelope under a pot"
        ],
        "body": [
          "植木鉢の下に空の封筒。「青い花・12粒」とある。口はきれいに開けられ、破れはない。",
          "An empty envelope beneath a pot says “Blue flowers · 12 seeds”. It was opened neatly, not torn."
        ],
        "area": [
          "鉢の下の緑の封筒",
          "A green envelope under a pot"
        ]
      },
      {
        "id": "soil",
        "pos": [
          64,
          49
        ],
        "name": [
          "並んだ12のくぼみ",
          "Twelve little planting holes"
        ],
        "body": [
          "育苗箱の湿った土には12の小さなくぼみ。縁には緑の封筒と同じ紙の繊維がついている。",
          "The damp seed tray has twelve little planting holes. Its rim holds fibres matching the green envelope."
        ],
        "area": [
          "並んだ12のくぼみ",
          "Twelve little planting holes"
        ]
      },
      {
        "id": "water",
        "pos": [
          49,
          81
        ],
        "name": [
          "倒れたじょうろ",
          "The tipped watering can"
        ],
        "body": [
          "じょうろから流れた水は、床ではなく作業台の箱の方へ続いている。ノラが戻った14時10分には、箱の端がまだ濡れていた。",
          "Water ran towards the drawer. When Nora returned at 14:10, its edge was still wet."
        ],
        "area": [
          "倒れたじょうろ",
          "The tipped watering can"
        ]
      },
      {
        "id": "plan",
        "pos": [
          9,
          16
        ],
        "name": [
          "花壇の計画表",
          "The planting plan"
        ],
        "body": [
          "種まきは翌朝8時。青い花は水にぬれたら、その日のうちにまくよう注意書きがある。",
          "Sowing was scheduled for 8am tomorrow. A note says these seeds must be planted the same day if they get wet."
        ],
        "area": [
          "花壇の計画表",
          "The planting plan"
        ]
      },
      {
        "id": "coat",
        "pos": [
          21,
          29
        ],
        "name": [
          "乾いた雨具",
          "The dry raincoat"
        ],
        "body": [
          "裏口の雨具は乾いている。外の道はぬかるんでいるが、室内に外へ往復した泥跡はない。",
          "The raincoat is dry. Outside is muddy, yet there are no muddy tracks from a trip out and back."
        ],
        "area": [
          "乾いた雨具",
          "The dry raincoat"
        ]
      }
    ],
    "people": [
      {
        "id": "bea",
        "role": [
          "花祭りの準備係",
          "Festival organiser"
        ],
        "quote": [
          "「14時にじょうろへ手が当たったの。水を拭いて、PIPを呼びに行ったわ。」",
          "“I knocked the can at two. I wiped the water and went to fetch Pip.”"
        ],
        "detail": [
          "水は引き出しにもかかった。ノラには会えず、種がぬれたことを伝えられなかった。",
          "Water reached the drawer too. I did not meet Nora, so I could not warn her about the seeds."
        ],
        "name": [
          "ベア",
          "Bea"
        ]
      },
      {
        "id": "milo",
        "role": [
          "道具の配達係",
          "Tool courier"
        ],
        "quote": [
          "「13時50分に鉢を届けたよ。その時は土のくぼみはなかった。」",
          "“I brought pots at 1:50. There were no planting holes then.”"
        ],
        "detail": [
          "14時15分に戻ると育苗箱にくぼみがあった。種の封筒は触っていない。",
          "When I returned at 2:15, the tray had holes. I never touched the envelope."
        ],
        "name": [
          "ミロ",
          "Milo"
        ]
      },
      {
        "id": "nora",
        "role": [
          "温室の庭師",
          "Greenhouse gardener"
        ],
        "quote": [
          "「14時10分に戻って水を見たわ。でも明日の準備は何も変えていないの。」",
          "“I returned at 2:10 and saw the water. But I changed none of tomorrow’s preparations.”"
        ],
        "detail": [
          "箱の中の封筒は湿っていた。青い花を育てた経験があり、ぬれた種の扱いも知っている。",
          "The envelope inside was damp. I have grown blue flowers before and know how wet seeds must be handled."
        ],
        "name": [
          "ノラ",
          "Nora"
        ]
      }
    ],
    "links": [
      {
        "pair": [
          "envelope",
          "soil"
        ],
        "title": [
          "種の行き先",
          "Where did the seeds go?"
        ],
        "question": [
          "持ち出されたのではなく、この場所で使われたことを示す証拠を2つ選ぼう。",
          "Choose two clues showing the seeds were used here, rather than taken away."
        ],
        "result": [
          "空の12粒入り封筒と、同じ繊維が残る12のくぼみ。種は育苗箱にまかれたと考えられる。",
          "An empty twelve-seed envelope, matching fibres and twelve holes link the seeds to the tray."
        ]
      },
      {
        "pair": [
          "water",
          "plan"
        ],
        "title": [
          "予定より早い種まき",
          "Why sow early?"
        ],
        "question": [
          "翌朝の予定を変更する必要が生まれた理由は？ 証拠を2つ選ぼう。",
          "Why did the sowing schedule need to change? Choose two clues."
        ],
        "result": [
          "水が箱へ流れ、ぬれた種は当日中にまく必要がある。失敗ではなく、種を守る対応だった可能性がある。",
          "Water reached the drawer; wet seeds must be sown the same day. Early sowing could save them."
        ]
      },
      {
        "pair": [
          "soil",
          "water"
        ],
        "title": [
          "ノラの話を確かめる",
          "Test Nora’s account"
        ],
        "question": [
          "ノラが戻ったあと予定が変わったと考えるために、作業の跡と時刻の手がかりを選ぼう。",
          "Choose the work trace and timing clue that question Nora’s claim that nothing changed."
        ],
        "result": [
          "14時10分に水を見た時と、14時15分にくぼみを見た時を分けると、種が動いた時間帯を絞れる。",
          "Separating the water observation at2:10 from the depressions at2:15 narrows when the seeds moved."
        ]
      }
    ],
    "questions": [
      {
        "text": [
          "種はどこへ？",
          "Where are the seeds?"
        ],
        "options": [
          [
            "外へ持ち去られた",
            "Taken outside"
          ],
          [
            "育苗箱にまかれた",
            "Sown in the tray"
          ],
          [
            "じょうろの中",
            "Inside the can"
          ]
        ],
        "answer": 1,
        "why": [
          "封筒の12粒と、育苗箱の12のくぼみを照合しよう。",
          "Compare the twelve seeds with the twelve holes."
        ]
      },
      {
        "text": [
          "予定を変えた理由は？",
          "Why change the plan?"
        ],
        "options": [
          [
            "雨で祭りが中止",
            "The festival was cancelled"
          ],
          [
            "配達を急ぐため",
            "To hurry a delivery"
          ],
          [
            "ぬれた種を守るため",
            "To save the wet seeds"
          ]
        ],
        "answer": 2,
        "why": [
          "計画表に書かれた「ぬれた種」の注意を読み返そう。",
          "Read the special rule for wet seeds."
        ]
      },
      {
        "text": [
          "種をまいた時間帯は？",
          "When were they sown?"
        ],
        "options": [
          [
            "14時10分〜14時15分",
            "Between 2:10 and 2:15"
          ],
          [
            "13時50分より前",
            "Before 1:50"
          ],
          [
            "翌朝8時",
            "8am tomorrow"
          ]
        ],
        "answer": 0,
        "why": [
          "ノラが水を見つけた時刻と、ミロがくぼみを見た時刻の間。",
          "Between Nora finding the water and Milo seeing the holes."
        ]
      }
    ],
    "ending": [
      "ノラは種をまいた育苗箱を見せてくれた。ベアは「教えてくれてありがとう」と笑う。PIPは、種が消えたのではなく、小さな花の準備が始まったのだとノートに記した。",
      "Nora shows everyone the newly sown tray. Bea thanks her for explaining. Pip writes: the seeds did not vanish; a little garden had begun."
    ],
    "challenge": {
      "statement": [
        "「封筒の種は、育苗箱へまかれた」",
        "“The envelope’s seeds were sown in the seedling tray.”"
      ],
      "verdict": "support",
      "pairs": [
        [
          "envelope",
          "soil"
        ]
      ],
      "explanation": [
        "12粒入りの空の封筒と、同じ繊維が残る12のくぼみが対応する。ノラは、ぬれた種を守るためにまいたと話した。予定変更を伝えそびれたことが、行き違いの原因だった。",
        "The empty twelve-seed envelope matches twelve depressions with the same fibres. Nora explains she sowed the wet seeds to protect them. The missing communication caused the confusion."
      ]
    },
    "timeline": [
      {
        "id": 0,
        "text": [
          "じょうろの水が引き出しへ流れる",
          "Water spills into the drawer"
        ],
        "time": [
          "14:00",
          "14:00"
        ]
      },
      {
        "id": 1,
        "text": [
          "戻ったノラが水に気づく",
          "Nora returns and sees the water"
        ],
        "time": [
          "14:10",
          "14:10"
        ]
      },
      {
        "id": 2,
        "text": [
          "ミロが育苗箱のくぼみを確認する",
          "Milo notices the tray depressions"
        ],
        "time": [
          "14:15",
          "14:15"
        ]
      }
    ]
  },
  {
    "id": 3,
    "title": [
      "灯台の届かなかった手紙",
      "The Undelivered Letter"
    ],
    "place": [
      "夕暮れの灯台書斎",
      "The lighthouse study at dusk"
    ],
    "image": "lighthouse.webp",
    "intro": [
      "灯台の集まりを知らせる手紙が届かない。配達係は届けたと言い、受け取り係は見ていないという。どちらかが嘘をついているのだろうか？",
      "The lighthouse invitation never reached its reader. The courier says it was delivered; the recipient never saw it. Must someone be lying?"
    ],
    "clues": [
      {
        "id": "tray",
        "pos": [
          54,
          47
        ],
        "name": [
          "空の受け取り皿",
          "The empty letter tray"
        ],
        "body": [
          "真鍮の受け取り皿は空。底のほこりには、封筒ほどの長方形だけほこりの薄い部分がある。",
          "The brass tray is empty. A rectangle the size of an envelope is less dusty than its surroundings."
        ],
        "area": [
          "空の受け取り皿",
          "The empty letter tray"
        ]
      },
      {
        "id": "seal",
        "pos": [
          66,
          89
        ],
        "name": [
          "星形の青い封ろう片",
          "A blue star-shaped wax fragment"
        ],
        "body": [
          "皿の下の床に青い封ろうの小片。配達記録にある「青い星の封」と形が合う。",
          "A blue wax fragment below the tray matches the recorded star seal."
        ],
        "area": [
          "星形の青い封ろう片",
          "A blue star-shaped wax fragment"
        ]
      },
      {
        "id": "window",
        "pos": [
          81,
          21
        ],
        "name": [
          "内側へ開いた窓",
          "The open window"
        ],
        "body": [
          "窓のそばの薄いカーテンが本棚の方へなびく。紙はさみは使われておらず、窓は固定されていない。",
          "The curtain blows inwards towards the bookcase. The tray has no paperweight and the window is not latched."
        ],
        "area": [
          "内側へ開いた窓",
          "The open window"
        ]
      },
      {
        "id": "atlas",
        "pos": [
          65,
          82
        ],
        "name": [
          "地図帳の下の白い角",
          "A white corner under the atlas"
        ],
        "body": [
          "床に落ちた地図帳の下に封筒の角。青い星の封がついた、未開封の灯台宛ての手紙が見つかった。",
          "An unopened letter addressed to the lighthouse lies under the fallen atlas, bearing a blue star seal."
        ],
        "area": [
          "地図帳の下の白い角",
          "A white corner under the atlas"
        ]
      },
      {
        "id": "log",
        "pos": [
          8,
          44
        ],
        "name": [
          "配達の控え",
          "The delivery record"
        ],
        "body": [
          "控えには「17時・灯台の受け取り皿・青い星の封」。ミロの署名がある。控えだけでは届いた証明にはならない。",
          "“5pm · lighthouse tray · blue star seal”, signed Milo. The record alone does not prove delivery."
        ],
        "area": [
          "配達の控え",
          "The delivery record"
        ]
      },
      {
        "id": "weather",
        "pos": [
          48,
          17
        ],
        "name": [
          "窓辺の風の記録",
          "The wind observation"
        ],
        "body": [
          "ノラがつけた記録では17時5分に強い海風。その直後、ベアが窓の閉まる音と本の落ちる音を聞いた。",
          "Nora recorded a strong sea gust at 5:05. Bea heard the window bang and a book fall immediately afterwards."
        ],
        "area": [
          "窓辺の風の記録",
          "The wind observation"
        ]
      }
    ],
    "people": [
      {
        "id": "bea",
        "role": [
          "灯台の受け取り係",
          "Lighthouse host"
        ],
        "quote": [
          "「17時10分に戻った時、皿は空だったの。だから配達前だと思ったわ。」",
          "“The tray was empty when I returned at 5:10. I assumed it had not arrived.”"
        ],
        "detail": [
          "17時5分ごろ隣室で、窓が鳴り本が落ちる音を聞いた。手紙を隠してはいない。",
          "At about 5:05 I heard a window bang and a book fall from the next room. I did not hide a letter."
        ],
        "name": [
          "ベア",
          "Bea"
        ]
      },
      {
        "id": "milo",
        "role": [
          "手紙の配達係",
          "Letter courier"
        ],
        "quote": [
          "「17時に青い星の封の手紙を、真鍮の皿に置いたよ。」",
          "“At five I placed the blue-star letter in the brass tray.”"
        ],
        "detail": [
          "窓は開いていた。重しを置くのを忘れた。宛先は灯台で間違いない。",
          "The window was open. I forgot to weigh it down. The address definitely said lighthouse."
        ],
        "name": [
          "ミロ",
          "Milo"
        ]
      },
      {
        "id": "nora",
        "role": [
          "港の観測係",
          "Harbour observer"
        ],
        "quote": [
          "「17時5分、海から強い風が吹いたわ。灯台の窓も開いていた。」",
          "“At 5:05 a strong sea gust blew in. The lighthouse window was open.”"
        ],
        "detail": [
          "自分の観測時刻を記録している。手紙も地図帳も触っていない。",
          "I wrote down the observation time. I never touched the letter or atlas."
        ],
        "name": [
          "ノラ",
          "Nora"
        ]
      }
    ],
    "links": [
      {
        "pair": [
          "log",
          "seal"
        ],
        "title": [
          "配達された証拠",
          "Was it delivered?"
        ],
        "question": [
          "配達係の記録を、現場にある物と照合しよう。証拠を2つ選んで。",
          "Support the courier’s written record with a physical trace. Choose two clues."
        ],
        "result": [
          "配達控えに書かれた青い星の封と、皿の下の封ろう片が一致。手紙がこの場所へ来たことを裏づける。",
          "The recorded blue star seal matches the wax fragment under the tray, supporting delivery."
        ]
      },
      {
        "pair": [
          "window",
          "weather"
        ],
        "title": [
          "誰も触らず動くもの",
          "What can move without a person?"
        ],
        "question": [
          "手紙が人の手によらず移動した原因と、その時間を結びつけよう。",
          "Connect the cause of movement with the time it occurred."
        ],
        "result": [
          "開いた窓と17時5分の突風。軽い手紙は本棚側へ吹き飛ばされうる。",
          "An open window and the 5:05 gust could carry a light envelope towards the bookcase."
        ]
      },
      {
        "pair": [
          "atlas",
          "tray"
        ],
        "title": [
          "空だった理由",
          "Why was the tray empty?"
        ],
        "question": [
          "手紙の元の場所と、最後に見つかった場所を示す証拠を選ぼう。",
          "Choose the clues showing the starting place and the final location."
        ],
        "result": [
          "皿の封筒形の跡と、地図帳の下の未開封の手紙。空の皿を見ただけで「未配達」とは言えない。",
          "The envelope-shaped trace and the unopened letter under the atlas explain the empty tray without assuming non-delivery."
        ]
      }
    ],
    "questions": [
      {
        "text": [
          "手紙を動かしたのは？",
          "What moved the letter?"
        ],
        "options": [
          [
            "ベアが隠した",
            "Bea hid it"
          ],
          [
            "窓から入った風",
            "Wind through the window"
          ],
          [
            "ミロが持ち帰った",
            "Milo took it back"
          ]
        ],
        "answer": 1,
        "why": [
          "窓から本棚へ向かう風と、突風の記録をつなげよう。",
          "Connect the inward curtain with the gust."
        ]
      },
      {
        "text": [
          "移動した時刻は？",
          "When did it move?"
        ],
        "options": [
          [
            "17時10分のあと",
            "After 5:10"
          ],
          [
            "配達前",
            "Before delivery"
          ],
          [
            "17時5分ごろ",
            "Around 5:05"
          ]
        ],
        "answer": 2,
        "why": [
          "観測の記録と、窓と本の音がした時刻を確認しよう。",
          "Compare the gust record with the window and book sounds."
        ]
      },
      {
        "text": [
          "どうすれば防げた？",
          "What would have prevented it?"
        ],
        "options": [
          [
            "窓を固定し、手紙に重しを置く",
            "Latch the window and weigh letters down"
          ],
          [
            "配達記録をやめる",
            "Stop keeping delivery records"
          ],
          [
            "受け取り皿をなくす",
            "Remove the letter tray"
          ]
        ],
        "answer": 0,
        "why": [
          "原因に直接働きかける方法を選ぼう。",
          "Choose a precaution that addresses the actual cause."
        ]
      }
    ],
    "ending": [
      "手紙は未開封のまま見つかった。誰も嘘をついていなかったのだ。窓を固定し、受け取り皿に小さな貝殻の重しを置くと、灯台の集まりは無事に始まった。PIPは「見えていないことと、起きていないことは違う」と記した。",
      "The letter is found unopened. Nobody had lied. With the window latched and a shell paperweight on the tray, the gathering can begin. Pip writes: not seeing something does not mean it never happened."
    ],
    "challenge": {
      "statement": [
        "「皿が空なので、手紙はまだ配達されていない」",
        "“The tray is empty, so the letter has not been delivered.”"
      ],
      "verdict": "review",
      "pairs": [
        [
          "log",
          "seal"
        ],
        [
          "atlas",
          "tray"
        ]
      ],
      "explanation": [
        "配達記録と封ろう片が手紙の到着を裏づけ、地図帳の下には未開封の手紙がある。空の皿という一場面だけで、未配達とは決められない。",
        "The delivery record and wax support arrival; an unopened letter is under the atlas. An empty tray alone cannot establish non-delivery."
      ]
    },
    "timeline": [
      {
        "id": 0,
        "text": [
          "ミロが手紙を皿に置く",
          "Milo puts the letter on the tray"
        ],
        "time": [
          "17:00",
          "17:00"
        ]
      },
      {
        "id": 1,
        "text": [
          "海から強い風が吹く",
          "A strong sea gust blows"
        ],
        "time": [
          "17:05",
          "17:05"
        ]
      },
      {
        "id": 2,
        "text": [
          "ベアが戻って空の皿を見る",
          "Bea returns to an empty tray"
        ],
        "time": [
          "17:10",
          "17:10"
        ]
      }
    ]
  },
  {
    "id": 4,
    "title": [
      "オルゴールの違うメロディ",
      "The Music Box Mix-up"
    ],
    "place": [
      "港のオルゴール工房",
      "The harbour music-box workshop"
    ],
    "image": "workshop.webp",
    "intro": [
      "お祝いに流すはずの「星のワルツ」が、いつの間にか別の曲に。壊れたのか、それとも誰かが仕組みを変えたのか。工房の記録を調べよう。",
      "The celebration music box plays a different tune instead of the Star Waltz. Is it broken, or has something changed inside? Follow the workshop records."
    ],
    "clues": [
      {
        "id": "box",
        "pos": [
          49,
          55
        ],
        "name": [
          "オルゴールの中",
          "Inside the music box"
        ],
        "body": [
          "中の円筒には三日月の刻印。回転はなめらかで、同じ旋律を毎回くり返す。歯車の破損や音飛びはない。",
          "The installed cylinder has a crescent mark. It rotates smoothly and repeats the same tune every time, without skipped notes or damaged gears."
        ],
        "area": [
          "オルゴールの中",
          "Inside the music box"
        ]
      },
      {
        "id": "spare",
        "pos": [
          83,
          58
        ],
        "name": [
          "机に残った交換用円筒",
          "The spare cylinder"
        ],
        "body": [
          "クッションの上の円筒には星の刻印。試聴すると、ベアが頼んだ「星のワルツ」が正しく流れた。",
          "The spare on the cushion is marked with a star. Testing it plays exactly the Star Waltz Bea requested."
        ],
        "area": [
          "机に残った交換用円筒",
          "The spare cylinder"
        ]
      },
      {
        "id": "cases",
        "pos": [
          77,
          78
        ],
        "name": [
          "よく似た2つの運搬箱",
          "Two similar carrying cases"
        ],
        "body": [
          "同じ大きさの箱が2つ。内側には星と三日月の印があるが、ふたを閉めると区別しにくい。三日月の箱が空だ。",
          "The equally sized cases are marked star and crescent inside. Their closed lids look alike. The crescent case is empty."
        ],
        "area": [
          "よく似た2つの運搬箱",
          "Two similar carrying cases"
        ]
      },
      {
        "id": "score",
        "pos": [
          28,
          70
        ],
        "name": [
          "演奏会の注文帳",
          "The concert order book"
        ],
        "body": [
          "注文は「星のワルツ・星の円筒」。もう一方の「月の子守歌」は別の日の注文だ。",
          "The order specifies “Star Waltz · star cylinder”. The Moon Lullaby is a separate order for another day."
        ],
        "area": [
          "演奏会の注文帳",
          "The concert order book"
        ]
      },
      {
        "id": "check",
        "pos": [
          37,
          73
        ],
        "name": [
          "ノラの試聴記録",
          "Nora’s test record"
        ],
        "body": [
          "ノラは10時に星と月を別々に試聴し、両方とも正常と記録。円筒を印の合う箱へ戻している。",
          "At ten Nora tested both tunes, recorded that both worked, and returned each cylinder to its matching marked case."
        ],
        "area": [
          "ノラの試聴記録",
          "Nora’s test record"
        ]
      },
      {
        "id": "tools",
        "pos": [
          49,
          78
        ],
        "name": [
          "交換工具の記録",
          "The tool sign-out"
        ],
        "body": [
          "交換用の鍵は10時5分〜10時10分だけミロに貸し出されていた。ベアが違う曲を聞いたのは10時15分。",
          "The cylinder-changing key was signed out to Milo from 10:05 to 10:10. Bea heard the wrong tune at 10:15."
        ],
        "area": [
          "交換工具の記録",
          "The tool sign-out"
        ]
      }
    ],
    "people": [
      {
        "id": "bea",
        "role": [
          "お祝いの主催者",
          "Celebration organiser"
        ],
        "quote": [
          "「頼んだ曲とは違うけれど、途中で止まったりはしないの。」",
          "“It is not the tune I ordered, but it never sticks or stops.”"
        ],
        "detail": [
          "注文したのは星のワルツ。10時15分に初めて再生し、月の子守歌だと気づいた。",
          "I ordered the Star Waltz. I first played the box at 10:15 and recognised the Moon Lullaby."
        ],
        "name": [
          "ベア",
          "Bea"
        ]
      },
      {
        "id": "milo",
        "role": [
          "箱を運ぶ配達係",
          "Carrying-case courier"
        ],
        "quote": [
          "「10時5分に鍵を借りて円筒を入れたよ。箱の中の印は見なかった。」",
          "“I borrowed the key at 10:05 and fitted a cylinder. I did not look at the mark inside its case.”"
        ],
        "detail": [
          "10時10分に鍵を返した。外見が同じ箱を取り違えたかもしれない。曲を聞いてから渡すべきだった、と話す。",
          "I returned the key at 10:10. I may have picked the wrong similar case. I should have listened before handing it over."
        ],
        "name": [
          "ミロ",
          "Milo"
        ]
      },
      {
        "id": "nora",
        "role": [
          "工房の点検係",
          "Workshop tester"
        ],
        "quote": [
          "「10時の点検では、2本とも正しい曲で鳴ったわ。」",
          "“At the ten o’clock test both cylinders played their own tunes correctly.”"
        ],
        "detail": [
          "10時の点検後は工具を使っていない。曲の違いは円筒の突起の並びで決まり、速さだけ変えても別の曲にはならない。",
          "I used no tools after the test. The pins on a cylinder determine its tune; changing speed alone will not produce the other tune."
        ],
        "name": [
          "ノラ",
          "Nora"
        ]
      }
    ],
    "links": [
      {
        "pair": [
          "box",
          "spare"
        ],
        "title": [
          "故障か、取り違えか",
          "Broken or mixed up?"
        ],
        "question": [
          "なめらかな別の曲と、机に残った正しい曲。原因を確かめる証拠を2つ選ぼう。",
          "Choose the two clues that distinguish a fault from the wrong cylinder."
        ],
        "result": [
          "中には月の円筒、机には正常な星の円筒。機械の故障より、入れる円筒の取り違えが説明に合う。",
          "The moon cylinder is installed while the working star cylinder remains on the desk. A cylinder mix-up explains the change."
        ]
      },
      {
        "pair": [
          "cases",
          "score"
        ],
        "title": [
          "本来入れるはずだったもの",
          "What should have been fitted?"
        ],
        "question": [
          "運ぶ箱の目印と注文の内容を照合しよう。",
          "Compare the case markings with the customer’s order."
        ],
        "result": [
          "注文は星の円筒。でも空なのは三日月の箱。外見が似ていても、中の印を確認すれば取り違えを防げた。",
          "The order calls for the star cylinder, but the crescent case is empty. Checking the inside marks would have prevented the mix-up."
        ]
      },
      {
        "pair": [
          "check",
          "tools"
        ],
        "title": [
          "入れ替わった時間",
          "When did it change?"
        ],
        "question": [
          "正常だった点検と、交換できた時間をつなげよう。",
          "Connect the last correct test with the time the cylinder could be changed."
        ],
        "result": [
          "点検後の10時5分〜10時10分に円筒が交換され、その後に曲の違いが確認された。交換した物と、本体の故障を分けて考えよう。",
          "The cylinder changed at10:05–10:10 after inspection; the different tune was noticed later. Separate the changed component from a fault in the mechanism."
        ]
      }
    ],
    "questions": [
      {
        "text": [
          "違う曲になった原因は？",
          "Why did the tune change?"
        ],
        "options": [
          [
            "歯車が欠けた",
            "A broken gear"
          ],
          [
            "回転が速すぎた",
            "Too much speed"
          ],
          [
            "別の曲の円筒を入れた",
            "The other tune’s cylinder was fitted"
          ]
        ],
        "answer": 2,
        "why": [
          "中の刻印と、机で試聴した円筒を比べよう。",
          "Compare the installed mark with the tested spare."
        ]
      },
      {
        "text": [
          "取り違えた時間は？",
          "When did the mix-up occur?"
        ],
        "options": [
          [
            "10時5分〜10時10分",
            "Between 10:05 and 10:10"
          ],
          [
            "10時の点検より前",
            "Before the ten o’clock test"
          ],
          [
            "10時15分の試聴後",
            "After the 10:15 playback"
          ]
        ],
        "answer": 0,
        "why": [
          "点検記録と交換工具の貸し出しをつなげよう。",
          "Compare the test record with the tool sign-out."
        ]
      },
      {
        "text": [
          "確実な再発防止は？",
          "How can it be prevented?"
        ],
        "options": [
          [
            "同じ箱を全部捨てる",
            "Throw away all the cases"
          ],
          [
            "中の印と注文を確認して試聴する",
            "Check the mark and order, then listen"
          ],
          [
            "音量を下げる",
            "Turn down the volume"
          ]
        ],
        "answer": 1,
        "why": [
          "箱の外見だけに頼らず、内容を確かめる方法を選ぼう。",
          "Choose a check of the contents, not just the outside."
        ]
      }
    ],
    "ending": [
      "星のワルツが工房に流れた。ミロは箱の外にも印を付け、次は必ず試聴すると約束した。PIPは「似ていることと、同じものであることは違う」とノートに書いた。",
      "The Star Waltz fills the workshop. Milo marks the outside of both cases and promises to listen next time. Pip writes: looking alike does not make two things the same."
    ],
    "challenge": {
      "statement": [
        "「違う曲の原因は、入れた円筒の取り違え」",
        "“The different tune comes from the wrong cylinder.”"
      ],
      "verdict": "support",
      "pairs": [
        [
          "box",
          "spare"
        ]
      ],
      "explanation": [
        "本体は途切れずに鳴り、月の円筒が中にあり、正常な星の円筒が机に残っている。ミロは箱の中の印を見なかったと説明し、正しい円筒へ交換した。",
        "The mechanism plays continuously. The moon cylinder is inside; the working star cylinder remains on the desk. Milo explains he missed the inner mark and changes to the correct cylinder."
      ]
    },
    "timeline": [
      {
        "id": 0,
        "text": [
          "ノラが2本の円筒を点検する",
          "Nora tests both cylinders"
        ],
        "time": [
          "10:00",
          "10:00"
        ]
      },
      {
        "id": 1,
        "text": [
          "ミロが円筒を交換する",
          "Milo changes the cylinder"
        ],
        "time": [
          "10:05〜10:10",
          "10:05–10:10"
        ]
      },
      {
        "id": 2,
        "text": [
          "ベアが違う曲に気づく",
          "Bea hears the wrong tune"
        ],
        "time": [
          "10:15",
          "10:15"
        ]
      }
    ]
  },
  {
    "id": 5,
    "title": [
      "列車のいない駅の汽笛",
      "The Whistle Before the Train"
    ],
    "place": [
      "海辺の小さな駅",
      "The little seaside station"
    ],
    "image": "station.webp",
    "intro": [
      "列車が来ていないのに、駅で汽笛が響いた。乗り遅れたと思ったミロは大あわて。音のした方向だけで決めつけず、現場を調べよう。",
      "A whistle sounds at the station before any train arrives. Milo thinks he has missed his ride. Explore the scene before trusting the direction of a sound."
    ],
    "clues": [
      {
        "id": "kettle",
        "pos": [
          95,
          49
        ],
        "name": [
          "まだ温かいやかん",
          "The warm kettle"
        ],
        "body": [
          "お茶用のやかんには、蒸気で鳴る笛のふたが付いている。火を落としたあとも温かく、中には沸いた湯が残る。",
          "The tea kettle has a steam-whistle cap. It is still warm after the stove was turned down, with recently boiled water inside."
        ],
        "area": [
          "まだ温かいやかん",
          "The warm kettle"
        ]
      },
      {
        "id": "cap",
        "pos": [
          91,
          41
        ],
        "name": [
          "やかんの笛の試聴",
          "Testing the kettle whistle"
        ],
        "body": [
          "ベアに頼んで安全にもう一度湯を沸かすと、先ほどと同じ高い音が鳴った。小さな笛だけでも音が出る。",
          "With Bea’s help, a safe repeat boil produces the same high note heard earlier. The small whistle can make the sound on its own."
        ],
        "area": [
          "やかんの笛の試聴",
          "Testing the kettle whistle"
        ]
      },
      {
        "id": "vent",
        "pos": [
          92,
          13
        ],
        "name": [
          "ひさしにつながる換気口",
          "The vent to the canopy"
        ],
        "body": [
          "ストーブ上の換気口はホームの金属のひさしへ通じる。やかんが鳴ると、音がそこから広がり列車側から聞こえる。",
          "The vent above the stove leads to the platform’s metal canopy. The kettle’s note spreads from there, sounding as though it comes from the tracks."
        ],
        "area": [
          "ひさしにつながる換気口",
          "The vent to the canopy"
        ]
      },
      {
        "id": "board",
        "pos": [
          12,
          20
        ],
        "name": [
          "運行の掲示",
          "The service notice"
        ],
        "body": [
          "次の列車は15時15分まで隣の駅で待機中。駅係への照会でも、15時5分にはまだ出発していなかったと確認できた。",
          "The next train was held at the neighbouring station until 3:15. A check with the station confirms it had not left at 3:05."
        ],
        "area": [
          "運行の掲示",
          "The service notice"
        ]
      },
      {
        "id": "tea",
        "pos": [
          35,
          43
        ],
        "name": [
          "お茶の準備メモ",
          "The tea preparation note"
        ],
        "body": [
          "ベアのメモは「15時に火を入れる、15時5分に沸騰」。15時5分の欄に完了の印がある。",
          "Bea’s note says “Heat at 3:00; boil at 3:05”, with the 3:05 step marked complete."
        ],
        "area": [
          "お茶の準備メモ",
          "The tea preparation note"
        ]
      },
      {
        "id": "rail",
        "pos": [
          76,
          56
        ],
        "name": [
          "ホームの確認",
          "Checking the platform"
        ],
        "body": [
          "PIPはホームを見回った。列車も機関車の蒸気もなく、ノラはホーム全体を15時から見ていたと証言している。",
          "Pip checks the platform: no train and no locomotive steam. Nora says she watched the whole platform from three onwards."
        ],
        "area": [
          "ホームの確認",
          "Checking the platform"
        ]
      }
    ],
    "people": [
      {
        "id": "bea",
        "role": [
          "待合室のお茶係",
          "Waiting-room tea helper"
        ],
        "quote": [
          "「15時に火を入れて、15時5分にお湯が沸いたの。そのあと火を弱めたわ。」",
          "“I lit the stove at three. The water boiled at 3:05, then I turned the heat down.”"
        ],
        "detail": [
          "このやかんは沸くと笛が鳴る。待合室の外では、ひさしの方から響くことがある。",
          "This kettle whistles when it boils. Outside the waiting room, its sound can seem to come from the canopy."
        ],
        "name": [
          "ベア",
          "Bea"
        ]
      },
      {
        "id": "milo",
        "role": [
          "列車を待つ配達係",
          "Courier waiting for the train"
        ],
        "quote": [
          "「15時5分に列車側から高い音を聞いた。姿は見ていないけれど、発車の合図だと思ったよ。」",
          "“At 3:05 I heard a high note from the tracks. I saw no train, but assumed it was departing.”"
        ],
        "detail": [
          "音を聞いた瞬間は配達袋を見ていて、ホームを見ていなかった。音色はやかんの試聴と同じだったと確認してくれた。",
          "I was looking at my delivery bag, not the platform. On hearing the kettle test, I confirm it is the same note."
        ],
        "name": [
          "ミロ",
          "Milo"
        ]
      },
      {
        "id": "nora",
        "role": [
          "ホームの花の世話係",
          "Platform gardener"
        ],
        "quote": [
          "「15時からホームの花に水をあげていたけれど、列車は来ていないわ。」",
          "“I watered the platform flowers from three. No train arrived.”"
        ],
        "detail": [
          "15時5分の音のあとも線路は空だった。次の列車の照会を手伝い、隣の駅にいることを確かめた。",
          "The tracks were still empty after the sound. I helped confirm the next train was still at the neighbouring station."
        ],
        "name": [
          "ノラ",
          "Nora"
        ]
      }
    ],
    "links": [
      {
        "pair": [
          "kettle",
          "cap"
        ],
        "title": [
          "同じ音を出すもの",
          "What makes that same note?"
        ],
        "question": [
          "現場に残る熱と、再現した音をつなげよう。",
          "Connect the remaining heat with the reproduced note."
        ],
        "result": [
          "沸いたやかんと、その笛で同じ音を再現できた。音源は列車でなく、待合室のやかんだった。",
          "The warm kettle and its tested whistle reproduce the sound. The source was the waiting-room kettle."
        ]
      },
      {
        "pair": [
          "vent",
          "rail"
        ],
        "title": [
          "音が聞こえた場所",
          "Where did the sound seem to come from?"
        ],
        "question": [
          "音の通り道と、列車がいなかった現場を照合しよう。",
          "Compare the route of the sound with the empty platform."
        ],
        "result": [
          "換気口を通った音がホームのひさしから響いた。聞こえた方向に音源そのものがあるとは限らない。",
          "The sound spread through the vent and canopy. Its apparent direction did not reveal its actual source."
        ]
      },
      {
        "pair": [
          "board",
          "tea"
        ],
        "title": [
          "15時5分に起きたこと",
          "What happened at 3:05?"
        ],
        "question": [
          "列車の運行時刻と、待合室で起きた出来事をつなげよう。",
          "Compare the train’s timing with the event in the waiting room."
        ],
        "result": [
          "15時5分には列車は隣の駅。ちょうどお湯が沸いた時刻だった。ミロが聞いた音は、時刻の記録からもやかんで説明できる。",
          "The train was still at the next station at 3:05, exactly when the water boiled. The timing independently supports the kettle explanation."
        ]
      }
    ],
    "questions": [
      {
        "text": [
          "汽笛のような音の正体は？",
          "What was the whistle?"
        ],
        "options": [
          [
            "待合室のやかん",
            "The waiting-room kettle"
          ],
          [
            "通り過ぎた列車",
            "A passing train"
          ],
          [
            "誰かのいたずら笛",
            "A prank whistle"
          ]
        ],
        "answer": 0,
        "why": [
          "温かい湯と、同じ音を再現した試聴を思い出そう。",
          "Recall the hot water and the matching test note."
        ]
      },
      {
        "text": [
          "列車側から聞こえた理由は？",
          "Why did it sound track-side?"
        ],
        "options": [
          [
            "列車が透明だった",
            "The train was invisible"
          ],
          [
            "ミロが時刻を間違えた",
            "Milo had the wrong time"
          ],
          [
            "換気口とひさしを通って響いた",
            "The vent and canopy carried the sound"
          ]
        ],
        "answer": 2,
        "why": [
          "音源と音が広がる場所を分けて考えよう。",
          "Separate the source from where the sound spreads."
        ]
      },
      {
        "text": [
          "ミロは乗り遅れていた？",
          "Had Milo missed his train?"
        ],
        "options": [
          [
            "すでに出発していた",
            "Yes, it had departed"
          ],
          [
            "まだ隣の駅にいて乗り遅れていない",
            "No, it was still at the next station"
          ],
          [
            "音だけでは必ず乗り遅れ",
            "Any whistle means he missed it"
          ]
        ],
        "answer": 1,
        "why": [
          "運行の掲示と駅係の確認を読み返そう。",
          "Revisit the notice and station confirmation."
        ]
      }
    ],
    "ending": [
      "ミロはほっとして、温かいお茶をひと口。15時15分を過ぎて本物の列車が到着すると、今度は姿と掲示を確認して乗り込んだ。PIPは「聞こえた場所と、音が生まれた場所を比べよう」と記した。",
      "Relieved, Milo sips some tea. When the real train arrives after 3:15, he checks both the train and the notice before boarding. Pip writes: compare where a sound is heard with where it is made."
    ],
    "challenge": {
      "statement": [
        "「音が聞こえた方向と、音源の場所は同じとは限らない」",
        "“The apparent direction of a sound need not be its source.”"
      ],
      "verdict": "support",
      "pairs": [
        [
          "vent",
          "rail"
        ]
      ],
      "explanation": [
        "換気口とひさしを通って、やかんの音が列車側から響いた。運行掲示と沸いた時刻も合わせれば、列車の発車と考える必要はない。",
        "The vent and canopy carried the kettle’s sound towards the tracks. The train notice and boiling time independently support that explanation."
      ]
    },
    "timeline": [
      {
        "id": 0,
        "text": [
          "ベアがやかんを火にかける",
          "Bea starts heating the kettle"
        ],
        "time": [
          "15:00",
          "15:00"
        ]
      },
      {
        "id": 1,
        "text": [
          "お湯が沸き、高い音が響く",
          "Water boils and a whistle sounds"
        ],
        "time": [
          "15:05",
          "15:05"
        ]
      },
      {
        "id": 2,
        "text": [
          "本物の列車が到着する",
          "The actual train arrives"
        ],
        "time": [
          "15:15以降",
          "After15:15"
        ]
      }
    ]
  },
  {
    "id": 6,
    "title": [
      "美術館の青い月",
      "The Museum’s Blue Moon"
    ],
    "place": [
      "夜の小さな美術館",
      "The little museum at night"
    ],
    "image": "gallery.webp",
    "intro": [
      "白かった月の彫刻が、夕方から青く見える。入れ替えられたのか、それとも別の理由？ 色だけに頼らず、形と展示の記録を調べよう。",
      "A white moon sculpture appears blue after sunset. Has it been replaced? Compare its shape and the exhibition records instead of trusting colour alone."
    ],
    "clues": [
      {
        "id": "moon",
        "pos": [
          74,
          47
        ],
        "name": [
          "月に並ぶ金色の星",
          "The moon’s gold star pattern"
        ],
        "body": [
          "三日月の縁に金色の星が並ぶ。今朝の下絵にも同じ位置と並びで描かれている。台座の模様と全体の大きさも一致する。",
          "Gold stars line the crescent’s edge. Their placement matches this morning’s sketch. The base pattern and overall size match too."
        ],
        "area": [
          "月に並ぶ金色の星",
          "The moon’s gold star pattern"
        ]
      },
      {
        "id": "sketch",
        "pos": [
          10,
          47
        ],
        "name": [
          "今朝の彫刻の下絵",
          "The morning sketch"
        ],
        "body": [
          "下絵は白い三日月。星の並びと、台座の小さな模様が詳しく記録されている。",
          "The sketch records a white crescent with a distinctive arrangement of stars and a small pattern on the base."
        ],
        "area": [
          "今朝の彫刻の下絵",
          "The morning sketch"
        ]
      },
      {
        "id": "seal",
        "pos": [
          67,
          68
        ],
        "name": [
          "展示ケースの封印",
          "The case seal"
        ],
        "body": [
          "扉の封印は今朝から破れておらず、鍵の貸し出しもない。ケースの別の開口部も見当たらない。",
          "The door’s seal is intact from this morning. The key was never signed out, and there is no other opening in the case."
        ],
        "area": [
          "展示ケースの封印",
          "The case seal"
        ]
      },
      {
        "id": "lamp",
        "pos": [
          86,
          9
        ],
        "name": [
          "青いフィルターの照明",
          "The blue-filtered spotlight"
        ],
        "body": [
          "照明の前に青いガラスがある。ノラに向きを変えてもらうと、月の青みが薄れ、白い姿が見える。",
          "Blue glass sits in front of the lamp. When Nora adjusts the light, the moon loses its blue tint and appears white again."
        ],
        "area": [
          "青いフィルターの照明",
          "The blue-filtered spotlight"
        ]
      },
      {
        "id": "cloth",
        "pos": [
          57,
          61
        ],
        "name": [
          "光の境目にある白い布",
          "White cloth across the light boundary"
        ],
        "body": [
          "同じ白い布でも、青い光の中にある部分だけ青く見える。暖色の壁灯側は白いままだ。",
          "The same white cloth looks blue only within the blue beam. The part under the warm wall lamp remains white."
        ],
        "area": [
          "光の境目にある白い布",
          "White cloth across the light boundary"
        ]
      },
      {
        "id": "ledger",
        "pos": [
          26,
          38
        ],
        "name": [
          "照明の作業記録",
          "The lighting work record"
        ],
        "body": [
          "18時に「月の展示へ青いフィルターを設置」。彫刻の交換の記録はない。ミロが青い月を見たのは18時5分。",
          "At six: “Fit a blue filter for the moon display.” No sculpture replacement is recorded. Milo saw the blue moon at 6:05."
        ],
        "area": [
          "照明の作業記録",
          "The lighting work record"
        ]
      }
    ],
    "people": [
      {
        "id": "bea",
        "role": [
          "美術館の案内係",
          "Museum guide"
        ],
        "quote": [
          "「17時50分に見た月は白かったわ。ずっと同じ作品だと思っていたのに。」",
          "“The moon looked white at 5:50. I thought it was the same artwork all along.”"
        ],
        "detail": [
          "朝に展示ケースを閉めて封印した。鍵は受付の保管庫にあり、その後誰にも貸していない。",
          "I sealed the case in the morning. Its key stayed at reception and was not lent to anyone."
        ],
        "name": [
          "ベア",
          "Bea"
        ]
      },
      {
        "id": "milo",
        "role": [
          "閉館前の来館者",
          "Evening visitor"
        ],
        "quote": [
          "「18時5分には青かったよ。白い月と別の物だと思った。」",
          "“It looked blue at 6:05. I thought it must be a different moon.”"
        ],
        "detail": [
          "形や封印はよく見ず、色だけで入れ替わったと思った。月に触っても、ケースを開けてもいない。",
          "I assumed replacement from the colour, without checking the shape or seal. I never touched it or opened the case."
        ],
        "name": [
          "ミロ",
          "Milo"
        ]
      },
      {
        "id": "nora",
        "role": [
          "展示の照明係",
          "Exhibition lighting helper"
        ],
        "quote": [
          "「18時に夜の展示用の青いガラスを照明へ入れたわ。」",
          "“At six I fitted blue glass to the lamp for the evening display.”"
        ],
        "detail": [
          "彫刻には触れていない。PIPの前で照明をずらすと、月は白に戻った。同じ場所で布を使っても色が変わる。",
          "I did not touch the sculpture. Moving the beam in front of Pip makes the moon white again. A cloth changes colour in the same spot too."
        ],
        "name": [
          "ノラ",
          "Nora"
        ]
      }
    ],
    "links": [
      {
        "pair": [
          "moon",
          "sketch"
        ],
        "title": [
          "同じ作品か確かめる",
          "Is it the same artwork?"
        ],
        "question": [
          "色以外で照合できる特徴を、現物と記録から選ぼう。",
          "Match a feature other than colour between the object and its record."
        ],
        "result": [
          "星の位置と並び、台座の模様が下絵と一致する。同じ作品だと考える具体的な根拠がある。",
          "The star arrangement and base pattern match the sketch: specific evidence for the same artwork."
        ]
      },
      {
        "pair": [
          "lamp",
          "cloth"
        ],
        "title": [
          "色を変えたもの",
          "What changed the colour?"
        ],
        "question": [
          "作品に触れずに色が変わる実験と、別の白い物での確認をつなげよう。",
          "Connect the non-contact light test with the check on another white object."
        ],
        "result": [
          "光をずらすと月が白く戻り、同じ青い光で布も青く見える。作品の交換ではなく照明の影響だ。",
          "Moving the beam makes the moon white; the same beam makes cloth blue. Lighting, rather than replacement, explains the change."
        ]
      },
      {
        "pair": [
          "seal",
          "ledger"
        ],
        "title": [
          "18時に変わった展示",
          "What changed at six?"
        ],
        "question": [
          "ケースを開けた痕跡と、その時刻の作業記録を照合しよう。",
          "Compare access to the case with the work recorded at that time."
        ],
        "result": [
          "封印は無傷で、18時に変えたのは照明のフィルター。17時50分の白い月と18時5分の青い月は、その作業を挟んで見られた。",
          "The seal is intact; only the light filter changed at six. The white moon at 5:50 and blue moon at 6:05 were seen on opposite sides of that change."
        ]
      }
    ],
    "questions": [
      {
        "text": [
          "青く見えた原因は？",
          "Why did it look blue?"
        ],
        "options": [
          [
            "青い塗料を塗った",
            "It was painted blue"
          ],
          [
            "青いフィルターの照明",
            "The blue-filtered light"
          ],
          [
            "作品が入れ替わった",
            "The sculpture was replaced"
          ]
        ],
        "answer": 1,
        "why": [
          "照明の実験と、白い布の見え方を思い出そう。",
          "Recall the beam test and the white cloth."
        ]
      },
      {
        "text": [
          "同じ作品だと照合できる特徴は？",
          "Which feature identifies the same sculpture?"
        ],
        "options": [
          [
            "下絵と同じ金色の星の並び",
            "The gold star pattern matching the sketch"
          ],
          [
            "ミロの服の色",
            "Milo’s clothes"
          ],
          [
            "閉館時刻",
            "Closing time"
          ]
        ],
        "answer": 0,
        "why": [
          "色ではなく、形に残る固有の特徴を選ぼう。",
          "Choose a distinctive physical shape, rather than colour."
        ]
      },
      {
        "text": [
          "見え方が変わったのはいつ？",
          "When did its appearance change?"
        ],
        "options": [
          [
            "今朝の封印前",
            "Before the morning seal"
          ],
          [
            "18時5分の来館後",
            "After the 6:05 visit"
          ],
          [
            "18時の照明作業",
            "During the six o’clock lighting work"
          ]
        ],
        "answer": 2,
        "why": [
          "白く見た時刻と青く見た時刻の間の作業を確認しよう。",
          "Check the work between the white and blue sightings."
        ]
      }
    ],
    "ending": [
      "ノラは夜の照明の説明を展示に添えた。白い月も青い月も、同じ一つの作品だった。ミロは色だけで決めつけたことに気づく。PIPは「見え方が変わった時は、見る条件も調べよう」とノートを閉じた。",
      "Nora adds an explanation of the evening lighting. The white moon and blue moon are one artwork. Milo realises colour alone misled him. Pip closes the notebook: when appearances change, investigate the viewing conditions too."
    ],
    "challenge": {
      "statement": [
        "「青く見える月は、別の作品に入れ替えられた」",
        "“The blue-looking moon has been replaced.”"
      ],
      "verdict": "review",
      "pairs": [
        [
          "moon",
          "sketch"
        ],
        [
          "seal",
          "ledger"
        ],
        [
          "lamp",
          "cloth"
        ]
      ],
      "explanation": [
        "固有の星の並びと封印は同じ作品を示す。光をずらす実験と白い布でも色が変わる確認が、照明の影響を裏づけた。色だけで交換と決めつけることはできない。",
        "The distinctive stars and intact seal support the same object. Moving the beam and checking white cloth establish the lighting effect. Colour alone cannot establish replacement."
      ]
    },
    "timeline": [
      {
        "id": 0,
        "text": [
          "ベアが白い月を見る",
          "Bea sees a white moon"
        ],
        "time": [
          "17:50",
          "17:50"
        ]
      },
      {
        "id": 1,
        "text": [
          "ノラが青いフィルターを入れる",
          "Nora fits the blue filter"
        ],
        "time": [
          "18:00",
          "18:00"
        ]
      },
      {
        "id": 2,
        "text": [
          "ミロが青い月を見る",
          "Milo sees a blue moon"
        ],
        "time": [
          "18:05",
          "18:05"
        ]
      }
    ]
  }
];root.CasebookCases=cases;if(typeof module!=="undefined")module.exports=cases;})(globalThis);
