(function(root){'use strict';
const solids=[];const rect=(x,y,w,h,kind='ground',id='')=>solids.push({x,y,w,h,kind,id});
[[0,544],[576,1040],[1088,1632],[1680,2320],[2368,3520]].forEach(([a,b])=>rect(a,176,b-a,80));
[[192,144,48],[352,128,64],[448,144,64],[640,144,64],[752,112,64],[864,144,64],[1152,144,64],[1280,112,64],[1440,144,64],[1600,144,48],[1728,128,64],[1840,112,64],[2000,144,80],[2176,128,64],[2432,144,64],[2576,112,64],[2720,144,64],[2896,128,64],[3072,144,64]].forEach(([x,y,w])=>rect(x,y,w,16,'ledge'));
[[272,'star'],[944,'heart'],[2496,'star']].forEach(([x,item],i)=>{rect(x,112,16,16,'box','box'+i);solids.at(-1).item=item;});
const coins=[];function row(x,y,n){for(let i=0;i<n;i++)coins.push({id:'m'+coins.length,x:x+i*20,y});}
row(124,150,4);row(360,102,3);row(652,118,3);row(760,86,3);row(1164,118,3);row(1292,86,3);row(1448,118,3);row(1740,102,3);row(2020,118,3);row(2184,102,3);row(2584,86,3);row(2728,118,3);row(2904,102,3);row(3200,150,5);
const enemies=[{id:'e0',x:450,y:160,a:416,b:520,type:'mushroom'},{id:'e1',x:800,y:160,a:736,b:1008,type:'slime'},{id:'e2',x:1232,y:160,a:1120,b:1408,type:'mushroom'},{id:'e3',x:1520,y:160,a:1440,b:1600,type:'slime'},{id:'e4',x:1940,y:160,a:1872,b:2080,type:'mushroom'},{id:'e5',x:2220,y:160,a:2112,b:2288,type:'slime'},{id:'e6',x:2700,y:160,a:2560,b:2800,type:'mushroom'},{id:'e7',x:3020,y:160,a:2896,b:3160,type:'slime'}];
const main={width:3520,solids,coins,enemies,spawn:{x:64,y:152},goal:{x:3392,y:112,w:48,h:64},checkpoint:{x:1496,y:176},portal:{x:1824,y:152,w:26,h:28}};
const secret={width:480,solids:[{x:0,y:176,w:480,h:80,kind:'ground'},{x:176,y:144,w:64,h:16,kind:'ledge'},{x:288,y:112,w:64,h:16,kind:'ledge'}],coins:Array.from({length:8},(_,i)=>({id:'s'+i,x:128+i*32,y:i>=5?86:(i===2||i===3?118:148)})),enemies:[],spawn:{x:56,y:152},portal:{x:32,y:148,w:24,h:28},treasure:{x:364,y:152,w:20,h:24}};

main.theme='meadow';main.title=['ひだまりの草原','SUNLIT MEADOW'];main.hint=['青い花の木かげには、もうひとつの道。','Blue flowers mark a hidden path.'];main.checkpoint={x:1496,y:152};main.secretName=['ひみつの木かげ','THE HIDDEN GROVE'];main.moving=[];main.hazards=[];main.wind=[];secret.theme='meadow';
function stage(id,width,title,theme,grounds,ledges,enemyXs){
 const solids=grounds.map(([a,b])=>({x:a,y:176,w:b-a,h:80,kind:'ground'}));
 ledges.forEach(([x,y,w,kind='ledge'])=>solids.push({x,y,w,h:16,kind,id:'ledge'+solids.length}));
 const coins=[];const row=(x,y,n)=>{for(let j=0;j<n;j++)coins.push({id:'m'+coins.length,x:x+j*20,y});};
 for(let x=140;x<width-180;x+=280)row(x,150,3);
 ledges.forEach(([x,y,w])=>{if(w>=48)row(x+12,y-25,Math.min(3,Math.floor((w-16)/20)));});
 const enemies=enemyXs.map((x,i)=>({id:'e'+i,x,y:160,a:x-36,b:x+56,type:i%2?'slime':'mushroom'}));
 const main={id,width,title,theme,solids,coins,enemies,spawn:{x:64,y:152},goal:{x:width-128,y:112,w:48,h:64},checkpoint:{x:Math.floor(width/2/16)*16,y:152},portal:{x:width-880,y:152,w:26,h:28},moving:[],hazards:[],wind:[],secretName:['かくれた宝物の部屋','THE SECRET TREASURE ROOM']};
 const secret={width:480,theme,solids:[{x:0,y:176,w:480,h:80,kind:'ground'},{x:160,y:144,w:64,h:16,kind:'ledge'},{x:288,y:112,w:64,h:16,kind:'ledge'}],coins:Array.from({length:10},(_,i)=>({id:'s'+i,x:104+i*30,y:i>=6?86:i>=2&&i<=4?118:148})),enemies:[],portal:{x:32,y:148,w:24,h:28},treasure:{x:404,y:152,w:20,h:24},moving:[],hazards:[],wind:[]};
 for(const [i,x] of [320,Math.floor(width/2)+160,width-620].entries())solids.push({x,y:112,w:16,h:16,kind:'box',id:'box'+i,item:i===1?'heart':'star'});
 return{main,secret};
}
const forest=stage(1,4128,['こもれびの森','WHISPERING WOODS'],'forest',[[0,736],[784,1488],[1536,2528],[2576,4128]],[[192,144,64],[384,112,64],[576,80,64],[896,144,80],[1136,112,64],[1328,80,96],[1696,144,64],[1888,112,80],[2112,80,64],[2416,144,64],[2752,144,80],[2976,112,96],[3200,80,64],[3584,144,96],[3776,112,64]],[520,980,1750,2260,2816,3648]);
forest.main.moving=[{id:'lift0',x:696,y:120,w:64,h:12,kind:'moving',axis:'y',range:35,period:5},{id:'lift1',x:2240,y:106,w:80,h:12,kind:'moving',axis:'x',range:80,period:6}];forest.main.hint=['木の足場はゆっくり動きます。上の道にはコインがいっぱい。','Wooden lifts carry you. Take the treetop route for more coins.'];forest.main.secretName=['こもれびの宝物庫','THE WOODLAND VAULT'];
const cave=stage(2,4352,['星あかりの洞窟','STARLIGHT CAVERN'],'cave',[[0,672],[720,1408],[1456,2384],[2432,3296],[3344,4352]],[[208,144,64],[400,112,64],[800,144,80],[1040,112,64],[1216,80,80],[1648,144,64],[1840,112,64],[2688,144,64],[2880,112,80],[3552,144,96],[3760,112,64],[3952,80,80]],[480,920,1632,2740,3650]);
cave.main.checkpoint={x:2176,y:152};cave.main.moving=[{id:'cart0',x:1992,y:144,w:80,h:16,kind:'cart',axis:'x',range:128,period:7}];for(let i=0;i<4;i++)cave.main.solids.push({id:'crumble'+i,x:1480+i*32,y:112,w:32,h:12,kind:'crumble'});cave.main.hazards=[{x:1168,y:166,w:28,h:10,kind:'spikes'},{x:3024,y:166,w:28,h:10,kind:'spikes'}];cave.main.hint=['ひびの床は乗ると崩れます。トロッコで宝石の道へ。','Cracked ledges crumble after a warning. Ride the mine cart to the crystal trail.'];cave.main.secretName=['きらめく水晶の間','THE CRYSTAL CHAMBER'];for(let i=0;i<8;i++)cave.main.coins.push({id:'rail'+i,x:1876+i*36,y:112});
const sky=stage(3,4480,['雲の向こうへ','SKYWARD ISLES'],'sky',[[0,592],[640,1328],[1376,2096],[2144,2880],[2928,3728],[3776,4480]],[[192,144,64],[352,112,64],[480,80,64],[800,144,80],[992,112,80],[1184,80,64],[1584,144,80],[1776,112,64],[2320,144,64],[2512,112,80],[2704,80,64],[3136,144,64],[3328,112,80],[3520,80,64],[3968,144,64],[4160,112,80]],[752,1496,2384,3056,4020]);
sky.main.moving=[{id:'cloud0',x:1888,y:104,w:80,h:12,kind:'cloud',axis:'x',range:64,period:5},{id:'cloud1',x:3664,y:128,w:64,h:12,kind:'cloud',axis:'y',range:28,period:4}];sky.main.wind=[{x:832,w:560,force:24},{x:2240,w:560,force:-22},{x:3296,w:480,force:26}];sky.main.hint=['空中では風に流されます。矢印とリボンで風向きを確認。','Wind nudges Pip in the air. Ribbons and arrows show the direction.'];sky.main.secretName=['雲の上の庭','THE CLOUD GARDEN'];
const fortress=stage(4,3648,['最後の砦','THE LAST KEEP'],'fortress',[[0,736],[784,1488],[1536,3648]],[[192,144,64],[384,112,64],[576,80,64],[928,144,80],[1120,112,80],[1376,144,64],[1648,144,64],[1840,112,64],[2064,144,64]],[480,1008,1664]);
fortress.main.checkpoint={x:2560,y:152};fortress.main.portal={x:2240,y:152,w:26,h:28};fortress.main.boss={left:2752,right:3472,x:3256,y:132,w:42,h:44,hp:3};fortress.main.hazards=[{x:1248,y:152,w:18,h:24,kind:'vent',period:4,offset:0},{x:1952,y:152,w:18,h:24,kind:'vent',period:4,offset:2}];fortress.main.hint=['光る床は噴き出す合図。砦の番人は突進後がチャンス！','Glowing vents warn before firing. Stomp the guardian while it catches its breath!'];fortress.main.secretName=['砦の小さな温室','THE HIDDEN CONSERVATORY'];
const stages=[{main,secret},forest,cave,sky,fortress];
const names=stages.map(s=>s.main.title);const get=(id=0,z='main')=>stages[id]?.[z]||stages[0][z];const total=id=>get(id).coins.length+get(id,'secret').coins.length;
root.PipWorld={main,secret,stages,get,total,coinTotal:total(0),stageNames:names};
if(typeof module!=='undefined')module.exports=root.PipWorld;
})(globalThis);
