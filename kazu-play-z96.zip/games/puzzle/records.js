(function(root,factory){const api=factory(typeof module==='object'&&module.exports?require('./atelier-engine.js'):root.PuzzleAtelier);if(typeof module==='object'&&module.exports)module.exports=api;else root.PuzzleRecords=api;})(typeof window==='object'?window:this,function(A){
 function stats(raw,hints){return{...A.stats(raw,hints),...(raw?.legacy===true?{legacy:true}:{})};}
 function medals(s){const m=A.medals(s);return s.legacy?[true,false,false]:m;}
 function upgrade(records){const out={};if(!records||typeof records!=='object'||Array.isArray(records))return out;for(const[k,r]of Object.entries(records)){const m=/^(\d+)-(12|24|48)$/.exec(k);if(!m||+m[1]>=30||!A.valid(r,+m[2]))continue;const h=Number.isInteger(r.hints)?Math.max(0,Math.min(3,r.hints)):3,complete=r.placed.length===+m[2],completed=r.completed===true||r.complete===true||complete;out[k]={...r,hints:h,complete,completed,stats:r.stats?stats(r.stats,h):{...stats(null,h),legacy:true},medals:Array.isArray(r.medals)&&r.medals.length===3?r.medals.map(x=>x===true):[completed,false,false]};}return out;}
 return{stats,medals,upgrade};
});
