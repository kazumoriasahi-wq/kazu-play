(function(root){'use strict';
function normalize(doc,hosted=true){
 if(!doc||typeof doc!=='object'||Array.isArray(doc))throw Error('Invalid save document');
 const out={records:{}};if(typeof doc.sound==='boolean')out.sound=doc.sound;
 if(!hosted&&['ja','en'].includes(doc.lang))out.lang=doc.lang;
 const goodLast=v=>v&&Number.isInteger(v.id)&&v.id>=0&&v.id<30&&[12,24,48].includes(v.n);
 if(doc.last!==undefined){if(!goodLast(doc.last))throw Error('Invalid last puzzle');out.last={id:doc.last.id,n:doc.last.n};}
 if(doc.records!==undefined){if(!doc.records||typeof doc.records!=='object'||Array.isArray(doc.records))throw Error('Invalid puzzle records');
  for(const [k,v] of Object.entries(doc.records)){const m=/^(\d+)-(12|24|48)$/.exec(k);if(!m||+m[1]>=30)throw Error('Unknown puzzle');const n=+m[2];if(!v||!Array.isArray(v.placed)||new Set(v.placed).size!==v.placed.length||!v.placed.every(i=>Number.isInteger(i)&&i>=0&&i<n)||!Array.isArray(v.order)||v.order.length!==n||new Set(v.order).size!==n||!v.order.every(i=>Number.isInteger(i)&&i>=0&&i<n))throw Error('Invalid puzzle progress');if(!Number.isInteger(v.hints)||v.hints<0||v.hints>3)throw Error('Invalid hint count');out.records[k]={placed:[...v.placed],order:[...v.order],hints:v.hints,complete:v.placed.length===n,completed:v.completed===true||v.complete===true||v.placed.length===n};if(v.stats!==undefined){const s=v.stats;if(!s||!Number.isFinite(s.elapsed)||s.elapsed<0||!['hintUses','referenceUses','mistakes'].every(k=>Number.isSafeInteger(s[k])&&s[k]>=0))throw Error('Invalid puzzle statistics');out.records[k].stats={elapsed:s.elapsed,hintUses:s.hintUses,referenceUses:s.referenceUses,mistakes:s.mistakes,...(s.legacy===true?{legacy:true}:{})};}if(v.medals!==undefined){if(!Array.isArray(v.medals)||v.medals.length!==3||!v.medals.every(x=>typeof x==='boolean'))throw Error('Invalid puzzle stamps');out.records[k].medals=[...v.medals];}}
 }return out;
}
function create(sdk,options={}){
 const hosted=!!sdk&&(!!sdk.IN_PLAYABLES_ENV||options.officialTest===true),storage=options.storage||(()=>root.localStorage),key='pip-picture-puzzle-playables-v1';let loaded=false,paused=false,audio=!hosted,dirty=false,revision=0,writing=null,value={},first=false,ready=false,bound=false,pendingWarning=false;const listeners=new Set();
 const emit=(type,v)=>listeners.forEach(fn=>fn(type,v));
 function warn(){if(paused){pendingWarning=true;return;}if(hosted)try{sdk.health.logWarning();}catch{}}
 function bind(){if(!hosted||bound)return;bound=true;audio=!!sdk.system.isAudioEnabled();sdk.system.onAudioEnabledChange(v=>{audio=!!v;emit('audio',audio)});sdk.system.onPause(()=>{if(paused)return;paused=true;emit('pause');void flush(true)});sdk.system.onResume(()=>{if(!paused)return;paused=false;emit('resume');if(pendingWarning){pendingWarning=false;warn()}void flush()});}
 async function init(){bind();let raw;if(hosted)raw=await sdk.game.loadData();else try{raw=storage().getItem(key)}catch{raw=null}let doc={};if(raw){const parsed=JSON.parse(raw);if(parsed.schema!==1)throw Error('Unsupported save version');doc=normalize(parsed.data,hosted)}value=doc;loaded=true;await whenActive();if(hosted){let locale='en';try{locale=await sdk.system.getLanguage()}catch{warn()}await whenActive();return {...doc,lang:String(locale).toLowerCase().startsWith('ja')?'ja':'en'}}return doc;}
 function save(doc){if(!loaded||paused)return false;value=normalize(doc,hosted);dirty=true;revision++;void flush();return true;}
 async function flush(final=false){if(!loaded||paused&&!final)return false;if(writing)return final?writing.then(()=>flush(true)):writing;if(!dirty)return true;writing=(async()=>{let firstPass=true;while(dirty&&(!paused||final&&firstPass)){firstPass=false;const rev=revision,raw=JSON.stringify({schema:1,data:value});try{if(hosted)await sdk.game.saveData(raw);else storage().setItem(key,raw)}catch{warn();if(!paused)emit('save-error');return false}if(revision===rev)dirty=false}return !dirty})().finally(()=>writing=null);return writing;}
 function whenActive(){if(!paused)return Promise.resolve();return new Promise(resolve=>{const fn=t=>{if(t==='resume'){listeners.delete(fn);resolve()}};listeners.add(fn)})}
 return {hosted,init,save,flush,whenActive,on:fn=>listeners.add(fn),warn,firstFrame(){if(first||paused)return;first=true;sdk?.game?.firstFrameReady?.()},gameReady(){if(ready||!first||!loaded||paused)return;ready=true;sdk?.game?.gameReady?.()},get paused(){return paused},get audioEnabled(){return audio},get loaded(){return loaded}};
}
root.PipPuzzlePlatform={create,normalize};if(typeof module!=='undefined')module.exports={create,normalize};
})(globalThis);
