(()=>{'use strict';
 const key='pip_play_language_v1';let language='ja';
 try{const q=new URLSearchParams(location.search).get('lang');language=['ja','en'].includes(q)?q:localStorage.getItem(key)==='en'?'en':'ja';}catch{}
 const english={golf:["PIP’S POCKET GOLF","Read the wind. Enjoy eighteen little escapes.","An 18-hole 3D golf tour: par 72, 6,610 yards. Choose four clubs and read the wind, slopes and bunkers. Standard and Challenge keep separate round records.","Tap to aim, adjust power and direction, then press SHOT. The putter is selected automatically on the green. OUT/IN scorecards and progress save automatically."],home:["WARM LITTLE HOME", "Six rooms. A warmer story.", "Restore a bedroom, kitchen, nursery, bathroom, living room and attic. Six distinct rooms and eighteen repairs, each with before-and-after artwork. Fit materials, stitch, connect pipes, cook, control heat and arrange shelves.", "Choose an unlocked room and tap a repair. Finish three tasks to unlock the next room. Start with 350 coins and earn 100 more in the workshop. Coins are spent only on success. Replay finished repairs for free. Progress from the six-room test carries over."],color:['COLOR STOP','Match a colour. Make their day.','A harbor parking puzzle with 120 stops across ten chapters. Twenty-four new expert stops contain 24 vehicles, 15–19 buses and 117–129 passengers. Original 96-stage layouts and saves stay compatible. Send matching cars and buses to three boarding bays. No timer, cheerful music and saved progress.','Tap vehicles with a clear path in the arrow direction. Passengers board from the front of the queue. Cars seat three and buses six. Full vehicles depart. Plan your order, undo or ask for a hint.'],
 block:['BLOCK RUSH 8 STUDIO','Find your flow, one block at a time.','Complete lines on an 8×8 board. Choose Standard with 16 shapes or Challenge with 28 shapes.','Choose a difficulty, then drag or tap to place blocks. Chain clears for combos. Each difficulty keeps its own run and best score.'],
 pip:['PIP’S HIDDEN TOWN','Little town. Lovely discoveries.','Explore 30 illustrated scenes with Pip in an unhurried spot-the-difference adventure.','Compare both pictures and tap the differences. Observation clues and a closer view are available.'],
 sky:["PIP’S SKY TRAIL STUDIO","Run through the sunlit sky gardens.","An endless three-lane run with Pip, ornate garden gates, floating waterfall ruins and warm stone bridges. Speed and obstacle difficulty rise every 150 m.","Swipe left/right to move, up to jump and down to slide. Jump crates and gaps, slide under low gates and dodge rocks. On-screen controls also work."],
 hop:['PIP’S ISLAND TRAIL','A little leap. A lovely journey.','Travel with Pip across eighteen morning islands, with moving platforms, breezes, scenic paths and checkpoints every six islands. Endless islands unlock after the journey.','Hold the scene or jump button, then release. Aim the landing ring at the next island. Tap controls let you choose your power instead.'],
 twins:['TIME TWINS','Your past self is your partner.','A time-shift puzzle where the order of your movements matters.','Move with the direction buttons or tap the floor. Your twin repeats your moves three seconds later. Work together on switches to open the door.'],
 shadow:['SHADOW BRIDGE','Move the light. Make a path.','Shape shadows into bridges and help Pip cross safely.','Drag the sun or adjust its direction and height. Connect the shadows, then cross the bridge.'],
 tower:['PERFECT TOWER','One perfect landing deserves another.','Stack moving blocks and build a chain of perfectly timed landings.','Tap when the moving block overlaps the tower. Any overhang is cut away, making the next landing harder.'],
 rain:['RAINDROP POST','Rainy days are delivery days.','Draw paths for raindrops and bring thirsty gardens to life.','Draw a downhill path from the cloud toward a flower. Guide enough rain to make every flower bloom.'],
 bite:['ONE BITE MONSTER','A tiny bite of happiness.','A quick timing game with a sweet-toothed little monster.','Tap when a sweet reaches the yellow window. Let the spiky hazards pass.'],
 squish:['SQUISH POST','A little squish. A happy delivery.','Change shape to squeeze through the next opening and deliver the post.','Hold to become tall and thin; release to become round. Match the opening as you pass through.'],
 orbit:['CLEAN ORBIT ACTION','Suck it in. Blast it out.','Explore a 3D garden with MOPI. Turn litter into ammunition, activate three devices and take on a giant machine.','Drag to move or use the stick. Nearby litter is collected automatically. Tap BLAST to fire, or hold and release for a charged shot. DASH to dodge. A lightweight mode is available in settings.'],
 puzzle:['PIP’S PICTURE PUZZLE','Piece by piece, a town comes to life.','Rebuild 30 scenes from PIP’S HIDDEN TOWN. Choose 12, 24 or 48 pieces with no time limit.','Drag a piece onto the board, or select it and tap its place. Use the reference picture, three hints per puzzle and the edge-piece filter. Progress is saved on this browser.'],
 cozy:['PIP’S COZY SORT','A comfortable place for every little thing.','Fit Pip’s belongings neatly into six themed drawers. There is no timer, so take your time.','Drag an item, or select it and tap its top-left destination cell. Rotate long items. Fit everything without overlaps. Undo, hints and saved progress are available.'],
 diner:['PIP’S LITTLE DINER','A good day starts in a little kitchen.','Toast bread and layer six ingredients to serve ten customers in Pip’s sandwich shop. No timer, cheerful music and optional automatic toast.','Start toasting and tap again when the needle reaches green. Add ingredients in the order shown, add the top slice and serve. Toast earns up to 20 points and ingredients up to 80. Undo and saved progress are available.'],
 bubble:['PIP’S BUBBLE JOURNEY','One more pop. One more personal best.','An endless score attack with character-face bubbles. Clear growing rows, chain cascades and beat your personal best as the pace rises.','Aim and release to shoot. Connect three or more matching colours. Swap colours or use rainbows. Unsupported bubbles fall together. Crossing the lower line ends the run; pausing stops new rows.']
 };
 const categories={'すべて':'All','パズル':'Puzzle','アクション':'Action','ワンタップ':'One tap','観察':'Observation','お気に入り':'Favourites'};
 const translations={
 '.top nav a[href="#collection"]':'Games','.top nav a[href="about.html"]':'About',
 '.hero h1':'Take a break.<br>Come play<span>.</span>',
 '.hero .intro':'Pick a game that catches your eye.<br>A little adventure starts with a tap.',
 '.hero .button':'Find your next game <span>↗</span>',
 '.hero .note':'Free · No sign-up · iPhone / Android',
 '.artcaption>span':'FEATURED / SPOT THE DIFFERENCE','.roundnote':'A little<br>curiosity.',
 '.sectionhead h2':'What shall we play today?',
 '#empty':'No games found. Try another search or filter.',
 '.install h2':'A little arcade.<br>Right in your pocket.',
 '.install>div:first-child>p:last-child':'Add us to your home screen for your next little break.',
 '#install':'Add to home screen ↗',
 '.install>div:last-child>p:nth-of-type(1)':'<strong>Android / Chrome</strong><br>Open the ⋮ menu → Add to home screen or Install app.',
 '.install>div:last-child>p:nth-of-type(2)':'<strong>iPhone / Safari</strong><br>Tap Share → Add to Home Screen.',
 '.install small':'Wording varies by browser. An internet connection is required.',
 '.ad-placeholder':'Advertising space · No ads are currently being served.',
 'footer>p':'A little joy for your spare moments.',
 'footer a[href="about.html"]':'About this site','footer a[href="privacy.html"]':'Privacy (Japanese)',
 'footer a[href="terms.html"]':'Terms (Japanese)',
 '.top>a[href*="#collection"]':'← All games','.portal-language>span':'Language'
 };
 const originals=new Map();
 function apply(){
  document.documentElement.lang=language;
  for(const[selector,text]of Object.entries(translations))for(const e of document.querySelectorAll(selector)){if(!originals.has(e))originals.set(e,e.innerHTML);e.innerHTML=language==='en'?text:originals.get(e);}
  document.querySelectorAll('[data-filter]').forEach(e=>{const k=e.dataset.filter;e.textContent=language==='en'?(k==='お気に入り'?'♡ ':'')+categories[k]:(k==='お気に入り'?'♡ ':'')+k;});
  const search=document.getElementById('search');if(search){search.placeholder=language==='en'?'Find a game':'ゲームを探す';search.setAttribute('aria-label',language==='en'?'Search games':'ゲームを検索');}
  document.querySelector('.filters')?.setAttribute('aria-label',language==='en'?'Filter games':'ゲームの絞り込み');
  const hero=document.querySelector('.heroart');hero?.setAttribute('aria-label',language==='en'?'Explore PIP’S HIDDEN TOWN':'PIP’S HIDDEN TOWNを詳しく見る');hero?.querySelector('img')?.setAttribute('alt',language==='en'?'Pip’s little bakery, surrounded by flowers and fresh bread':'PIPの町にある、花とパンに囲まれた小さなお店');
  document.querySelector('.ad-placeholder')?.setAttribute('aria-label',language==='en'?'Advertising status':'広告配信の準備状況');
  const select=document.getElementById('portalLanguage');if(select)select.value=language;
  for(const a of document.querySelectorAll('a[href*="detail.html?game="],.top .brand,.top>a[href*="#collection"]')){const u=new URL(a.href);u.searchParams.set('lang',language);a.href=u.pathname+u.search+u.hash;}
  if(document.querySelector('#grid'))document.title=language==='en'?'PIP & PLAY — Take a break. Come play.':'PIP & PLAY — ひと息、あそぼう。';
  if(document.querySelector('#grid'))document.querySelector('meta[name=description]')?.setAttribute('content',language==='en'?'Thirteen little adventures for your spare moments. Play original PIP & PLAY games on iPhone and Android.':'ひと息つける、13の小さな冒険。PIP & PLAYのオリジナルゲームをiPhone・Androidで。');
  window.dispatchEvent(new Event('portal-language-change'));
 }
 window.PipPortalLanguage={get language(){return language;},pick:(ja,en)=>language==='en'?en:ja,category:k=>language==='en'?categories[k]||k:k,game:g=>{const e=english[g.id];return language==='en'&&e?{...g,title:e[0],tag:e[1],description:e[2],how:e[3],imageAlt:e[0]+' game illustration'}:g;}};
 document.getElementById('portalLanguage')?.addEventListener('change',e=>{language=e.target.value==='en'?'en':'ja';try{localStorage.setItem(key,language)}catch{}const url=new URL(location.href);url.searchParams.set('lang',language);history.replaceState(null,'',url);apply();});
 apply();
})();
