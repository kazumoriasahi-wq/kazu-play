(() => {
  'use strict';
  const names = {
  "block": "BLOCK RUSH 8 STUDIO",
  "pip": "PIP’S HIDDEN TOWN",
  "sky": "そらいろ遺跡ラン STUDIO",
  "hop": "PIP’S ISLAND TRAIL",
  "tower": "ぴったりタワー",
  "orbit": "くるっと！おそうじ惑星 ACTION",
  "puzzle": "PIP’S PICTURE PUZZLE",
  "cozy": "PIP’S COZY SORT",
  "diner": "PIP’S LITTLE DINER",
  "bubble": "PIP’S BUBBLE JOURNEY",
  "color": "COLOR STOP",
  "home": "WARM LITTLE HOME",
  "golf": "PIP’S POCKET GOLF",
  "detective": "PIP’S LITTLE DETECTIVE"
};
  const match = location.pathname.match(/^\/games\/([a-z]+)\/index\.html$/);
  if (!match || !Object.hasOwn(names, match[1])) return;
  const id = match[1];
  window.PipGameMetrics = {
    id,
    name: names[id],
    start() {
      try {
        window.KazuAnalytics?.track('game_start', {
          game_id: id,
          game_name: names[id]
        });
      } catch { /* Analytics must never interrupt a game. */ }
    }
  };
})();
