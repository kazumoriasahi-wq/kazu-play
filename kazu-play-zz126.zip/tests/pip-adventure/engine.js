(function(root){'use strict';const W=root.PipWorld||require('./world.js');
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
function fresh(){return{version:1,phase:'playing',zone:'main',x:64,y:152,vx:0,vy:0,w:13,h:24,face:1,ground:true,coyote:.12,buffer:0,jumpHold:0,dash:100,time:0,score:0,hp:3,immune:0,power:0,hurt:0,land:0,anim:0,checkpoint:false,secret:false,treasure:false,coins:[],used:[],defeated:[],items:[],enemies:W.main.enemies.map(e=>({...e,dir:1})),events:[],returnX:1824,checkpointData:null,justInteracted:false};}
function zone(s){return W[s.zone];}function body(s){return{x:s.x,y:s.y,w:s.w,h:s.h};}
function snapshot(s){const d={...s,phase:s.phase==='clear'?'clear':'playing',events:[]};delete d.checkpointData;return JSON.parse(JSON.stringify(d));}
function restore(raw){if(!raw||raw.version!==1||!['main','secret'].includes(raw.zone)||!Number.isFinite(raw.x)||!Number.isFinite(raw.y)||!Number.isFinite(raw.time)||raw.time<0||raw.time>1e7||!Number.isInteger(raw.hp)||raw.hp<1||raw.hp>3)return null;
 const strings=(a,max)=>Array.isArray(a)&&a.length<=max&&a.every(x=>typeof x==='string');
 if(!strings(raw.coins,W.coinTotal)||new Set(raw.coins).size!==raw.coins.length||raw.coins.some(id=>!W.main.coins.concat(W.secret.coins).some(c=>c.id===id))||!strings(raw.used,3)||raw.used.some(id=>!['box0','box1','box2'].includes(id))||!strings(raw.defeated,8)||raw.defeated.some(id=>!W.main.enemies.some(e=>e.id===id)))return null;
 if(raw.x<0||raw.x>W[raw.zone].width||raw.y< -200||raw.y>240||!Number.isFinite(raw.score)||raw.score<0||raw.score>1e9)return null;
 const s=fresh();Object.assign(s,raw);s.w=13;s.h=24;s.vx=0;s.vy=0;s.events=[];s.phase='playing';s.buffer=0;s.jumpHold=0;s.coyote=0;s.immune=clamp(Number(raw.immune)||0,0,1.5);s.power=clamp(Number(raw.power)||0,0,8);s.dash=clamp(Number(raw.dash)||0,0,100);s.face=raw.face===-1?-1:1;s.items=Array.isArray(raw.items)?raw.items.filter(it=>it&&['box0','box1','box2'].includes(it.id)&&['star','heart'].includes(it.type)&&Number.isFinite(it.x)&&Number.isFinite(it.y)&&Number.isFinite(it.life)&&it.life>0&&it.life<=16).map(it=>({id:it.id,type:it.type,x:it.x,y:it.y,life:it.life})):[];s.enemies=W.main.enemies.map(e=>({...e,dir:1}));s.checkpoint=!!raw.checkpoint;s.secret=!!raw.secret;s.treasure=!!raw.treasure;s.checkpointData=null;return s;
}
function damage(s,knock=0){if(s.immune>0||s.power>0||s.phase!=='playing')return;s.hp--;s.immune=1.5;s.hurt=.45;s.vy=-115;s.vx=knock*110;s.events.push({type:'hurt'});if(s.hp<=0){s.phase='dead';s.events.push({type:'dead'});}}
function retry(s){const time=s.time;const data=s.checkpointData?restore(s.checkpointData):null;const n=data||fresh();if(s.checkpoint&&!data){n.checkpoint=true;n.x=1496;n.y=152;n.coins=[...s.coins];n.used=[...s.used];n.defeated=[...s.defeated];n.score=s.score;n.secret=s.secret;n.treasure=s.treasure;}
 n.time=time;n.hp=3;n.immune=1.5;n.phase='playing';n.checkpointData=s.checkpointData;return n;}
function interaction(s){if(s.phase!=='playing')return false;const p=zone(s).portal;return Math.abs(s.x-p.x)<34&&Math.abs(s.y-p.y)<36;}
function tick(s,input,dt){if(s.phase!=='playing')return;s.events=[];dt=clamp(dt,0,1/30);s.time+=dt;s.anim+=dt;s.immune=Math.max(0,s.immune-dt);s.power=Math.max(0,s.power-dt);s.hurt=Math.max(0,s.hurt-dt);s.land=Math.max(0,s.land-dt);s.jumpHold=Math.max(0,(s.jumpHold||0)-dt);
 if(input.jumpPressed)s.buffer=.18;else s.buffer=Math.max(0,s.buffer-dt);if(s.ground)s.coyote=.15;else s.coyote=Math.max(0,s.coyote-dt);
 if(input.interact&&!s.justInteracted&&interaction(s)){if(s.zone==='main'){s.returnX=s.x;s.zone='secret';s.x=56;s.y=152;if(!s.secret){s.secret=true;s.score+=500;s.events.push({type:'secret'});}else s.events.push({type:'warp'});}else{s.zone='main';s.x=1856;s.y=152;s.events.push({type:'warp'});}s.vx=s.vy=0;s.ground=true;s.justInteracted=true;return;}s.justInteracted=!!input.interact;
 const axis=(input.right?1:0)-(input.left?1:0),dashing=!!input.dash&&!!axis&&s.dash>0;s.dashing=dashing;if(axis)s.face=axis;
 if(dashing)s.dash=Math.max(0,s.dash-dt*42);else s.dash=Math.min(100,s.dash+dt*(s.ground?28:12));
 const speed=dashing?145:88,target=axis*speed,accel=s.ground?1050:700;
 if(s.hurt<=.2)s.vx+=clamp(target-s.vx,-accel*dt,accel*dt);
 if(s.buffer>0&&s.coyote>0){s.vy=-260;s.ground=false;s.coyote=0;s.buffer=0;s.jumpHold=.14;s.events.push({type:'jump'});}
 if(!input.jump&&s.jumpHold<=0&&s.vy< -110)s.vy=-110;s.vy=Math.min(380,s.vy+620*dt);
 const solids=zone(s).solids,oldY=s.y,wasGround=s.ground;
 s.x+=s.vx*dt;s.x=clamp(s.x,0,zone(s).width-s.w);
 for(const r of solids)if(overlap(body(s),r)){if(s.vx>0)s.x=r.x-s.w;else if(s.vx<0)s.x=r.x+r.w;s.vx=0;}
 s.y+=s.vy*dt;s.ground=false;
 for(const r of solids)if(overlap(body(s),r)){if(s.vy>=0){s.y=r.y-s.h;s.ground=true;if(!wasGround&&s.vy>80){s.land=.13;s.events.push({type:'land'});}s.vy=0;}else{s.y=r.y+r.h;s.vy=0;if(r.kind==='box'&&!s.used.includes(r.id)){s.used.push(r.id);s.items.push({id:r.id,type:r.item,x:r.x,y:r.y-18,life:16});s.events.push({type:'box'});}}}
 for(const c of zone(s).coins)if(!s.coins.includes(c.id)&&overlap(body(s),{x:c.x-4,y:c.y-5,w:8,h:10})){s.coins.push(c.id);s.score+=100;s.events.push({type:'coin',x:c.x,y:c.y});}
 s.items=s.items.filter(it=>{it.life-=dt;if(overlap(body(s),{x:it.x-3,y:it.y-4,w:18,h:18})){if(it.type==='star')s.power=8;else s.hp=Math.min(3,s.hp+1);s.score+=200;s.events.push({type:it.type});return false;}return it.life>0;});
 if(s.zone==='main'){
  for(const e of s.enemies){if(s.defeated.includes(e.id))continue;e.x+=e.dir*(e.type==='slime'?19:25)*dt;if(e.x<e.a){e.x=e.a;e.dir=1;}if(e.x>e.b){e.x=e.b;e.dir=-1;}const b={x:e.x,y:e.y,w:16,h:16};if(overlap(body(s),b)){if(s.power>0){s.defeated.push(e.id);s.score+=200;s.events.push({type:'stomp',x:e.x,y:e.y});}else if(s.vy>0&&oldY+s.h<=e.y+7){s.defeated.push(e.id);s.vy=-190;s.score+=200;s.events.push({type:'stomp',x:e.x,y:e.y});}else damage(s,s.x<e.x?-1:1);}}
  if(!s.checkpoint&&Math.abs(s.x-1496)<22&&s.ground){s.checkpoint=true;s.checkpointData=snapshot(s);s.events.push({type:'checkpoint'});}
  if(overlap(body(s),W.main.goal)){s.phase='clear';s.score+=1000;s.events.push({type:'clear'});}
 }else if(!s.treasure&&overlap(body(s),zone(s).treasure)){s.treasure=true;s.hp=3;s.score+=750;s.power=8;s.events.push({type:'treasure'});}
 if(s.y>256){s.hp=0;s.phase='dead';s.events.push({type:'dead'});}
}
const api={fresh,tick,retry,restore,snapshot,interaction,overlap,damage};root.PipAdventure=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
